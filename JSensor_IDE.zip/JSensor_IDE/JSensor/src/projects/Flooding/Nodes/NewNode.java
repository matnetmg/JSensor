package projects.Flooding.Nodes;

import jsensor.nodes.Node;
import jsensor.nodes.messages.Inbox;
import jsensor.nodes.messages.Message;
import projects.Flooding.Messages.FloodingMessage;


/**
 *
 * @author danniel & Matheus
 */
public class NewNode extends Node{
    public int energy; 

    @Override
    public void handleMessages(Inbox inbox) {    	
       while(inbox.hasMoreMessages())
       {
           Message message = inbox.getNextMessage();
          
           if(message instanceof FloodingMessage)
           {
        	   FloodingMessage floodingMessage = (FloodingMessage) message;
        	   
           }
       }
    }

    @Override
    public void onCreation() 
    {
        
    }
}

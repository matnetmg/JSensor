package projects.MobilePhone_DSR.DSRAlgorithm;

public class DSRUtils {
    public static class DSRConstants {
        private static final int activeRouteTime = 3000;
        
        public static int getActiveRouteTime() {
            return activeRouteTime;
        }
    }
}

package projects.Flooding_ring;

import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.runtime.AbsCustomGlobal;
import jsensor.runtime.Jsensor;

/**
 *
 * @author danniel & Matheus
 */
public class CustomGlobal extends AbsCustomGlobal{
	
	static byte[] key;
	
    @Override
    public boolean hasTerminated() {
        return false;
    }
    
    @Override
    public void preRun() {
    }

    @Override
    public void preRound() {
    }

    @Override
    public void postRound() {
    }

	@Override
	public void postRun() {
	}
}

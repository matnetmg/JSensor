package projects.Flooding_ring.DistributionModels;

import jsensor.nodes.Node;
import jsensor.nodes.models.DistributionModelNode;
import jsensor.runtime.Jsensor;
import jsensor.utils.Position;

/**
 *
 * @authorMatheus
 */
public class LineDistribution extends DistributionModelNode
{
	 @Override
	    public Position getPosition(Node n) {
		 int half = Jsensor.numNodes/2;
		 if(n.getID() <= half) {
	        return new Position(n.getID(), 0);
		 }
		 else {
			 int back = n.getID() - half;
			 return new Position(half - back+1 , 0);
		 }
	    }
}

package projects.Flooding_ring.Nodes;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import jsensor.nodes.Node;
import jsensor.nodes.messages.Inbox;
import jsensor.nodes.messages.Message;
import jsensor.runtime.Jsensor;
import projects.Flooding_ring.Messages.FloodingMessage;
import projects.Flooding_ring.Timers.FloodingTimer;


/**
 *
 * @author danniel & Matheus
 */
public class FloodingNode extends Node{
    public LongOpenHashSet messagesIDs; 

    @Override
    public void handleMessages(Inbox inbox) {    	
       while(inbox.hasMoreMessages())
       {
           Message message = inbox.getNextMessage();
          
           if(message instanceof FloodingMessage)
           {
        	   FloodingMessage floodingMessage = (FloodingMessage) message;
        	   
               if(this.messagesIDs.contains(floodingMessage.getID()))
               {
                   continue;
               }
               
               this.messagesIDs.add(floodingMessage.getID());
               if(floodingMessage.getDestination() == this.getID())
               {
            	   Jsensor.log("time: "+ Jsensor.currentTime +
            			   "\t sensorID: " +this.ID+
            			   "\t receivedFrom: " +floodingMessage.getSender()+
            			   "\t hops: "+ floodingMessage.getHops() +
            			   "\t path: " +floodingMessage.getMsg().concat(this.ID+""));
               }
               else
               {
            	   //simulates some work
            	   int n = 99999;
                   int cont = 0;
                   int i = 1;
                   while (i <= n) {
                       if (n % i == 0) {
                           ++cont;
                       }
                       ++i;
                   }
                   if (cont > 0) {
                	   this.multicast(floodingMessage);
                   }
            	   
                   
               }
               
               floodingMessage = null;
              
           }
       }
    }

    @Override
    public void onCreation() 
    {
    	//initializes the list of messages received by the node.
        this.messagesIDs = new LongOpenHashSet();
        
    	if(this.ID <= 100) {
			int time = 1;
	    	FloodingTimer ft = new FloodingTimer();
	        ft.startRelative(time, this);
			
    	}
    }
}
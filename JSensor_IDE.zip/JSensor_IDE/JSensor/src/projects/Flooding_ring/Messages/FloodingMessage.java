package projects.Flooding_ring.Messages;

import jsensor.nodes.messages.Message;




public class FloodingMessage
  extends Message
{
  private String msg;
  private int sender;
  private int destination;
  private int hops;
  byte chunk;
  
  public FloodingMessage(int sender, int destination, int hops, String message, byte chunk)
  {
    super(chunk);
    msg = message;
    this.sender = sender;
    this.destination = destination;
    this.hops = hops;
    this.chunk = chunk;
  }
  
  private FloodingMessage(String msg, int sender, int destination, int hops, long ID)
  {
    setID(ID);
    this.msg = msg;
    this.sender = sender;
    this.destination = destination;
    this.hops = hops;
  }
  
  public String getMsg() {
    return msg;
  }
  
  public void setMsg(String msg) {
    this.msg = msg;
  }
  
  public int getDestination() {
    return destination;
  }
  
  public void setDestination(int destination) {
    this.destination = destination;
  }
  
  public int getHops() {
    return hops;
  }
  
  public void setHops(int hops) {
    this.hops = hops;
  }
  
  public short getChunk() {
    return chunk;
  }
  
  public int getSender() {
    return sender;
  }
  
  public void setSender(int sender) {
    this.sender = sender;
  }
  
  public Message clone()
  {
    return new FloodingMessage(msg, sender, destination, hops + 1, getID());
  }
}
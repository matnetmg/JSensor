package projects.Airquality.CellModels;

import jsensor.runtime.Jsensor;
import jsensor.nodes.Node;
import jsensor.nodes.monitoring.CellModel;
import jsensor.nodes.monitoring.HandleCells;
import projects.Airquality.Nodes.Car;
import projects.Airquality.Nodes.Cow;
import projects.Airquality.Nodes.House;
import projects.Airquality.Nodes.Human;
import projects.Airquality.Nodes.Industry;
import projects.Airquality.Nodes.Truck;

public class InsertCO2Cell extends HandleCells {

	@Override
	public void fire(Node node, CellModel cell) {
		GridCell cellToChange = (GridCell) cell;
		if(node instanceof Car){
			Car car = (Car)node;
			
			double co2level = cellToChange.getco2();
    	    double inc = node.getRandom().nextDouble() * Car.co2affect; 
    	    cellToChange.setco2(co2level + inc);
    	    Jsensor.setCell(cellToChange);
    	    Jsensor.log("Time: - "+ Jsensor.currentTime +" Car: "+ car.getID()+ " Releasing CO2");
	    	   
		}else if(node instanceof Cow){
			Cow cow= (Cow) node;
			
			double co2level = cellToChange.getco2();
		    double inc = cow.getRandom().nextDouble() * Cow.co2affect; 
		    cellToChange.setco2(co2level + inc);
		    Jsensor.setCell(cellToChange);
		    Jsensor.log("Time: - "+ Jsensor.currentTime +" Cow: "+ cow.getID()+ " Releasing CO2");
			
		}else if(node instanceof House){
			House house = (House) node;
			
			double co2level = cellToChange.getco2();
	    	double inc = house.getRandom().nextDouble() * House.co2affect; 
	    	cellToChange.setco2(co2level + inc);
	    	Jsensor.setCell(cellToChange);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" House: "+ house.getID()+ " Releasing CO2");
			
		}else if(node instanceof Human){
			Human human = (Human) node;
			
			double co2level = cellToChange.getco2();
	    	double inc = human.getRandom().nextDouble() * Human.co2affect; 
	    	cellToChange.setco2(co2level + inc);
	    	Jsensor.setCell(cellToChange);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" Human: "+ human.getID()+ " Releasing CO2");
			
		}else if(node instanceof Industry){
			Industry industry = (Industry) node;
			
			double co2level = cellToChange.getco2();
	    	   double inc = industry.getRandom().nextDouble() * Industry.co2affect; 
	    	   cellToChange.setco2(co2level + inc);
	    	   Jsensor.setCell(cellToChange);
	    	   Jsensor.log("Time: - "+ Jsensor.currentTime +" Industry: "+ industry.getID()+ " Releasing CO2");
			
		}else if(node instanceof Truck){
			Truck truck = (Truck) node;
			
			double co2level = cellToChange.getco2();
	    	double inc = truck.getRandom().nextDouble() * Truck.co2affect; 
	    	cellToChange.setco2(co2level + inc);
	    	Jsensor.setCell(cellToChange);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" Truck: "+ truck.getID()+ " Releasing CO2");
			
		}

	}
	
}

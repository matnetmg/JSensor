package projects.Airquality.Nodes;

import jsensor.nodes.Node;
import jsensor.nodes.messages.Inbox;
import projects.Airquality.CellModels.RemoveCO2Cell;

public class MediumTree extends Node {

	
	public static double co2affect = 2;
	public static double reduction = 0.95;
	public long nextTime = 1;
	
	@Override
    public void handleMessages(Inbox inbox) {
		
		RemoveCO2Cell removeCO2 = new RemoveCO2Cell();
		removeCO2.addCell(this, this.getPosition());
    }
     
    @Override
    public void onCreation() 
    {
      
    }
}
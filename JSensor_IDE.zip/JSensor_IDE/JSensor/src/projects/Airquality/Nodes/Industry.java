package projects.Airquality.Nodes;

import jsensor.runtime.Jsensor;
import jsensor.nodes.Node;
import jsensor.nodes.messages.Inbox;
import projects.Airquality.CellModels.InsertCO2Cell;

/**
 *
 * @author Matheus
 */
public class Industry extends Node{
	
	public static double co2affect = 1000;
	public static int percentage = 10;
	public long nextTime = 1;
	
	@Override
    public void handleMessages(Inbox inbox) {
		
		if (Jsensor.currentTime >= this.nextTime) {
			
			InsertCO2Cell insertCO2 = new InsertCO2Cell();
			insertCO2.addCell(this, this.getPosition());
			setNextTime();
		}
    }
	
	private void setNextTime() {
		this.nextTime = Jsensor.currentTime + (long) this.getRandom().nextInt((int)(200/percentage));
	}
    
    @Override
    public void onCreation() 
    {
     
    }
}
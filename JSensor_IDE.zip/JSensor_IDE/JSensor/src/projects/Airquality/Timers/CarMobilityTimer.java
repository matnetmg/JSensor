package projects.Airquality.Timers;

import java.util.Hashtable;

import jsensor.nodes.Node;
import jsensor.nodes.models.MobilityModel;
import jsensor.runtime.Jsensor;
import jsensor.utils.Position;

public class CarMobilityTimer extends MobilityModel
{	
	private Hashtable<Integer, Integer> nodes;
	
	public CarMobilityTimer(){
		this.nodes = new Hashtable<>();
	}
	
	public CarMobilityTimer(Hashtable<Integer, Integer> nodes){
		this.nodes = nodes;
	}
	
    @Override
    public CarMobilityTimer clone() {
        return new CarMobilityTimer(this.nodes);
    }

    @Override
    public Position getNextPosition(Node n) 
    {
    	return nextMoviment(n);
    }
   
    public Position nextMoviment(Node n){
    	int x = n.getPosition().getPosX();
    	int y = n.getPosition().getPosY();
    	int direction, newDirection = 0;
    	
    	if(nodes.containsKey(n.getID())){
    		direction = nodes.get(n.getID());
    		
    		//if is stopped.
    		if(direction == 8){
    			//probability of remain stopped = 0.8
    			if(n.getRandom().nextDouble() < 0.8)
    				return n.getPosition();
    		}
    		//if is walking.
    		else{
    			//probability of stop = 0.2
    			if(n.getRandom().nextDouble() < 0.2){
    				nodes.put(n.getID(), 8);
    				return n.getPosition();
    			}
    		}
    		
    		//probability of change the moviment
        	if(n.getRandom().nextDouble() > 0.8){
        		do{
        			newDirection = n.getRandom().nextInt(8);
        			
        		}while(direction == newDirection);	
        	}	
    	}
    	
    	direction = needChange(n, x, y, newDirection);
    	
    	nodes.put(n.getID(), direction);
    	
    	int movedist = this.node.getRandom().nextInt(1000);
    	
    	int ys = Jsensor.getDimY(); int xs = Jsensor.getDimX();
    	
    	switch(direction){
    		case 0:{ 
    		return new Position(n.getPosition().getPosX(), Math.min(ys, n.getPosition().getPosY() + movedist));}
    		case 1:{ 
    		return new Position(Math.min(xs , n.getPosition().getPosX() + (int)(movedist/Math.sqrt(2))), Math.min(n.getPosition().getPosY() + (int) (movedist/Math.sqrt(2)), ys));}
    		case 2:{ 
    		return new Position(Math.min(xs,n.getPosition().getPosX() + movedist ), n.getPosition().getPosY());}
    		case 3:{ 
    		return new Position(Math.min(xs, n.getPosition().getPosX() + (int)(movedist/Math.sqrt(2))), Math.max(0, n.getPosition().getPosY() - (int)(movedist/Math.sqrt(2))));}
    		case 4:{ 
    		return new Position(n.getPosition().getPosX(), Math.max(0, n.getPosition().getPosY() - movedist));}
    		case 5:{ 
    		return new Position(Math.max(0, n.getPosition().getPosX() - (int)(movedist/Math.sqrt(2))), Math.max(0, n.getPosition().getPosY() - (int)(movedist/Math.sqrt(2))));}
    		case 6:{ 
    		return new Position(Math.max(0, n.getPosition().getPosX() - movedist), n.getPosition().getPosY());}
    		case 7:{ 
    		return new Position(Math.max(0, n.getPosition().getPosX() - (int)(movedist/Math.sqrt(2))), Math.min(ys, n.getPosition().getPosY() + (int)(movedist/Math.sqrt(2))));}		
    	}
		return null;
    }
    
    public int needChange(Node n, int x, int y, int direction){
    	//checks if the position have to change
    	if(x == 0){
    		if(y == 0){
    			direction = n.getRandom().nextInt(3);
    		}
    		else if(y == Jsensor.getDimY()){
    			direction = 3 + n.getRandom().nextInt(3);
    		}
    		else{
    			if(direction >= 5 && direction <=7){
    				direction = n.getRandom().nextInt(5);
    			}
    		}
    	}
    	else if(x == Jsensor.getDimX()){
    		if(y == Jsensor.getDimY()){
    			direction = 4 + n.getRandom().nextInt(3);
    		}
    		else{
    			if(direction >= 1 && direction <= 3){
    				direction = n.getRandom().nextInt(5);
    				if(direction != 0)
    					direction += 3;
    			}
    		}
    	}
    	
    	if(y == 0){
    		if(x == Jsensor.getDimX()){
    			direction = n.getRandom().nextInt(3);
    			if(direction != 0)
    				direction += 5;
    		}
    		else{
    			if(direction >= 3 && direction <= 5){
    				direction = n.getRandom().nextInt(5);
    				if(direction == 3)
    					direction += 3;
    				else if(direction == 4)
    					direction += 3;
    			}
    		}
    	}
    	else if(y == Jsensor.getDimY()){
    		if(direction ==0 || direction == 1 || direction == 7){
    			direction = 2 + n.getRandom().nextInt(5);
    		}
    	}
    	return direction;
    }
}


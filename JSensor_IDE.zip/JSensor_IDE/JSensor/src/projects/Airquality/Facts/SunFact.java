package projects.Airquality.Facts;

import projects.Airquality.CellModels.GridCell;
import jsensor.nodes.events.EventModel;
import jsensor.nodes.monitoring.CellModel;
import jsensor.runtime.Jsensor;

public class SunFact extends EventModel
{
	@Override
	public CellModel setValue(CellModel cell) {
		float newWater = ((GridCell)cell).getWater() - Jsensor.getNodeByID(1).getRandom().nextFloat()*100;
		if (newWater < 0) {
			newWater = 0;
		}
		((GridCell)cell).setWater(newWater);
		return cell;
	}

	@Override
	public SunFact clone() {
		return new SunFact();
	}
}
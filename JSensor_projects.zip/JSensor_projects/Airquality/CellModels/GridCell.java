package projects.Airquality.CellModels;

import jsensor.nodes.monitoring.DefaultJsensorCell;

public class GridCell extends DefaultJsensorCell{
	private boolean thunder;
	private Float water;
	private double co2;
	
	public double getco2() {
		return co2;
	}
	
	public void setco2(double co2) {
		this.co2 = co2;
	}
	
	public Float getWater() {
		return water;
	}

	public void setWater(Float water) {
		this.water = water;
	}

	public GridCell (){
		this.thunder = false;
		this.water = new Float(0);
		this.co2 = new Integer(0);
	}
	
	public GridCell (boolean thunder, Float water, double co2){
		this.thunder = thunder;
		this.water = water;
		this.co2 = co2;
		
	}

	public boolean getThunder() {
		return this.thunder;
	}
	
	public void setThunder(boolean thunder) {
		this.thunder = thunder;
	}
	

	@Override
	public GridCell clone() {
		return new GridCell(this.thunder, this.water, this.co2);
	}
}
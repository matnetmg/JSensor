package projects.MobilePhone_DSR.Reliability_models;

import jsensor.nodes.messages.Packet;
import jsensor.nodes.models.ReliabilityModel;
import projects.MobilePhone_DSR.Nodes.CellPhone;

public class PhonesReliability extends ReliabilityModel{

	@Override
	public boolean reachesDestination(Packet p) {
		if(p.getNode() instanceof CellPhone) {
			if(p.getNode().getRandom().nextFloat() > 0.95) {
				return false;
			}
		}
		return false;
	}

}

package projects.MobilePhone_DSR.Transmission_models;

import jsensor.nodes.Node;
import jsensor.nodes.messages.Message;
import jsensor.nodes.models.MessageTransmissionModel;
import projects.MobilePhone_DSR.Nodes.Antenna;
import projects.MobilePhone_DSR.Nodes.CellPhone;

public class MobilePhoneTransmissionModel extends MessageTransmissionModel{

	@Override
	public float timeToReach(Node nodeSource, Node nodeDestination, Message msg) {
		if(nodeSource instanceof Antenna)
			return 2;
		
		if (nodeSource instanceof CellPhone)
			return 3;
		
		return 3;
	}

}

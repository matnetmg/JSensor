package projects.MobilePhone_DSR.Reliability_models;

import jsensor.nodes.messages.Packet;
import jsensor.nodes.models.ReliabilityModel;
import projects.MobilePhone_DSR.Nodes.Antenna;

public class AntennasReliability extends ReliabilityModel{
	@Override
	public boolean reachesDestination(Packet p) {
		if(p.getNode() instanceof Antenna) {
			if(p.getNode().getRandom().nextFloat() > 0.98) {
				return false;
			}
		}
		return false;
	}
}

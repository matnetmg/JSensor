package projects.Airquality.CellModels;

import jsensor.nodes.Node;
import jsensor.nodes.monitoring.CellModel;
import jsensor.nodes.monitoring.HandleCells;

public class SetFactCell extends HandleCells {

	@Override
	public void fire(Node sensor, CellModel cell) {
		((GridCell)cell).setco2( ((GridCell)cell).getco2() * Math.pow(0.9999, (int) (((GridCell)cell).getWater()/100)));
	}
	
}

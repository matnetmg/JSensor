package jsensor.runtime;

import java.util.Random;

import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.collections.EventsList;
import jsensor.nodes.collections.NodesList;
import jsensor.nodes.messages.Inbox;
import jsensor.nodes.messages.PacketsInTheAir;
import jsensor.utils.Configuration;
import jsensor.utils.RandomGenerator;


/**
 * This is the abstract class of the Runtime. This class should not be touched. It 
 * is used for internal porpuso only.
 * @author danniel
 */
public abstract class Runtime{

    protected long numberOfRounds = 0;
    protected long numberOfEventss = 0;

    protected long refreshRate = 1;
    protected volatile long roundsDone = 0;
    protected boolean abort = false;
    
    public AbstractNodesList[] myLists;
    protected RandomGenerator[] myRandom;
    protected RandomGenerator[] myRandomCell;
    protected ConcurrentNodesPositionHashMap sensorsHash;
    protected Node fakeNode = new Node() {
		
		@Override
		public void onCreation() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void handleMessages(Inbox inbox) {
			// TODO Auto-generated method stub
			
		}
	};
	

    protected PacketsInTheAir packetsInTheAir;
    public EventsList[] eventList;
	public AbstractNodesList[] nodesHash;


    public enum ThreadState {
        waiting,
        moving,
        rebuilding,
        findingNeighbours,
        reading_messages,
        steping_messages,
        steping_timer,
        steping_moviment,
        updatingFacts,
        updatingCells,
        updatingFactCells
    }

    public Runtime() {
    	fakeNode.setID(0);
        myLists = new NodesList[Configuration.numberOfChunks];
        eventList = new EventsList[Configuration.numberOfChunks];
        myRandom = new RandomGenerator[Configuration.numberOfChunks];
        myRandomCell = new RandomGenerator[Configuration.numberOfChunks];
        
        for(int i = 0; i < eventList.length; i++){
        	eventList[i] = new EventsList();
        }
        for(int i = 0; i< myLists.length; i++){
            myLists[i] = new NodesList();
        }
        
    	Random r  = new Random(Configuration.seedRandom);
        for(int i = 0; i< myRandom.length; i++){
        	myRandom[i] = new RandomGenerator(r.nextLong());
        }
        for(int i = 0; i< myRandomCell.length; i++){
        	myRandomCell[i] = new RandomGenerator(r.nextLong());
        }
        
    }
    
    public Node getFakeNode(){
    	return fakeNode;
    }

    public long getRoundsDone() {
        return roundsDone;
    }

    public void setRoundsDone(long roundsDone) {
        this.roundsDone = roundsDone;
    }

    public boolean hasNodes(){
        if(this.myLists == null)
            return false;
        
        int num = 0;

        for(AbstractNodesList nl: this.myLists){
            num+= nl.size();
        }

        return num!=0;
    }
    
    public Node getSensorByID(int id){
        for(AbstractNodesList nl: this.myLists){
            for(Node n:nl.getNodesList()){
                if(n.getID() == id)
                    return n;
            }
        }
        
        return null;
    }

    public ConcurrentNodesPositionHashMap getSensorsHash() {
        return sensorsHash;
    }

    public void setSensorsHash(ConcurrentNodesPositionHashMap sensorsHash) {
        this.sensorsHash = sensorsHash;
    }

    
    public int nodesSize(){
       int size = 0;
       for(AbstractNodesList nl: this.myLists){
            size+= nl.size();
       }

       return size;
    }

    public AbstractNodesList[] getMyLists() {
        return myLists;
    }
    
    public RandomGenerator getMyRamdom(int i){
    	return myRandom[i];
    } 
    
    public RandomGenerator getMyRamdomCell(int i){
    	return myRandomCell[i];
    }

    public void setMyLists(NodesList[] myLists) {
        this.myLists = myLists;
    }


    public long getNumberOfRounds() {
        return numberOfRounds;
    }

    public void setNumberOfRounds(long numberOfRounds) {
        this.numberOfRounds = numberOfRounds;
    }
    
    public PacketsInTheAir getPacketsInTheAir() {
        return packetsInTheAir;
    }

    public void setPacketsInTheAir(PacketsInTheAir packetsInTheAir) {
        this.packetsInTheAir = packetsInTheAir;
    }

    
    public boolean isAbort() {
        return abort;
    }

    public void setAbort(boolean abort) {
        this.abort = abort;
    }

    public long getRefreshRate() {
        return refreshRate;
    }

    public void setRefreshRate(long refreshRate) {
        this.refreshRate = refreshRate;
    }

    public EventsList[] getEventList() {
        return eventList;
    }

    public void removeNodes(){
        myLists = new NodesList[Configuration.numberOfChunks];
       
        for(int i = 0; i< myLists.length; i++){
            myLists[i] = new NodesList();
        }

        this.sensorsHash = new ConcurrentNodesPositionHashMap();
    }
    
    public void removeEvents(){
    	eventList = new EventsList[Configuration.numberOfChunks];
        
        for(int i = 0; i < eventList.length; i++){
        	eventList[i] = new EventsList();
        }
    }

    /**
     * This method determine how to run a simulation. This method is implemented
     * by AssynchronousRuntime and SynchronousRuntime.
     */
    public abstract void run();

}

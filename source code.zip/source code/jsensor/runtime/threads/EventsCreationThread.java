/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.runtime.threads;

import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.nodes.collections.EventsList;
import jsensor.nodes.events.EventModel;
import jsensor.nodes.models.DistributionModelEvent;
import jsensor.nodes.monitoring.Event;
import jsensor.nodes.monitoring.EventDefault;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime;
import jsensor.utils.Configuration;
import jsensor.utils.Position;
import jsensor.utils.TripleInt;

/**
 * This class implements the thread responsible to create the facts efficiently.
 * The set of all nodes to be created is divided into abstract sets and each FactsCreationThread
 * takes one of this lists and creates an instance of those nodes.
 * @author Matheus
 */
public class EventsCreationThread extends Thread{
	private int index;
	private int tripleIndex;
	private EventsList[] factsList;
	private TripleInt[] tripleList;
	private Runtime runtime;
    private DistributionModelEvent distribution;

    public EventsCreationThread(int index, int tripleIndex, TripleInt[] triple, EventsList[] factsList, Runtime runtime, DistributionModelEvent distributionModelFact) {
    	this.index = index;
    	this.tripleIndex = tripleIndex;
    	this.tripleList = triple;
    	this.factsList = factsList;
    	this.runtime = runtime;
    	this.distribution = distributionModelFact;
    }

    /**
     * The number of all facts to be created is divided equally for all NodesCreationThreads
     * and these number of nodes is instantiated by this method.
     * For a desired number of nodes, this method instantiate them and put into an AbstractNodesList.
     */
    @Override
    public void run() {
		TripleInt triple = tripleList[this.tripleIndex];
    	
		for(int i = triple.geta(); i < triple.getb(); i++){
			int chunks = triple.getc();
			
			EventModel assynchronousFact = null;
			Event event = null;
	        try {
	        	if(Configuration.assynchronousMode){
	        		try{
	        			event = new EventDefault();
		        		assynchronousFact = (EventModel) Configuration.factTypes[index].newInstance();
	        		}catch(ClassCastException ex){
	        			System.err.println("Simulations asynchronous facts should extend AbstractFactEvent.");
	        			Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        			System.exit(1);
	        		}
	        	}
	        	else{
	        		event = (Event) Configuration.factTypes[index].newInstance();
	        	}
	
	        } catch (InvocationTargetException ex) {
	            Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (IllegalArgumentException ex) {
	            Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (SecurityException ex) {
	            Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        }
	        
	        event.setID(i * Configuration.numberOfChunks + chunks);
	        event.setStart(Jsensor.currentTime+Configuration.factStarts[index]);
	        event.setDuration(event.getStart()+Configuration.factDurations[index]);
	        event.setRadius(Configuration.factRadius[index]);
            try{
            	 Position p = distribution.getPosition(event);
            	 event.setPosition(p);
            }catch(NullPointerException ex){
            	System.err.println("Your Distribution Model must return a not null Position. ");
    			Logger.getLogger(EventsCreationThread.class.getName()).log(Level.SEVERE, null, ex);
    			System.exit(1);
            }
            
            factsList[tripleIndex].addEvent(event);
            
            if(Configuration.assynchronousMode){
            	assynchronousFact.start(event, event.getStart(), event.getDuration(), Configuration.factSteps[index]);
            }
            else{
            	event.onCreation();
            }
    	} 
    	
    	if(Configuration.virtualThread)
    		if(tripleIndex == Integer.parseInt(Thread.currentThread().getName()))
    			runThread();
    }
    
    private void runThread(){
    	for(Object i : Configuration.threads[Integer.parseInt(Thread.currentThread().getName())]){
    		new EventsCreationThread(index, (int) i, tripleList, factsList, runtime, distribution).run();
    	}
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.runtime.threads;

import java.util.logging.Level;

import jsensor.Main;
import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.AbstractNodesPositionMatrix;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.collections.EventsList;
import jsensor.nodes.events.AbstractEvent;
import jsensor.nodes.monitoring.CellController;
import jsensor.nodes.monitoring.Event;
import jsensor.nodes.monitoring.HandleCells;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime.ThreadState;
import jsensor.threads.Consumer;

/**
 * This class represents the Consumer Thread of Assynchronous mode. Each second
 * of simulation this Thread is executed to perform a specific action. It can manage
 * the nodes in three diferent ways: using an array of NodesList, using an array of 
 * NodesMatrix or using a Map.
 * @author danniel
 */
public class AssynchronousConsumerCallable extends Consumer{

    private int indexToWrite;
    private AbstractNodesList[] myLists;
    private ThreadState myState;
    private long time;
    private ConcurrentNodesPositionHashMap nodesHash;
    private EventsList[] facts;

    public AssynchronousConsumerCallable(AbstractNodesList[] nl,EventsList[] f,int index,ThreadState state, long time, AbstractNodesPositionMatrix[] nodesMatrix) {
        this.indexToWrite = index;
        this.myLists = nl;
        this.myState = state;
        this.time = time;
        this.facts = f;
    }

    public AssynchronousConsumerCallable(AbstractNodesList[] nl,EventsList[] f,int index,ThreadState state, long time, AbstractNodesPositionMatrix nodesMatrix) {
        this.indexToWrite = index;
        this.myLists = nl;
        this.myState = state;
        this.time = time;
        this.facts = f;
    }
    
    public AssynchronousConsumerCallable(AbstractNodesList[] nl,EventsList[] f,int index,ThreadState state, long time, ConcurrentNodesPositionHashMap hash) {
        this.indexToWrite = index;
        this.myLists = nl;
        this.myState = state;
        this.time = time;
        this.nodesHash = hash;
        this.facts = f;
    }

    /**
     * For a given ThreadState, this method perform an action that can be 
     * wait,read message,find neighbours, update facts or perform the step phase.
     */
    
    
    @Override
	public Boolean call() throws Exception {
		
        switch(myState)
        {
            case reading_messages:
            {
                for(Node n:this.myLists[indexToWrite].getNodesList()){
                    try{
                    	n.handleMessages(n.getInbox().getInboxAtThisTime(time));
                    }catch(ClassCastException ex){
                    	System.err.println("There was a cast problem in your method handleMessages.");
                    	Main.LOG.log(Level.SEVERE, null, ex);
            			System.exit(1);
                    }
                    
                }
                break;
            }

           case findingNeighbours: 
           {
                
                for(Node n:this.myLists[indexToWrite].getNodesList()){
                    n.setNeighborhoodChange(n.getConectivityModel().updateConnection(n,nodesHash));
                }
                        
                break;
            }
               
           	case updatingFacts:
           	{
                for(Event f:this.facts[indexToWrite].getEventList()){
            		if(f.getDuration() < Jsensor.currentTime){
            			this.facts[indexToWrite].getEventList().remove(f);
            			continue;
            		}
            		f.step(time);                	
              
                }
                break;
           	}
           	
           	case updatingFactCells:
           	{
       			for(AbstractEvent ae : CellController.getCellChunk(indexToWrite).getEvents()){
       				ae.handle();
       			}
       			
                break;
           	}
           	
           	
           	case updatingCells:
           	{
       			for(HandleCells cellEvent : CellController.getCellsToSet(indexToWrite).getAllEvents()){
       				cellEvent.handle();
       			}
       			
                break;
           	}
           	
            case steping_messages:
            {
                for(Node n:this.myLists[indexToWrite].getNodesList())
                {
                   n.step(time, ThreadState.steping_messages);
                }
                break;
            }
            
            case steping_timer:
            {
                for(Node n:this.myLists[indexToWrite].getNodesList())
                {
                   n.step(time, ThreadState.steping_timer);
                }
               break;
            }

            case waiting:
            {
                break;
            }
            
            case steping_moviment:
            {
                for(Node n:this.myLists[indexToWrite].getNodesList())
                {
                   n.step(time, ThreadState.steping_moviment);
                }
                break;
            }
            
            default:
            	break;
        }
		return null;
    }

  

}

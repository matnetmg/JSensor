/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.runtime;

import java.util.LinkedList;
import jsensor.nodes.events.TimerEvent;

/**
 * This class represent the AbstractCustomGlobal that is used to manage 
 * the user's simulation. Each Custom Global should implement this class.
 * @author danniel
 */
public abstract class AbsCustomGlobal {

    private LinkedList<TimerEvent> globalTimers = new LinkedList<TimerEvent>();

    public LinkedList<TimerEvent> getGlobalTimers() {
        return globalTimers;
    }

    public void setGlobalTimers(LinkedList<TimerEvent> globalTimers) {
        this.globalTimers = globalTimers;
    }

    public void addGlobalTimer(TimerEvent t){
        this.globalTimers.add(t);
    }
    
    /**
     * This method is used to tell when a simulation has finished.
     * @return a boolean representing if the simulation finished or not.
     */
    public abstract boolean hasTerminated();
    
    /**
     * This method is executed before run a simulation. Implement this method
     * to specify what should happen before stars a simulation.
     */
    public abstract void preRun();
    
    /**
     * Implement this method to specify what should be executed before every 
     * round step.
     */
    public abstract void preRound();
    
    /**
     * Implement this method to specify what should be executed after every 
     * round step.
     */
    public abstract void postRound();
    
    /**
     * This method is executed after run a simulation. Implement this method
     * to specify what should happen after stars a simulation.
     */
    public abstract void postRun();

}

package jsensor;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import jsensor.models.DefaultMessageTransmissionModel;
import jsensor.models.GrideDistributionEvent;
import jsensor.models.GrideDistributionNode;
import jsensor.models.RandomDistributionEvent;
import jsensor.models.RandomDistributionNode;
import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.models.MessageTransmissionModel;
import jsensor.nodes.monitoring.CellController;
import jsensor.runtime.AbsCustomGlobal;
import jsensor.runtime.AssynchronousRuntime;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime;
import jsensor.threads.ListResource;
import jsensor.utils.Configuration;
import jsensor.utils.Configuration.StopBy;
import jsensor.utils.GenerateFilesOmnet;
import jsensor.utils.PropertiesLoader;

/**
 *
 * @author danniel
 */
public class Main {

	public static final Logger LOG = Logger.getLogger(Main.class.getName());
    protected String[] nodeType;
    protected int[] numNodes;
    protected String[] cModels;
    protected String[] mModels;
    protected String[] dModels;
    protected String[] factType;
    protected String[] fdModels;
    protected int[] numFacts;
    protected double[] fValues;
    protected double[] fstart;
    protected double[] fduration;
    protected int[] fradius;
    public static double time;
    synchronized
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	try{
    		
    		//start the log system
    		Handler console = new ConsoleHandler();
            Handler file = new FileHandler("log.txt",true);
            console.setLevel(Level.OFF);
            file.setLevel(Level.ALL);
            file.setFormatter(new SimpleFormatter());
            LOG.addHandler(file);
            LOG.addHandler(console);
            LOG.setUseParentHandlers(false);
    	    
    		time = System.currentTimeMillis();
            Main m = new Main();
            m.run(args);
    	}catch(Exception ex){
    		System.err.println("Sorry, an internal error occurred, contact the developers.");
    		System.err.println("jsensorsimulator@gmail.com");
    		LOG.log(Level.SEVERE, null, ex);
    		System.exit(1);
    	}
    }

    
    public void run(String[] args) {
    	try{
        
    	if(args.length > 0)
        {
    		Jsensor.msgsResourcee = new ListResource<String>();
    		
    		args = getValues(args[0]);
    		
        } else
        {
    		System.err.println("You need to pass a settings file.");
    		System.exit(1);
        }
        
    	
        //initImplementations();
    	Jsensor.startMesseges();
    	
    	//call the constructors 
    	new CellController(); 

    	argsParser(args);
        Runtime r = new AssynchronousRuntime();
        Jsensor.runtime = r;
        
        Configuration.threadLists();
        
        //creates the facts of simulation
        if (Configuration.factTypes != null){
        	for (int i = 0; i < Configuration.factTypes.length; i++) {
                Jsensor.genFacts(r, i);
            }
        }

        double time = 0.0;
        if(Configuration.log_debug)
        {
        	debugLog();
            System.out.println("[DEBUG] Starting the generation of the nodes");
            time = System.currentTimeMillis();
        }
        
        //ceates the gride of nodes
        ConcurrentNodesPositionHashMap hashMap = new ConcurrentNodesPositionHashMap();
        
        //creates the nodes of simulation
        for (int i = 0; i < Configuration.nodeTypes.length; i++) {
            Jsensor.genNodes(hashMap, r, i);
        }
        
        //call onCreate() method of every node
        for(AbstractNodesList list: Jsensor.runtime.getMyLists()){
        	for(Node node : list.getNodesList())
        	{   
        		node.onCreation();
        	}
        }
        
        //put the gride of nodes in runtime
        r.setSensorsHash(hashMap);
        
        if(Configuration.log_debug)
        {
        	double t = (System.currentTimeMillis() - time)/1000;
            Jsensor._criacaoNodes = t;
            Jsensor.log_debug("Generation of the nodes: " + t +" seconds");
            System.out.println("[DEBUG] End of generation of the nodes: " + t +" seconds");
        }
        
        Jsensor.customGlobal.preRun();
        System.out.println("\nSimulation running -- "+Configuration.numberOfThreads+" Threads\n");
        
        //run assynchronously
        r.run();
        Jsensor.customGlobal.postRun();
        
        if(Configuration.log_omnet == true){
            GenerateFilesOmnet.generateSensorsConnectionsPositions(Jsensor.runtime.getMyLists());
            GenerateFilesOmnet.generateStartNodes();
        }
    	}catch(Exception ex){
    		System.err.println("Sorry, an internal error occurred, contact the developers.");
    		System.err.println("jsensorsimulator@gmail.com");
    		LOG.log(Level.SEVERE, null, ex);
    		System.exit(1);
    	}    
    	Main.printInformations2();
    	
    }
    
    public static long bytesToMegabytes(long bytes) {
        return bytes / 1048576;
    }
                  
    public static void printInformations2(){
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();  
    	nf.setMinimumFractionDigits(2);  
    	nf.setMaximumFractionDigits(2);  
        
        double finalTime = System.currentTimeMillis() - Main.time;
        	
    	Jsensor.log_debug("time before: " + finalTime +" (ms) -- "+nf.format(finalTime/1000.0) +" (s) -- "+nf.format(finalTime/60000.0) +" (m) -- "+ nf.format(finalTime/3600000.0) +" (h)\n"+
    	"memory comsuption: "+java.lang.Runtime.getRuntime().totalMemory()/1000000 +" MB\n"+
    	"number of events: "+Jsensor.getNumberOfEvent());   
    }
    
    
    public static void printInformations(){
    	System.out.println("Simulation terminated\n");
    	// Get the Java runtime
        java.lang.Runtime runtime = java.lang.Runtime.getRuntime();
        runtime.gc();
        
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();  
    	nf.setMinimumFractionDigits(2);  
    	nf.setMaximumFractionDigits(2);  
        
        double finalTime = System.currentTimeMillis() - Main.time;
        
    	System.out.println("time: " + finalTime +" (ms) -- "+nf.format(finalTime/1000.0) +" (s) -- "+nf.format(finalTime/60000.0) +" (m) -- "+ nf.format(finalTime/3600000.0) +" (h)");
    	System.out.println("memory comsuption: "+bytesToMegabytes(runtime.totalMemory()) +" MB");   
    	System.out.println("number of events: "+Jsensor.getNumberOfEvent());   
    	System.out.println("number of cells: "+Configuration.numberofcells);   
    
    	Jsensor.log_debug("time: " + finalTime +" (ms) -- "+nf.format(finalTime/1000.0) +" (s) -- "+nf.format(finalTime/60000.0) +" (m) -- "+ nf.format(finalTime/3600000.0) +" (h)"+ "\n" +
    	"memory comsuption: "+java.lang.Runtime.getRuntime().totalMemory()/1000000 +" MB"+ "\n" +
    	"number of events: "+Jsensor.getNumberOfEvent());   
    	
    }
    
    private void debugLog(){
    	Jsensor.log_debug("Settings --------------------\n"+
    	"project Name: "+Configuration.projectName+ "\n" +
    	"dimX: "+Configuration.dimX+ "\n" +
    	"dimY: "+Configuration.dimY+ "\n" +
    	"cell Size: "+Configuration.cellSize+ "\n" +
    	"debug: "+Configuration.log_debug+ "\n" +
    	"log: "+Configuration.log_jsensor+ "\n" +
    	"seed Random: "+Configuration.seedRandom+ "\n" +
    	"number Of Threads: "+Configuration.numberOfThreads+ "\n" +
    	"number Of Chunks: "+Configuration.numberOfChunks+ "\n" +
    	"Mobility: "+Configuration.hasMobility+ "\n" +
    	"Facts: "+Configuration.hasFacts+ "\n");
    	if(Configuration.messageTransmissionModel != null)
			Jsensor.log_debug("Message Transmission Model: "+Configuration.messageTransmissionModel.getClass().getName());
    	
    	
    	for(int i = 0; i < Configuration.nodeTypes.length; i++){
    		Jsensor.log_debug("Sensor: "+Configuration.nodeTypes[i].getName()+ "\n" +
    		"Number: "+Configuration.numberNodes[i]+ "\n" +
    		"Distribution Model: "+Configuration.distributionModels[i].getName()+ "\n" +
    		"Connectivity Model: "+Configuration.connectivityModels[i].getName());
    		if(Configuration.mobilityModels[i] != null)
    			Jsensor.log_debug("Mobility Model: "+Configuration.mobilityModels[i].getName());
    		if(Configuration.reliabilityModels[i] != null)
    			Jsensor.log_debug("Reliabilty Model: "+Configuration.reliabilityModels[i].getName());
    		
    		Jsensor.log_debug("Node Radio: "+Configuration.nodeRadios[i]+ "\n" +
    		"Communication Radio: "+Configuration.communicationRadios[i]);
    	}
    	
    	
    	Jsensor.log_debug("-----------------------------\n\n\n");
    }

    public void argsParser(String[] args) {
    	try{
    	Configuration.applicationPath = getApplicationPath();
    	
        for (String arg : args){
        	
        	if(arg == null)
        		continue;
            StringTokenizer strtok = new StringTokenizer(arg, "=");
            String var = strtok.nextToken();
            String value = strtok.nextToken();

            if (var.equals("project_name")) {
            	String projectPath =  findDirectory(new File(Configuration.applicationPath), value);
            	if(projectPath != null){
            		Configuration.projectPath = projectPath;
            		Configuration.projectName = value;
                    continue;
                }else{
                	System.out.println("The project "+value+" doesn't exist");
            		System.exit(1);
                }
            }
            
            if (var.equals("width")) {
        		Configuration.dimX = checkIntegerPositive(var, value);
        		continue;
            }

            if (var.equals("height")) {
            	Configuration.dimY = checkIntegerPositive(var, value);
        		continue;
            }
            
            if (var.equals("assynchronous_mode")) {
            	Configuration.assynchronousMode = checkTrueOrFalse(var, value);
            	continue;
            }
            
            if (var.equals("debug")) {
            	Configuration.log_debug = checkTrueOrFalse(var, value);
            	continue;
            }
            
            if (var.equals("log_jsensor")) {
            	Configuration.log_jsensor = checkTrueOrFalse(var, value);
            	continue;
            }
            
            if (var.equals("log_user")) {
            	Configuration.log_user = checkTrueOrFalse(var, value);
            	continue;
            }
            
            if (var.equals("number_of_threads")) {
            	int threads = checkIntegerPositive(var, value);
            	if(threads > Configuration.numberOfChunks){
            		threads = java.lang.Runtime.getRuntime().availableProcessors();
            		System.err.println("WARNING! ");
            		System.out.println("The number of threads must be less than or equal to the number of processing cores.");
            		System.out.println("The number of threads was reduced to "+ threads+".");
            	}
            		
            	Configuration.numberOfThreads = threads;
                continue;
            }

            if (var.equals("rounds")) {
                Configuration.numberOfRounds = checkLongPositive(var, value);
                continue;
            }
            
            if (var.equals("seed_random")) {
            	Configuration.seedRandom = checkLongPositive(var, value);
                continue;
            }

            if (var.equals("refresh")) {
                Configuration.refreshRate = checkIntegerPositive(var, value);
                continue;
            }
            
            if (var.equals("stop_by")) {
            	if(value.equalsIgnoreCase("ALL")){
            		Configuration.stop_by = StopBy.ALL;
            		continue;
            	}else if(value.equalsIgnoreCase("messages")){
            		Configuration.stop_by = StopBy.messages;
            		continue;
            	}else if(value.equalsIgnoreCase("mobility")){
            		Configuration.stop_by = StopBy.mobility;
            		continue;
            	}
            	else{
            		System.err.println("[WARNING] Invalid option for stop_by, using the default stop by messages. Options are: message, mobility or all");
            		LOG.log(Level.SEVERE, "invalid option for stop_by, using the default stop by messages", "invalid option for stop_by, using the default stop by messages");
            	}
            }
            
            if (var.equals("my_cell")) {
            	try {
	            	Class<?> myCell = findClass(new File(Configuration.projectPath), value);
	            	
	            	if (myCell == null){
	            		System.out.println("the class "+value+" does not exist");
	            		System.exit(1);
	            	}
	            	
					Configuration.myCellConstructor = myCell.getConstructor();
					
				} catch (NoSuchMethodException | SecurityException ex) {
					LOG.log(Level.SEVERE, null, ex);
				}
                continue;
            }
            
            if (var.equals("message_transmission_model")) {
            	try {
	            	Class<?> messageTransmissionModel = findClass(new File(Configuration.projectPath), value);
	            	
	            	if (messageTransmissionModel == null){
	            		System.out.println("the class "+value+" does not exist");
	            		System.exit(1);
	            	}
	            	
					Configuration.messageTransmissionModel = (MessageTransmissionModel) messageTransmissionModel.getConstructor().newInstance();
					
				} catch (NoSuchMethodException | SecurityException ex) {
					LOG.log(Level.SEVERE, null, ex);
				}
                continue;
            }
            
            if (var.equals("cell_size")) {
                Configuration.cellSize = checkIntegerPositive(var, value);
                continue;
            }
            
            if (var.equals("node_implementation")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.nodeTypes = new Constructor<?>[size];
                Configuration.nodeNames = new String[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
	                	String s = strtok2.nextToken();
	            		Class<?> aux = findClass(new File(Configuration.projectPath), s);
	            		if (aux == null) {
	                        System.err.println("the node implementation "+s+" does not exist.");
	                        System.exit(0);
	                    }
            		
						Configuration.nodeTypes[i] = aux.getConstructor();
						Configuration.nodeNames[i] = s;
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }
            
            if (var.equals("node_radio")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.nodeRadios = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                        Configuration.nodeRadios[i] = checkIntegerPositive(var, strtok2.nextToken());
                        i++;
                }
                continue;
            }
            
            if (var.equals("communication_radio")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.communicationRadios = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                        Configuration.communicationRadios[i] = checkIntegerPositive(var, strtok2.nextToken());
                        i++;
                }
                if(Configuration.cellSize == 0){
                	int lowerRadio = Configuration.communicationRadios[0];
                	for(int j = 1; j < Configuration.communicationRadios.length; j++){
                		if(Configuration.communicationRadios[j] < lowerRadio)
                			lowerRadio = Configuration.communicationRadios[j];
                	}
                	Configuration.cellSize = lowerRadio;
                }
                continue;
            }
            
            if (var.equals("connectivity_model")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.connectivityModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
                		String s = strtok2.nextToken();
                		Class<?> aux = findClass(new File(Configuration.projectPath), s);
                		if (aux == null) {
                            System.err.println("the conectivity model "+s+" does not exist.");
                            System.exit(0);
                        }
                		
                		Configuration.connectivityModels[i] = aux.getConstructor();
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }
            
            if (var.equals("interference_model")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.interferenceModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
                		String s = strtok2.nextToken();
                		
                		if(s.equalsIgnoreCase("null")){
                			Configuration.interferenceModels[i] = null;
                			continue;
                		}
                		Class<?> aux = findClass(new File(Configuration.projectPath), s);
                		if (aux == null) {
                            System.err.println("the interference model "+s+" does not exist.");
                            System.exit(0);
                        }
                		
                		Configuration.interferenceModels[i] = aux.getConstructor();
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }
            
            if (var.equals("reliability_model")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.reliabilityModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
                		String s = strtok2.nextToken();
                		
                		if(s.equalsIgnoreCase("null")){
                			Configuration.reliabilityModels[i] = null;
                			continue;
                		}
                		Class<?> aux = findClass(new File(Configuration.projectPath), s);
                		if (aux == null) {
                            System.err.println("the reliability model "+s+" does not exist.");
                            System.exit(0);
                        }
                		
                		Configuration.reliabilityModels[i] = aux.getConstructor();
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }
            

            if (var.equals("distribuition_model")) {
            	StringTokenizer strtok2 = new StringTokenizer(value, ",");
            	int size = strtok2.countTokens();
                Configuration.distributionModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
                        String s = strtok2.nextToken();
                        
                        if(s.equalsIgnoreCase("gride")){
                        	Configuration.distributionModels[i] = GrideDistributionNode.class.getConstructor(int.class, int.class);
                        }else if(s.equalsIgnoreCase("random")){
                        	Configuration.distributionModels[i] = RandomDistributionNode.class.getConstructor();
                        }else{
	                        Class<?> aux = findClass(new File(Configuration.projectPath), s);
	                        if (aux == null) {
	                            System.err.println("the distribuition model "+s+" does not exist.");
	                            System.exit(0);
	                        }
	                        
							Configuration.distributionModels[i] = aux.getConstructor();
                        }
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
            	continue;
            }
 
            if (var.equals("mobility_model")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.mobilityModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
	                    String s = strtok2.nextToken();
	                    
	                    if(Configuration.assynchronousMode){
	                    	Configuration.mobilityModels[i] = null;
	                    }else{
		                    Class<?> aux = findClass(new File(Configuration.projectPath), s);
		                    if (aux == null) {
		                        System.err.println("the mobility model "+s+" does not exist.");
		                        System.exit(0);
		                    }
		                    
							Configuration.mobilityModels[i] = aux.getConstructor();
							Configuration.hasMobility = true;
	                    }
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }

            if (var.equals("nodes")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.numberNodes = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                    Configuration.numberNodes[i] = Integer.parseInt(strtok2.nextToken());
                    i++;
                }
                continue;
            }
            
            if (var.equals("fact_implementation")){
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factTypes = new Constructor<?>[size];
                Configuration.factNames = new String[size];
                int i = 0;
                while (strtok2.hasMoreTokens()){
                	try{
                		String s = strtok2.nextToken();
	            		Class<?> aux = findClass(new File(Configuration.projectPath), s);
	            		if (aux == null) {
	                        System.err.println("the fact implementation "+s+" does not exist.");
	                        System.exit(0);
	                    }
            		
						Configuration.factTypes[i] = aux.getConstructor();
						Configuration.factNames[i] = s;
						Configuration.hasFacts = true;
                	}catch (NoSuchMethodException | SecurityException ex) {
                		LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
                continue;
            }
           
            if (var.equals("fact_distribuition_model")) {
            	StringTokenizer strtok2 = new StringTokenizer(value, ",");
            	int size = strtok2.countTokens();
                Configuration.factDistributionModels = new Constructor<?>[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	try {
                        String s = strtok2.nextToken();
                        
                        if(s.equalsIgnoreCase("gride")){
                        	Configuration.factDistributionModels[i] = GrideDistributionEvent.class.getConstructor(int.class, int.class);
                        }else if(s.equalsIgnoreCase("random")){
                        	Configuration.factDistributionModels[i] = RandomDistributionEvent.class.getConstructor();
                        }else{
	                        Class<?> aux = findClass(new File(Configuration.projectPath), s);
	                        if (aux == null) {
	                            System.err.println("the distribuition model "+s+" does not exist.");
	                            System.exit(0);
	                        }
	                        
							Configuration.factDistributionModels[i] = aux.getConstructor();
                        }
                        
					} catch (NoSuchMethodException | SecurityException ex) {
						LOG.log(Level.SEVERE, null, ex);
					}
                    i++;
                }
            	continue;
            }

            if (var.equals("fact_start_value")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factStartValues = new float[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	String token = strtok2.nextToken();
                	if(token.equalsIgnoreCase("null")){
                		if(!Configuration.assynchronousMode){
                			System.out.println("you need to define the field fact_start_value");
                    		System.exit(1);
                		}
                	}else{
                		Configuration.factStartValues[i] = checkFloatPositive(var, token);
                        i++;
                	}
                }
                continue;
            }
            
            if (var.equals("fact_step")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factSteps = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                	if(value.equalsIgnoreCase("null")){
                		if(Configuration.assynchronousMode){
                			System.out.println("you need to define the field fact_step");
                    		System.exit(1);
                		}
                	}
                	
                    Configuration.factSteps[i] = checkIntegerPositive(var, strtok2.nextToken());
                    i++;
                }
                continue;
            }

            if (var.equals("facts")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.numberFacts = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                    Configuration.numberFacts[i] = checkIntegerPositive(var, strtok2.nextToken());
                    i++;
                }
                continue;
            }
            
            if (var.equals("fact_radius")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factRadius = new int[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                    Configuration.factRadius[i] = checkIntegerPositive(var, strtok2.nextToken());
                    i++;
                }
                continue;
            }

            if (var.equals("fact_start")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factStarts = new float[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                    Configuration.factStarts[i] = checkFloatPositive(var, strtok2.nextToken());
                    i++;
                }
                continue;
            }

            if (var.equals("fact_duration")) {
                StringTokenizer strtok2 = new StringTokenizer(value, ",");
                int size = strtok2.countTokens();
                Configuration.factDurations = new float[size];
                int i = 0;
                while (strtok2.hasMoreTokens()) {
                    Configuration.factDurations[i] = checkFloatPositive(var, strtok2.nextToken());
                    i++;
                }
                continue;
            }
        }
        
        if(Configuration.messageTransmissionModel == null){
        	Configuration.messageTransmissionModel = new DefaultMessageTransmissionModel();
        }
        
        try {
        	
            Class<?> cGlobal = findClass(new File(Configuration.projectPath) , "CustomGlobal");
            Constructor<?> constructor = cGlobal.getConstructor();
            Jsensor.customGlobal = (AbsCustomGlobal) constructor.newInstance();
        } catch (InstantiationException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (InvocationTargetException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (NoSuchMethodException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
        	LOG.log(Level.SEVERE, null, ex);
        } catch (NullPointerException e) {
            System.err.println("Problem with CustomGlobal class");
            LOG.log(Level.SEVERE, null, e);
            System.exit(1);
		}
    	}catch(Exception ex){
            System.err.println("Sorry, an internal error occurred, contact the developers.");
            System.err.println("jsensorsimulator@gmail.com");
            LOG.log(Level.SEVERE, null, ex);
            System.exit(1);
        }    
    }
    
    private int checkIntegerPositive(String param, String value){
    	try{
    	if(!value.matches("[0-9]*")){
    		System.out.println("The field "+param+" must be a number greater than zero");
    		System.exit(1);
    	}
    	}catch(Exception ex){
            System.err.println("Sorry, an internal error occurred, contact the developers.");
            System.err.println("jsensorsimulator@gmail.com");
            LOG.log(Level.SEVERE, null, ex);
            System.exit(1);
        }
    	int number = Integer.parseInt(value);
    	
    	return number;
    	
    }
    
    private long checkLongPositive(String param, String value){
    	if(!value.matches("-?[0-9]*")){
    		System.out.println("The field "+param+" must be a number");
    		System.exit(1);
    	}
    	
    	long number = Long.parseLong(value);
    	if(number < 0){
    		System.out.println("The field "+param+" must be greater than zero");
    		System.exit(1);
    	}
    	return number;
    }
    
    private float checkFloatPositive(String param, String value){
    	try{
    	if(!value.matches("\\d*(\\.\\d+)?")){
    		System.out.println("The field "+param+" must be a number greater than zero");
    		System.exit(1);
    	}
    	}catch(Exception ex){
            System.err.println("Sorry, an internal error occurred, contact the developers.");
            System.err.println("jsensorsimulator@gmail.com");
            LOG.log(Level.SEVERE, null, ex);
            System.exit(1);
        }
    	float number = Float.parseFloat(value);
    	return number;
    }
    
	private boolean checkTrueOrFalse(String param, String value){
		boolean bool = false;
	    if(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")){
			bool = Boolean.parseBoolean(value);
		}else{
			System.out.println("The field "+param+" must be true or false");
			System.exit(1);
		}
		return bool;
	}
	
	
    public static void initImplementations() {
    	try{
        Jsensor.directoryPath = getApplicationPath();

        List<String> distModels = new ArrayList<String>();
        List<String> mobModels = new ArrayList<String>();
        List<String> connModels = new ArrayList<String>();
        List<String> nodesImpl = new ArrayList<String>();
        List<String> factsImpl = new ArrayList<String>();
        
        final String path = findDirectory(new File(Jsensor.directoryPath), "projects");
        File file = new File(path);
        
        String[] projects = file.list(new FilenameFilter() {

            @Override
            public boolean accept(File dir, String name) {

                if(name.startsWith(".")) return false;
                if(name.equals("defaultProject")) return false;
                File compiledFolder = new File(path + "/" + name);
                 
                if (compiledFolder.exists() && compiledFolder.isDirectory()) {
                    return true;
                }
                return false;
            }
        });

        Jsensor.projects = projects;

        //Distribution Models
      
        for (String project : projects) {
            file = new File(path + "/" + project + "/DistributionModels");

            final String pr = project;
            String[] models = file.list(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {
                    
                    File compiledFolder = new File(path + "/" + pr + "/DistributionModels/" + name);
                   
                    if (compiledFolder.exists()) {
                        return true;
                    }
                    return false;
                }
            });

            for (String m : models) {
                if(m.startsWith(".")) continue;
                m = m.replace(".java", "");
                m = m.replace(".class", "");
                distModels.add(project + ":" + m);
            }

        }

        Jsensor.distributionModels = new String[distModels.size()];

        int i = 0;
        for (String models : distModels) {
            Jsensor.distributionModels[i++] = models;
        }

        //Mobility Models
        for (String project : projects) {
            file = new File(path + "/" + project + "/MobilityModels");

            final String pr = project;
            String[] models = file.list(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {

                    File compiledFolder = new File(path + "/" + pr + "/MobilityModels/" + name);
                    if (compiledFolder.exists()) {
                        return true;
                    }
                    return false;
                }
            });

            for (String m : models) {
                if(m.startsWith(".")) continue;
                m = m.replace(".java", "");
                m = m.replace(".class", "");
                mobModels.add(project + ":" + m);
            }

        }

        Jsensor.mobilityModels = new String[mobModels.size()];

        i = 0;
        for (String models : mobModels) {
            Jsensor.mobilityModels[i++] = models;
        }

        //Connectivity Models
        for (String project : projects) {
            file = new File(path + "/" + project + "/ConnectivityModels");

            final String pr = project;
            String[] models = file.list(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {

                    File compiledFolder = new File(path + "/" + pr + "/ConnectivityModels/" + name);
                    if (compiledFolder.exists()) {
                        return true;
                    }
                    return false;
                }
            });

            for (String m : models) {
                if(m.startsWith(".")) continue;
                m = m.replace(".java", "");
                m = m.replace(".class", "");
                connModels.add(project + ":" + m);
            }

        }

        Jsensor.connectivityModels = new String[connModels.size()];

        i = 0;
        for (String models : connModels) {
            Jsensor.connectivityModels[i++] = models;
        }

        //Nodes Implementation
        for (String project : projects) {
            file = new File(path + "/" + project + "/Nodes/NodeImplementation");

            final String pr = project;
            String[] models = file.list(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {

                    File compiledFolder = new File(path + "/" + pr + "/Nodes/NodeImplementation/" + name);
                    if (compiledFolder.exists()) {
                        return true;
                    }
                    return false;
                }
            });

            for (String m : models) {
                if(m.startsWith(".")) continue;
                m = m.replace(".java", "");
                m = m.replace(".class", "");
                nodesImpl.add(project + ":" + m);
            }

        }

        Jsensor.nodesImplementation = new String[nodesImpl.size()];

        i = 0;
        for (String models : nodesImpl) {
            Jsensor.nodesImplementation[i++] = models;
        }




        //Nodes Facts
        for (String project : projects) {
            file = new File(path + "/" + project + "/Nodes/Facts");

            final String pr = project;
            String[] models = file.list(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {

                    File compiledFolder = new File(path + "/" + pr + "/Nodes/Facts/" + name);


                    if (compiledFolder.exists()) {
                        return true;
                    }
                    return false;
                }
            });

            for (String m : models) {
                if(m.startsWith(".")) continue;
                m = m.replace(".java", "");
                m = m.replace(".class", "");
                factsImpl.add(project + ":" + m);
            }

        }

        Jsensor.factsImplementation = new String[factsImpl.size()];

        i = 0;
        for (String facts : factsImpl) {
            Jsensor.factsImplementation[i++] = facts;
        }
    	}catch(Exception ex){
            System.err.println("Sorry, an internal error occurred, contact the developers.");
            System.err.println("jsensorsimulator@gmail.com");
            LOG.log(Level.SEVERE, null, ex);
            System.exit(1);
        }
    }
    
    
    //M�todo que faz a leitura do arquivo de configura��es. Retorna um List contendo as mesmas.
    private static String[] getValues(String file){
    	String[] args = new String[31];
        PropertiesLoader propertiesLoader = null;
        String propertie = null;
        try
        {
        	//carrega o arquivo usando a classe properties
        	if(file.contains("config"))
        		propertiesLoader = new PropertiesLoader(file);
        	else
        		propertiesLoader = new PropertiesLoader(file+".config");
        	
        	//l� o campo nome do projeto
        	propertie = propertiesLoader.getValor("project_name");
            if(propertie == null || propertie.isEmpty()){
                System.err.println("field project_name invalid");
                System.exit(1);
            }else{
            	args[0] = "project_name="+ propertie;
            }
            
            //l� o campo width
            propertie = propertiesLoader.getValor("width");
            if(propertie == null || propertie.isEmpty()){
                System.err.println("field width invalid");
                System.exit(1);
            } else{
            	args[1] = "width="+ propertie;
            }
            
            //l� o campo height
            propertie = propertiesLoader.getValor("height");
            if(propertie == null || propertie.isEmpty()){
                System.err.println("field height invalid");
                System.exit(1);
            } else{
            	args[2] = "height="+ propertie;
            }
            
            //l� o campo assynchronous_mode
            propertie = propertiesLoader.getValor("assynchronous_mode");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field assynchronous_mode invalid");
                    System.exit(1);
                } else{
                	args[3] = "assynchronous_mode="+ propertie;
            	}
            	if(propertie.equalsIgnoreCase("false")){
            		System.err.println("Synchronous mode is not available in this release.");
                    System.exit(1);
            	}
            }
            
            //l� o campo debug_mode
            propertie = propertiesLoader.getValor("debug");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field debug invalid");
                    System.exit(1);
                } else{
                	args[4] = "debug="+ propertie;
            	}
            }
                
            //l� o campo log
            propertie = propertiesLoader.getValor("log_jsensor");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field log invalid");
                    System.exit(1);
                } else{
                	args[5] = "log_jsensor="+ propertie;
            	}
            }
            
            //l� o campo log
            propertie = propertiesLoader.getValor("log_user");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field log invalid");
                    System.exit(1);
                } else{
                	args[6] = "log_user="+ propertie;
            	}
            }
            
            
            //l� o campo number_of_threads
            propertie = propertiesLoader.getValor("number_of_threads");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field number_of_threads invalid");
                    System.exit(1);
                } else{
                	args[7] = "number_of_threads="+ propertie;
                }
            }
            
            //l� o campo rounds
            propertie = propertiesLoader.getValor("rounds");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field rounds invalid");
                    System.exit(1);
                } else{
                	args[8] = "rounds="+ propertie;
                }
            }
                
            //l� o campo seed_random
            propertie = propertiesLoader.getValor("seed_random");
            if(propertie != null){ 
            	if(propertie.isEmpty()){
            		System.err.println("field seed_random invalid");
            		System.exit(1);
            	} else{
            		args[9] = "seed_random="+ propertie;
            	}
            }
            
            //l� o campo my_cell
            propertie = propertiesLoader.getValor("my_cell");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field my_cell invalid");
                    System.exit(1);
                } else{
                	args[10] = "my_cell="+ propertie;
            	}
            }
            
          //l� o campo cell_size
            propertie = propertiesLoader.getValor("cell_size");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field cell_size invalid");
                    System.exit(1);
                } else{
                	args[11] = "cell_size="+ propertie;
            	}
            }
            
          //l� o campo stop_by
            propertie = propertiesLoader.getValor("stop_by");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field stop_by invalid");
                    System.exit(1);
                } else{
                	args[12] = "stop_by="+ propertie;
            	}
            }
            
  
            //l� o campo message_transmission_model
            propertie = propertiesLoader.getValor("message_transmission_model");
            if(propertie != null){
            	if(propertie.isEmpty()){
            		System.err.println("field message_transmission_model invalid");
                    System.exit(1);
                } else{
                	args[13] = "message_transmission_model="+ propertie;
            	}
            }
          
                
            
            //l� os n�s e seus modelos
            int id = 0;
            boolean first = true;
            
            while(true){
            	
            	//l� os campo nodes
            	String nodes = propertiesLoader.getValor("nodes["+id+"]");
                if(nodes == null){
                	if(id == 0){
                		System.err.println("field nodes["+id+"] invalid");
                        System.exit(1);
                	}
                	break;
                }else if(nodes.isEmpty()){
                	System.err.println("field nodes["+id+"] invalid");
                    System.exit(1);
                }
                
              //l� o campo node_radio
                String node_radio = propertiesLoader.getValor("node_radio["+id+"]");
                if(node_radio != null){
                	if(node_radio.isEmpty()){
                		System.err.println("field node_radio["+id+"] invalid");
                        System.exit(1);
                    } 
                }
                    
                
              //l� o campo communication_radio
                String communication_radio = propertiesLoader.getValor("communication_radio["+id+"]");
                if(communication_radio == null || communication_radio.isEmpty()){
                    System.err.println("field communication_radio["+id+"] invalid");
                    System.exit(1);
                }
                
                //l� o campo distribuition_model
                String distribuition_model = propertiesLoader.getValor("distribuition_model["+id+"]");
                if(distribuition_model == null || distribuition_model.isEmpty()){
                    System.err.println("field distribuition_model["+id+"] invalid");
                    System.exit(1);
                }
                
                //l� o campo node_implementation
                String node_implementation = propertiesLoader.getValor("node_implementation["+id+"]");
                if(node_implementation == null || node_implementation.isEmpty()){
                    System.err.println("field node_implementation["+id+"] invalid");
                    System.exit(1);
                }
                
                //l� o campo connectivity_model
                String connectivity_model = propertiesLoader.getValor("connectivity_model["+id+"]");
                if(connectivity_model == null || connectivity_model.isEmpty()){
                    System.err.println("field connectivity_model["+id+"] invalid");
                    System.exit(1);
                }
                
                //l� o campo reliability_model
                String reliability_model = propertiesLoader.getValor("reliability_model["+id+"]");
                if(reliability_model != null){
                	if(reliability_model.isEmpty()){
                		System.err.println("field reliability_model["+id+"] invalid");
                        System.exit(1);
                	}
                }
                
                //l� o campo interference_model
                String interference_model = propertiesLoader.getValor("interference_model["+id+"]");
                if(interference_model != null){
                	if(interference_model.isEmpty()){
                		System.err.println("field interference_model["+id+"] invalid");
                        System.exit(1);
                	}
                }
                    
                
                //l� o campo mobility_model
                String mobility_model = propertiesLoader.getValor("mobility_model["+id+"]");
                if(mobility_model != null){
                	if(mobility_model.isEmpty()){
                		System.err.println("field mobility_model["+id+"] invalid");
                        System.exit(1);
                	}
                }
                
                if(first){
                	args[14] = "nodes="+ nodes;
                    args[15] = "distribuition_model="+ distribuition_model;
                    args[16] = "node_radio="+ node_radio;
                    args[17] = "communication_radio="+ communication_radio;
                    args[18] = "node_implementation="+ node_implementation;
                    args[19] = "connectivity_model="+ connectivity_model;
                    args[20] = "reliability_model="+ reliability_model;
                    args[21] = "interference_model="+ interference_model;
                    args[22] = "mobility_model="+ mobility_model;
                    
                }else{
                	args[14] += ","+ nodes;
                    args[15] += ","+ distribuition_model;
                    args[16] += ","+ node_radio;
                    args[17] += ","+ communication_radio;
                    args[18] += ","+ node_implementation;
                    args[19] += ","+ connectivity_model;
                    args[20] += ","+ reliability_model;
                    args[21] += ","+ interference_model;
                    args[22] += ","+ mobility_model;
                }
                id++;
                first = false;
            }
            id = 0;
            first  = true;
           
            while(true){
            	String facts = propertiesLoader.getValor("facts["+id+"]");
                if(facts == null){
                	break;
                }else if(facts.isEmpty()){
                	System.err.println("field facts["+id+"] invalid");
                	System.exit(1);
                }
                 	
 	        	String fact_distribuition_model = propertiesLoader.getValor("fact_distribuition_model["+id+"]");
 	            if(fact_distribuition_model == null || fact_distribuition_model.isEmpty()){
 	                System.err.println("field fact_distribuition_model["+id+"] invalid");
 	                System.exit(1);
 	            }
 	            
 	            String fact_implementation = propertiesLoader.getValor("fact_implementation["+id+"]");
 	            if(fact_implementation == null || fact_implementation.isEmpty()){
 	                System.err.println("field fact_implementation["+id+"] invalid");
 	                System.exit(1);
 	            }
 	            
 	            String fact_start = propertiesLoader.getValor("fact_start["+id+"]");
 	            if(fact_start == null || fact_start.isEmpty()){
 	                System.err.println("field fact_start["+id+"] invalid");
 	                System.exit(1);
 	            } 	            
 	            
 	            String fact_duration = propertiesLoader.getValor("fact_duration["+id+"]");
 	            if(fact_duration == null || fact_duration.isEmpty()){
 	                System.err.println("field fact_duration["+id+"] invalid");
 	                System.exit(1);
 	            } 
 	            
 	            String fact_start_value = propertiesLoader.getValor("fact_start_value["+id+"]");
 	            if(fact_start_value != null){
	            	if(fact_start_value.isEmpty()){
	            		System.err.println("field fact_start_value["+id+"] invalid");
				        System.exit(1);
				   	}
				}
 	            
 	            String fact_radius = propertiesLoader.getValor("fact_radius["+id+"]");
 	            if(fact_radius == null || fact_radius.isEmpty()){
 	                System.err.println("field fact_radius["+id+"] invalid");
 	                System.exit(1);
 	            }
 	            
 	            String fact_step = propertiesLoader.getValor("fact_step["+id+"]");
 	            if(fact_step != null){
 	            	if(fact_step.isEmpty()){
 	            		System.err.println("field fact_step["+id+"] invalid");
				        System.exit(1);
				   	}
				}
 	            
 	            if(first){
 	            	args[23] = "facts="+ facts;
 	                args[24] = "fact_distribuition_model="+ fact_distribuition_model;
 	                args[25] = "fact_implementation="+ fact_implementation;
 	                args[26] = "fact_start="+ fact_start;
 	                args[27] = "fact_duration="+ fact_duration;
 	                args[28] = "fact_start_value="+ fact_start_value;
 	                args[29] = "fact_radius="+ fact_radius;
 	                args[30] = "fact_step="+ fact_step;
 	            }else{
	 	            args[23] += ","+ facts;
	 	            args[24] += ","+ fact_distribuition_model;
	 	            args[25] += ","+ fact_implementation;
	 	            args[26] += ","+ fact_start;
	 	            args[27] += ","+ fact_duration;
	 	            args[28] += ","+ fact_start_value;
	 	            args[29] += ","+ fact_radius;
	 	            args[30] += ","+ fact_step;
 	            }
 	           first = false;
 	           id++;
            }
        }
        catch(IOException ex){
            System.out.println("Invalid File");
            LOG.log(Level.SEVERE, null, ex);
            System.exit(1);
        }
        
        return args;
    }
    
    public static Class<?> findClass(File initialPath, String file)
    {
    	Class<?> myClass = null;
        if(initialPath.exists())
        {
            File contents[] = initialPath.listFiles();
            for(int i = 0; i < contents.length; i++)
            {
            	if(contents[i].getName().equals(file+".class"))
                {
            		try {
	            		String name = contents[i].getAbsolutePath();
	            		if(name.lastIndexOf("projects") == -1){
	            			System.err.println("You need a project folder");
    			    		System.exit(1);
	            		}
	            		name = name.substring(name.lastIndexOf("projects"), name.lastIndexOf(".class"));
	            		name = name.replace("\\", ".");
	            		name = name.replace("/", ".");
						myClass = Class.forName(name);
					} catch (ClassNotFoundException ex) {
						System.err.println("Sorry, an internal error occurred, contact the developers.");
			    		System.err.println("jsensorsimulator@gmail.com");
			    		LOG.log(Level.SEVERE, null, ex);
			    		System.exit(1);
					}
            	
                }else{
                	if(contents[i].getName().equals(file+".java"))
                    {
                		try {
    	            		String name = contents[i].getAbsolutePath();
    	            		name = name.substring(name.lastIndexOf("projects"), name.lastIndexOf(".java"));
    	            		name = name.replace("\\", ".");
    	            		name = name.replace("/", ".");
    						myClass = Class.forName(name);
    					} catch (ClassNotFoundException ex) {
    						System.err.println("You need to pass a '.class' file.");
    			    		LOG.log(Level.SEVERE, null, ex);
    			    		System.exit(1);
    					}
                    }
                }
            	
                if(contents[i].isDirectory())
                {
                	myClass = findClass(contents[i], file);
                }
                
                if(myClass !=null)
                	return myClass;
            }
        }
        return myClass;
    }
    
    public static String findDirectory(File initialPath, String directory)
    {
    	String path = null;
        if(initialPath.exists())
        {
            File contents[] = initialPath.listFiles();
            for(int i = 0; i < contents.length; i++)
            {
                if(!contents[i].isDirectory())
                {
                    continue;
                }
                if(contents[i].getName().equalsIgnoreCase(directory))
                {
                    path = contents[i].getAbsolutePath();
                    break;
                }
              
                path = findDirectory(contents[i], directory);
                if(path !=null)
                	return path;
            }
        }
        return path;
    }
    
    public static String getApplicationPath() 
    {  
    	String caminho = null;
		try {
			caminho = Main.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}    
        caminho = caminho.substring(0, caminho.lastIndexOf('/')); 
        if((caminho.substring(caminho.lastIndexOf('/')).equalsIgnoreCase("/bin")))
        {
        	caminho = caminho.substring(0, caminho.lastIndexOf('/'));
        }
        if((caminho.substring(caminho.lastIndexOf('/')).equalsIgnoreCase("/lib")))
        {
        	caminho = caminho.substring(0, caminho.lastIndexOf('/'));
        }
        
        return caminho; 
     }  
}

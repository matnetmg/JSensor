package jsensor.threads;

import java.io.BufferedWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.utils.Configuration;
import jsensor.utils.Writer;

/**
 *
 * @author Matheus
 */
public class LogConsumer extends Thread {

    private ListResource<String> resource;
    private static Writer writer;
    private static BufferedWriter file;
    private static BufferedWriter fileUser;
    private static BufferedWriter fileDebug;

    public LogConsumer(ListResource<String> resource) {
        this.resource = resource;
        writer = new Writer("Results");
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy-HHmmss");  
	    
        try {
        	Configuration.dateName = sdf.format(new Date());
        	if(Configuration.log_jsensor)
				file = writer.fileWriter("log-" + Configuration.dateName);
			if(Configuration.log_user)
				fileUser = writer.fileWriter("userLog-" + Configuration.dateName);
			if(Configuration.log_debug)
				fileDebug = writer.fileWriter("debugLog-" + Configuration.dateName);
		} catch (IOException e) {
			Logger.getLogger(LogConsumer.class.getName()).log(Level.SEVERE, null, e);
		}
    }
    
    public void close()
    {
    	try {
    		if(Configuration.log_jsensor){
    			file.flush();
    			file.close();
    		}
			if(Configuration.log_user){
				fileUser.flush();
				fileUser.close();
			}
			if(Configuration.log_debug){
				fileDebug.flush();
				fileDebug.close();
			}
		} catch (IOException e) {
			Logger.getLogger(LogConsumer.class.getName()).log(Level.SEVERE, null, e);
		}
    }
    
    //This code is for realeases
    @Override  
    public void run() {
        
        String str = null;

        while ((resource.isFinished() == false) || (resource.getNumOfRegisters() != 0)) {
            try {
                if ((str = resource.getRegister()) != null) 
                {
                	if(str.startsWith("#")){
                		writer.LogMsg(file, str.substring(1) + "\n");
                	}
                	else if(str.startsWith("$")){
                		writer.LogMsg(fileUser, str.substring(1) + "\n");
                	}
                	else{               		
                		writer.LogMsg(fileDebug, str + "\n");
                	}      	
                }
            } catch (Exception ex) {
                Logger.getLogger(LogConsumer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
 }

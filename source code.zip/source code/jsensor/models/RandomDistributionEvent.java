package jsensor.models;


import jsensor.nodes.models.DistributionModelEvent;
import jsensor.nodes.monitoring.Event;
import jsensor.utils.Configuration;
import jsensor.utils.Position;

/**
 *
 * @author Matheus
 */
public class RandomDistributionEvent extends DistributionModelEvent
{
	@Override
	public Position getPosition(Event f) {
		return new Position(f.getRandom().nextInt(Configuration.dimX), f.getRandom().nextInt(Configuration.dimY));
	}
}

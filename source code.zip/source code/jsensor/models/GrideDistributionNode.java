package jsensor.models;

import java.util.Hashtable;
import java.util.LinkedList;

import jsensor.nodes.Node;
import jsensor.nodes.models.DistributionModelNode;
import jsensor.runtime.Jsensor;
import jsensor.utils.Position;

/**
 *
 * @author Matheus
 */
public class GrideDistributionNode extends DistributionModelNode
{
	LinkedList<Node> as = new LinkedList<Node>();
	Hashtable<Integer, Position> position = new Hashtable<>();
	long dimX, dimY, area, size, startX, startY, linesX, linesY, countX, countY;
	
	public GrideDistributionNode(int start, int numNodes)
	{
		
    	dimX = Jsensor.getDimX();
    	dimY = Jsensor.getDimY();
    	area = dimX * dimY;
    	countX = 1;
    	countY = 1;
    	
    	//obtenho o valor da área por sensor
    	size = (long) Math.floor( Math.sqrt(area/ numNodes));
    	startX = size;
    	startY = size;
    	
    	//obtenho quantas divisões terá cada dimensão
    	linesX = dimX / size;
    	linesY = dimY / size;
    	
    	//caso com essas divisões não se chegue ao número de nodes, aumento
    	if(linesX * linesY < numNodes){
    		startY = (int)((dimY - (linesY * size))/2);
    		linesY ++;		
    	}
    	if(linesX * linesY < numNodes){
    		startX = (int)((dimX - (linesX * size))/2);
    		linesX ++;		
    	}
    	dimX = startX;
    	dimY = startY;
    	
    	distribuition(start, numNodes);
	}
	
	private void distribuition(int start, int numNodes){
		for(int i = start; i < start + numNodes; i++){
			if(countX > linesX){
	    		countX = 1;
	    		dimY += size;
	    	}
	    	if(countX == 1){
	    		dimX = startX;
	    		countX++;
	    	}
	    	else{
	    		dimX += size;
	    		countX++;
	    	}
	    	position.put(i, new Position((int)dimX, (int)dimY));
		}
	}
	
    @Override
    public Position getPosition(Node n) 
    {
        return position.get(n.getID());
    }
}

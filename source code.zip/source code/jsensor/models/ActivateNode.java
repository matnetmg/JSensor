package jsensor.models;

import jsensor.nodes.Node;
import jsensor.nodes.events.AbstractEvent;

public class ActivateNode extends AbstractEvent{

	protected Node nodeToActivate;
	
	public void setNodeToActivate(Node nodeToActivate){
		this.nodeToActivate = nodeToActivate;
	}
	
	public Node getNodeToActivate(Node nodeToActivate){
		return this.nodeToActivate;
	}
	
	@Override
	public void handle() {
		nodeToActivate.activate();
	}



}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.events;

/**
 * This class represents the queue where the events will be stored.
 * This class is for internal use of the framework.
 * @author danniel
 */
import java.util.SortedSet;
import java.util.TreeSet;

import jsensor.runtime.Jsensor;
import jsensor.utils.ComparatorAbstractEvent;
import jsensor.utils.Configuration;

public class EventQueue {
    
	private TreeSet<AbstractEvent> queue;

        public EventQueue(){
            this.queue = new TreeSet<AbstractEvent>(new ComparatorAbstractEvent());
        }

        public AbstractEvent getFirst(){
            return this.queue.pollFirst();
        }

        public int size(){
            return queue.size();
        }

        @SuppressWarnings("unused")
		private TreeSet<AbstractEvent> getEventsToHandle() {
            return this.queue;
        }

        public void setEventsToHandle(TreeSet<AbstractEvent> eventsToHandle) {
            this.queue = eventsToHandle;
        }

        public void addEventToHandle(AbstractEvent ae){
        	ae.setID(Jsensor.getEventID(ae.getNode().getID() % Configuration.numberOfChunks));
            if(this.queue.add(ae)){
            	Jsensor.eventsTimeToHandle.addEventToHandle((int)ae.getFireTime());
            }
            else 
            	System.out.println("Rejeitou fora");
        }
        
        public void addEventToHandle(AbstractEvent ae, int factID){
        	ae.setID(Jsensor.getEventID(factID % Configuration.numberOfChunks));
        	if(this.queue.add(ae)){
            	Jsensor.eventsTimeToHandle.addEventToHandle((int)ae.getFireTime());
            }
            else 
            	System.out.println("Rejeitou fora fact");
        }
        
        public void addCellEventToHandle(AbstractEvent ae, int factID){
        	ae.setID(Jsensor.getEventID(ae.getNodeFactID() % Configuration.numberOfChunks));
        	if(this.queue.add(ae)){
            	Jsensor.eventsTimeToHandle.addEventToHandle((int)ae.getFireTime());
            }
            else 
            	System.out.println("Rejeitou fora fact");
        }


        /**
         * Return all events whose fireTime is lower the the specified time.
         * @param time - the maximun time to get the events
         * @return a set of AbstractEvents which fireTime is lower than time
         */
        public SortedSet<AbstractEvent> getEventLowerThan(long time){
            SortedSet<AbstractEvent> list= new TreeSet<AbstractEvent>();

            for(AbstractEvent ae: this.queue){
                  if(ae.getFireTime() <= time){
                        list.add(ae);
                   }
            }
            this.queue.removeAll(list);
            return list;
        }
        
        /**
         * Return all events whose fireTime is lower the the specified time.
         * @param time - the maximun time to get the events
         * @return a set of AbstractEvents which fireTime is lower than time
         */
        public SortedSet<AbstractEvent> getAllEvents(){
            SortedSet<AbstractEvent> list= new TreeSet<AbstractEvent>();

            for(AbstractEvent ae: this.queue){
            	list.add(ae);
            }
            this.queue.removeAll(list);
            return list;
        }

        public boolean isEmpty(){
            return this.queue.isEmpty();
        }
}


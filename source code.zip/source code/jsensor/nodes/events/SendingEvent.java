/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.events;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.logging.Level;

import jsensor.Main;
import jsensor.nodes.Node;
import jsensor.nodes.messages.Message;
import jsensor.nodes.messages.Packet;

/**
 *
 * @author danniel & Matheus
 */
public class SendingEvent extends AbstractEvent{

    private SendType SendType;
    private Message message;
    private Node target;
    private double loss;
    
    public SendingEvent(Message message, Node sender, Node target, double delayTime, SendType SendType) {
        this.message = message;
        this.node = sender;
        this.target = target;
        this.SendType = SendType;
        this.fireTime = delayTime;
        this.name = this.getClass().getSimpleName();
    }


    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public SendType getSendType() {
        return SendType;
    }

    public void setSendType(SendType SendType) {
        this.SendType = SendType;
    }

    public Node getTarget() {
        return target;
    }

    public void setTarget(Node target) {
        this.target = target;
    }
    
    public double getLoss() {
        return loss;
    }

    public void setLoss(double loss) {
        this.loss = loss;
    }
    
    /**
     * This method is used to send a new message via broadcast or unicast.
     */
    @Override
    public void handle(){
    	
        switch(this.SendType){
            case broadcast:{
                broadcast();
                break;
            }
            case unicast:{
                unicast();
                break;
            }
            
            case broadcastLoss:{
            	break;
            }
              
        }
    }
    
    /**
     * Send a message to all sender's neighbours.
     * @param sender - the node who is sending the message
     * @param message - the message to be sent
     * @param delayTime - the time to send the message
     */
    public void broadcast(){
    	SortedSet<Node> list = this.node.getNeighbours().getNodesList();
    	Iterator<Node> it = list.iterator();
    	while(it.hasNext()){
    		Node nodes = it.next();
        	try {
        		Packet p = new Packet(node, nodes, fireTime, message.clone());
        		if(nodes.getReliabilityModel().reachesDestination(p))
        			nodes.addToInbox(message.clone(),node,nodes, fireTime);
        		
        	} catch (ClassCastException ex) {
    			System.err.println("There was a cast problem in your method clone (Message).");
    			Main.LOG.log(Level.SEVERE, null, ex);
    			System.exit(1);
    		} catch (NullPointerException ex) {
    			System.err.println("The method clone (Message) should not return null.");
    			Main.LOG.log(Level.SEVERE, null, ex);
    			System.exit(1);
    		}
        }
    }
    
    
    /**
     * Send a message from a sender to a target. This method checks if the send and the target
     * are near to each other before sending it. If they are not, the message event is discarted.
     * @param sender - the node who is sending the message
     * @param target - the receiver of the message
     * @param message - the message to be sent
     * @param senddelayTimeTime - the time that the message should be sent
     */
    public void unicast(){
        if(!isNear(this.node, target)){
        	return;
        }
        try {
        	 target.addToInbox(message.clone(),node ,target, fireTime);
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method clone (Message).");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The method clone (Message) should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
    }
    
    /**
     * Compare if two nodes are near to each other.
     * @param n1 - the firts node
     * @param n2 - the second node
     * @return true if they are close to each other and false otherwise
     */
     public boolean isNear(Node n1, Node n2){
        double dist = Math.sqrt( Math.pow(n1.getPosition().getPosX() - n2.getPosition().getPosX(), 2) +
                Math.pow(n1.getPosition().getPosY() - n2.getPosition().getPosY(), 2));

        return dist <= n1.getCommunicationRadio();
    }
}

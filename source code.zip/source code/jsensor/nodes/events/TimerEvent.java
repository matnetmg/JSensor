/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.events;

import jsensor.nodes.Node;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime.ThreadState;

/**
 * This class represents all Timer events in the network. Extend this class to create new
 * Timer events to handle the network assynchronous timers.
 * @author danniel & Matheus
 */
public abstract class TimerEvent extends AbstractEvent implements Comparable<AbstractEvent> {

	public TimerEvent(){
		setName(this.getClass().getSimpleName());
	}
	
    /**
     * Fire a new timer event.
     */
    public abstract void fire();


    /**
     * This method is for internal use only. It fire a new timer event.
     */
    public final void handle(){
        fire();
    }
    
    /**
     * Start a new timer using a relative timer.
     * @param relativeTime - the time that will be increased to the current timer
     * to fire the event.
     */
    public final void startTimer(double relativeTime){

        if(relativeTime <= 0){
            System.out.println("RelativeTime must be positive and greater than zero");
            System.exit(0);
        }

        node = null;

        fireTime = Jsensor.currentTime + relativeTime;

        if(jsensor.utils.Configuration.assynchronousMode){
            this.node.addEventToHandle(this, ThreadState.steping_timer);
        }else{
            Jsensor.customGlobal.addGlobalTimer(this);
        }

    }
    
    /**
     * Start a new relative timer to the Node n. 
     * @param relativeTime - the time that will be increased to the current timer
     * @param n - the node where the event will be treated
     */
    public final void startRelative(double relativeTime, Node sensor){
        if(relativeTime <= 0){
            System.out.println("RelativeTime must be positive and greater than zero." + " time: " + relativeTime);
            System.exit(0);
        }

        this.node = sensor;
        fireTime = Jsensor.currentTime + relativeTime;

        if(jsensor.utils.Configuration.assynchronousMode){
            this.node.addEventToHandle(this, ThreadState.steping_timer);
        }else{
        	this.node.addTimer(this);
        }
    }

    /**
     * Start a new timer for the node n using the absoluteTime.
     * @param absoluteTime - the exact time when the event should occurr
     * @param n - the node who will fire the timer
     */
    public final void startAbsolute(double absoluteTime, Node sensor){
        if(absoluteTime <= Jsensor.currentTime){
            System.out.println("AbsoluteTime must be greater than current time");
            System.exit(0);
        }

        this.node = sensor;
        fireTime = absoluteTime;

        if(jsensor.utils.Configuration.assynchronousMode){
            this.node.addEventToHandle(this, ThreadState.steping_timer);
        }else{
        	this.node.addTimer(this);
        }
    }

    @Override
    public int compareTo(AbstractEvent o) {
        if(this.getFireTime() < o.getFireTime())
            return -1;
        else{
        	if(this.getFireTime() > o.getFireTime())
                return 1;
        	
        	return 0;
        }
            
    }
}

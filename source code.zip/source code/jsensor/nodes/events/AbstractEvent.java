/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.events;

import jsensor.nodes.Node;
import jsensor.nodes.messages.ID;

/**
 * The Abstract class for all Event Types
 */
public abstract class AbstractEvent implements Comparable<AbstractEvent> {

    protected double fireTime;
    protected Node node;
    protected int nodeFactID;
    protected ID ID;
    protected String name;

    /**
     * This method is called in assynchrnous sequence. Its responsible for
     * handle the event actions for specific event types.
     */
    public abstract void handle();

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
        this.setNodeFactID(node.getID());
    }

    public double getFireTime() {
        return fireTime;
    }

    public void setFireTime(double fireTime) {
        this.fireTime = fireTime;
    }
    
    public void setID(ID ID) 
    {
    	this.ID = ID;
    }
    
    public ID getID() 
    {
    	return this.ID;
    }
    
    public void setNodeFactID(int ID) 
    {
    	this.nodeFactID = ID;
    }
    
    public int getNodeFactID() 
    {
    	return this.nodeFactID;
    }
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int compareTo(AbstractEvent o) {
    	return ID.compareTo(o.ID);
    }
}
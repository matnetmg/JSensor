package jsensor.nodes.monitoring;

import jsensor.runtime.Jsensor;
import jsensor.nodes.Node;
import jsensor.utils.Position;

/**
 * The superclass of all the HandleCells. Extend this class to implement your own 
* HandleCells.
* @author Matheus
*/
public abstract class HandleCells implements Comparable<HandleCells>{
	
	private Node node;
	private CellModel cell;
	
	/**
	 * This method fires the code to handle the cell.
	 *
	 * @param sensor The sensor that is trying to modify the cell
	 * @param cell The cell to be modified.
	 * 	 */
	public abstract void fire(Node sensor,CellModel cell);
	
	public final void handle(){
		fire(this.node, this.cell);
	}
	
	
	/**
	 * This method adds the cell in the line to be handled.
	 *
	 * @param sensor The sensor that is trying to modify the cell
	 * @param position The cell's position.
	 * 	 */
	public void addCell(Node node, Position position){
		this.node = node;
		this.cell = Jsensor.getCell(position);
		CellController.addSetCell(this, cell.getChunk());
	}
	
	@Override
	public int compareTo(HandleCells o) {
		if(this.node.getID() < o.node.getID())
			return -1;
		else{
			if(this.node.getID() > o.node.getID())
				return 1;
			
			return 0;
		}
	}
}

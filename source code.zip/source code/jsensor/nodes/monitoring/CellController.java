package jsensor.nodes.monitoring;

import jsensor.nodes.events.AbstractEvent;
import jsensor.utils.CellChunk;
import jsensor.utils.Configuration;

public class CellController {
	
	private static SetCellQueue[] setCellsQueue;
	private static CellChunk[] cellchunk;
	
	
	public CellController(){
		setCellsQueue = new SetCellQueue[Configuration.numberOfChunks];
		cellchunk = new CellChunk[Configuration.numberOfChunks];
		
		
		for(int i = 0; i< setCellsQueue.length; i++){
			setCellsQueue[i] = new SetCellQueue();
		}
		 
		for(int i = 0; i< cellchunk.length; i++){
			cellchunk[i] = new CellChunk();
		}
	}
	
	
	public static void addSetCell(HandleCells hc, int chunk){
    	setCellsQueue[chunk].addEventToHandle(hc);
    	
    }
    
    public static SetCellQueue getCellsToSet(int i){
    	return setCellsQueue[i];
    }
    
    public static void addFactEventChunk(AbstractEvent ae, int chunk){
    	cellchunk[chunk].addEventToHandle(ae);
    }
    
    public static CellChunk getCellChunk(int i){
    	return cellchunk[i];
    }
}

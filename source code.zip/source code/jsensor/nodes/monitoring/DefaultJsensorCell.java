package jsensor.nodes.monitoring;


public class DefaultJsensorCell extends CellModel{
	
	@Override
	public CellModel clone() {
		return new DefaultJsensorCell(); 
	}

}

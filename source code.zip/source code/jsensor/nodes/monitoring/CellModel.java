package jsensor.nodes.monitoring;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import jsensor.nodes.Node;
import jsensor.runtime.Jsensor;
import jsensor.utils.Configuration;

/**
  * The superclass of all the CellModels. Extend this class to implement your own 
 * CellModel.
 * @author Matheus
 */
public abstract class CellModel{
	private byte chunk;
	private int posX;
	private int posY;
	private Int2ObjectOpenHashMap<Node> hashSensors;
	
	public CellModel(){
		
		int initialCapacity = Math.round(Jsensor.numNodes/Configuration.estimateCells);
		
		hashSensors = new Int2ObjectOpenHashMap<Node>(initialCapacity, 0.3f);
	}
	
	
	/**
     * This method should not be used by users.
     */
	public final void setChunk(byte chunk){
		this.chunk = chunk;
	}
	
	
	/**
     * This method return an int that represents the chunck the cell.
     * @return an int that represents the chunck the cell.
     */
	public int getChunk(){
		return this.chunk;
	}
	
	
	/**
     * This method should not be used by users.
     */
	public void setPosX(int x){
		this.posX = x;
	}
	
	
	/**
     * This method should not be used by users.
     */
	public void setPosY(int y){
		this.posY = y;
	}
	
	
	/**
     * This method return an int that represents the position X of the cell.
     * @return an int that represents the position X of the cell.
     */
	public int getPosX(){
		return this.posX;
	}
	
	
	/**
     * This method return an int that represents the position Y of the cell.
     * @return an int that represents the position Y of the cell.
     */
	public int getPosY(){
		return this.posY;
	}
	
	
	/**
     * This method return a hash with the sensors that are within this cell. The key of the hash is the sensor ID and the value the sensor.
     * @return a map <Integer, Sensor> that contains the sensors within this cell.
     */
	public Int2ObjectOpenHashMap<Node> getHashSensors(){
		return this.hashSensors;
	}
	
	
	/**
     * This method set a hash with the sensors that are within this cell. The key is the sensor ID and the value the sensor.
     * @param map - a map <Integer, Sensor> that contains the sensors within this cell.
     */
	public void setHashNodes(Int2ObjectOpenHashMap<Node> map){
		this.hashSensors = map;
	}
	
	
    /**
     * This method must return an exact clone of the cell 
     * @return A new JsensorCell that is a perfect clone of the original
     */
	public abstract CellModel clone();

}

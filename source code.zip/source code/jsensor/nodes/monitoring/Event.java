/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.monitoring;

import java.awt.Color;
import java.awt.Graphics;

import jsensor.nodes.Node;
import jsensor.nodes.events.AbstractEvent;
import jsensor.nodes.events.EventQueue;
import jsensor.runtime.Jsensor;
import jsensor.utils.Configuration;
import jsensor.utils.Position;
import jsensor.utils.PositionTransformation;
import jsensor.utils.RandomGenerator;

/**
 * This class is the base class for all Facts. A fact represents an event that
 * may occurr during the simulation. The framework treat the Facts separately from 
 * the Nodes. Its one of the three entities of the framework, along with Node and Message.
 * @author danniel
 */
public abstract class Event implements Comparable<Event> {
    protected int ID;
    protected int radius;
    protected Position position;
    protected double start;
    protected double duration;
    protected double value;
    protected double timeElapsed = 0;
    protected Color color = Color.BLACK;
    protected EventQueue factEventQueue = new EventQueue();
    
    

   /**
     * Draw the fact in the simulation area.
     * @param g - the Graphics used to draw the fact.
     * @param start_x - the x-position of the fact.
     * @param start_y - the y-position fo the fact.
     */
    public void draw(Graphics g, int start_x, int start_y){
        int x = PositionTransformation.getGuiDimX(this.position.getPosX());
        int y = PositionTransformation.getGuiDimY(this.position.getPosY());

        x = x - (radius >>1);
        y = y - (radius >>1);
        
        g.setColor(color);
        g.drawOval(x + start_x, y + start_y, radius, radius);
    }
    
    /**
     * Framework internal use method. This method handle the fact events
     * which time is lower than time.
     * @param time - the time to handle all events
     */
    public void step(long time){
        for(AbstractEvent ae : this.factEventQueue.getEventLowerThan(time))
        {
            ae.handle();          
        }
    }
    
    public void addEventToHandle(AbstractEvent ae){
        this.factEventQueue.addEventToHandle(ae, this.ID);
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public double getStart() {
        return start;
    }

    public void setStart(double start) {
        this.start = start;
    }

    public double getValue() {
        return value;
    }
    
    public void setValue(double value){
        this.value = value;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public double getTimeElapsed() {
        return timeElapsed;
    }

    public void setTimeElapsed(double timeElapsed) {
        this.timeElapsed = timeElapsed;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }
    
    
    
    public boolean isNear(Node n){
        double dist = Math.sqrt( Math.pow(n.getPosition().getPosX() - this.position.getPosX(), 2) +
                Math.pow(n.getPosition().getPosY() - this.position.getPosY(), 2));

        return dist <= this.radius;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Event other = (Event) obj;
        if (this.ID != other.ID) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.ID;
        return hash;
    }
    
    public int compareTo(Event o) {
        if(this.ID < o.ID)
            return 1;
        else if(this.ID == o.ID)
            return 0;
        else
            return -1;
    }
    
    /**
     * This method updates the Fact Value. Implement this method to specify how a fact
     * will update its value.
     * @return - the new value of the fact
     */
    public abstract double updateValue();
    
    /**
     * This method specify what will happen when a fact is created. Implement this method to
     * set the actions that might happen when a new Fact is created.
     */
    public abstract void onCreation();

    public RandomGenerator getRandom(){
    	return Jsensor.runtime.getMyRamdom(this.ID % Configuration.numberOfChunks);
    }
}
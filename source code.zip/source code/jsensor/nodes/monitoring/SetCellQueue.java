package jsensor.nodes.monitoring;

import java.util.SortedSet;
import java.util.concurrent.ConcurrentSkipListSet;

public class SetCellQueue {
	private ConcurrentSkipListSet<HandleCells> queue;
	
	public SetCellQueue() {
        this.queue = new ConcurrentSkipListSet<HandleCells>();
    }
	
	 public HandleCells getFirst(){
         return this.queue.pollFirst();
     }
	 
	 public void addEventToHandle(HandleCells ce){
     	
         this.queue.add(ce);
     }
	 
     public SortedSet<HandleCells> getAllEvents(){
         return this.queue;
     }
}

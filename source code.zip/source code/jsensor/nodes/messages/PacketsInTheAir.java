/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.messages;

import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import jsensor.nodes.Node;

/**
 *
 * @author danniel
 */
public class PacketsInTheAir {
    private ConcurrentHashMap<Integer,ConcurrentLinkedQueue<Packet>> packetsInTheAir;

    public PacketsInTheAir() {
        this.packetsInTheAir = new ConcurrentHashMap<Integer, ConcurrentLinkedQueue<Packet>>();
    }

    public void addNewSensor(Node n){
        if(!this.packetsInTheAir.containsKey(n.getID())){
            ConcurrentLinkedQueue<Packet> packQueue = new ConcurrentLinkedQueue<Packet>();
            this.packetsInTheAir.put(n.getID(), packQueue);

        }
    }

    public void addNewPacket(Node target, Packet p){
        if(this.packetsInTheAir.containsKey(target.getID())){
            this.packetsInTheAir.get(target.getID()).add(p);
        }
    }

    public LinkedList<Packet> getSensorPackets(Node sensor,int time){
       if(this.packetsInTheAir.containsKey(sensor.getID())){
           LinkedList<Packet> packets = new LinkedList<Packet>();
           for(Packet p : this.packetsInTheAir.get(sensor.getID())){
                if(p.getDelayTime()<= time){
                    packets.add(p);
                    this.packetsInTheAir.get(sensor.getID()).remove(p);
                }
           }

           return packets;
       }

       return null;
    }


}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.messages;

import jsensor.runtime.Jsensor;

/**
 * This class is the representation of all Messages of the network. Extend
 * this class to implement a new type of Message.
 * @author danniel & Matheus
 */
public abstract class Message {
	private long ID;
	
	/**
	 * This constructor is used to get an ID for the message based on its chunk.
	 * @param chunk The chunk to which the message belongs.
	 */
	public Message(byte chunk){
		this.ID = Jsensor.getIDMessage(chunk);
	}
	
	/**
	 * The default constructor of the class message.
	 */
	public Message(){
	}
	
	
	/**
	 * This method is used to set the ID when cloning a message.
	 * @param ID The ID of the original message.
	 */
	public void setID(long ID){
		this.ID = ID;
	}
	
	/**
	 * This method is used to get the ID when cloning a message.
	 */
	public long getID(){
		return ID;
	}
	
	
    /**
     * This method should return an exact copy of the Message.
     * All objects within this class should make a new copy of its content
     * to another object of the same type.
     * @return an exact copy of this object
     */
    @Override
    public abstract Message clone();
}

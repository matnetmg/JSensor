package jsensor.nodes.messages;

public class ID implements Comparable<ID>{
	private long number;
	private int chunkie;
	
	public ID(long number, int chunkie){
		this.number = number;
		this.chunkie = chunkie;
	}

	public long getNumber() {
		return number;
	}

	public int getChunkie() {
		return chunkie;
	}

	@Override
	public int compareTo(ID o) {
		if(this.chunkie < o.getChunkie())
			return -1;
		else{
			if(this.chunkie == o.getChunkie()){
				if(this.number < o.getNumber())
					return -1;
				else{
					if(this.number == o.getNumber())
						return 0;
					else
						return 1;
				}
			}
			return 1;
		}
	}
}

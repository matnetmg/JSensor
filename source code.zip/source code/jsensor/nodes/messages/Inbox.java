/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.messages;
import java.util.LinkedList;
import java.util.TreeSet;

import it.unimi.dsi.fastutil.objects.ObjectRBTreeSet;
import jsensor.nodes.Node;

/**
 * This class represents the inbox where the arriving messages will be stored before
 * beeing evaluated by a node.
 * @author danniel
 */
public class Inbox {
	
    private ObjectRBTreeSet<Packet> inbox;

    public Inbox() {
        this.inbox = new ObjectRBTreeSet<Packet>(new ComparatorPacket());
    }
    
    public int getSize()
    {
    	return this.inbox.size();
    }

    public boolean hasMoreMessages(){
        return this.inbox.isEmpty() == false;
    }

    public void addToInbox(Node node,Node target, double delayTime, Message m){
    	Packet p = new Packet(node,target,delayTime, m);
    	synchronized (this.inbox) {
    		inbox.add(p);					
		}
    }
    
    public boolean add(Packet p){
        return this.inbox.add(p);
    }
    
    public Message getNextMessage(){
        if(this.inbox.isEmpty()) 
        	return null;
        Packet first = this.inbox.first();
        this.inbox.remove(first);
        return first.getMessage();
    }

    /**
     * Return all packets which receiveTime is lower than the specified time.
     * @param time - the time to get the packets
     * @return a set of packets which receiveTime is lower than the specified time.
     */
    public LinkedList<Packet> getPackets(long time){
    	System.out.println("Inbox - getPackets");
        LinkedList<Packet> list = new LinkedList<Packet>();
        
        for(Packet p:this.inbox){
            if(p.getDelayTime() <= time){
                list.add(p);
            }
        }
        this.inbox.removeAll(list);
        return list;
    }
    
    public TreeSet<Packet> seePackets(){
    	@SuppressWarnings("unchecked")
		TreeSet<Packet> list = (TreeSet<Packet>) this.inbox.clone();
        
        return list;
    }
    
    /**
     * This method is similar to Inbox#getPackets(),but it returns a inbox instead of
     * a set of packets.
     * @param time - the time to get the packets
     * @return a Inbox which receiveTime is lower than the specified time.
     */
    public Inbox getInboxAtThisTime(long time){
        Inbox list = new Inbox();
        
        for(Packet p : this.inbox){
        	if(p.getDelayTime() <= time){
                list.add(p);
        	}
        }
        this.inbox.removeAll(list.inbox);
    	
        return list;     
    }

    @Override
    public String toString() {
        
        return this.inbox.toString();
    }
}

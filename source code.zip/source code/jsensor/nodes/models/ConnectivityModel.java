/*
 * To change this template, choose Tools | Templates
\ * and open the template in the editor.
 */

package jsensor.nodes.models;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;

import jsensor.Main;
import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.AbstractNodesPositionMatrix;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.collections.NodesList;

/**
 *
 * @author danniel
 */
public abstract class ConnectivityModel extends Model {


    /**
     * Update a node connections using an array of AbstractNodesList. 
     * @param n - the node whose connection might be updated
     * @param nodesLists - the array of lists used to get the node's neighbours
     * @return true if the node's neighbour changed and false otherwise
     */
    public final boolean updateConnection(Node s,AbstractNodesList[] nodesLists){
        
        boolean changed = false;
        AbstractNodesList myNeighbours = new NodesList();

        try {
        	for(AbstractNodesList lists: nodesLists){
                for(Node possibleNeighbour:lists.getNodesList()){
                    if(possibleNeighbour.equals(s)) 
                    	continue;

                    if(isNear(s, possibleNeighbour)){
                        if(isConnected(s,possibleNeighbour)){
                            myNeighbours.addNode(possibleNeighbour);
                        }
                    }
                }
            }
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method isConnected.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The isConnected method should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}

        if(s.getNeighbours().equals(myNeighbours))
            changed = false;
        else
            changed = true;

        s.setNeighbours(myNeighbours);

        return changed;
        
        
    }

    /**
     * Update a node connections using an array of AbstractNodesPositionMatrix. 
     * @param n - the node whose connection might be updated
     * @param nodesMatrix - the array of matrices used to get the node's neighbours
     * @return true if the node's neighbour changed and false otherwise
     */
    public final boolean updateConnection(Node n,AbstractNodesPositionMatrix[] sensorsMatrix){

        boolean changed = false;
        NodesList myNeighbours = new NodesList();
        List<Node> possibleNeighbours = new LinkedList<Node>();

        for(AbstractNodesPositionMatrix matrix: sensorsMatrix){
            possibleNeighbours.addAll(matrix.possibleNeighbours(n, n.getPosition()));
        }

        try {
        	for(Node possibleNeighbour: possibleNeighbours){
                if(isNear(n, possibleNeighbour)){
                    if(isConnected(n,possibleNeighbour)){
                        myNeighbours.addNode(possibleNeighbour);
                    }
                }
            }
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method isConnected.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The isConnected method should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        
        if(n.getNeighbours().equals(myNeighbours))
            changed = false;
        else
            changed = true;

        n.setNeighbours(myNeighbours);

        return changed;
    }

    /**
     * Update a node connections using an unic AbstractNodesPositionMatrix. 
     * @param n - the node whose connection might be updated
     * @param nodesMatrix - the matrix used to get the node's neighbours
     * @return true if the node's neighbour changed and false otherwise
     */
     public final boolean updateConnection(Node n,AbstractNodesPositionMatrix nodesMatrix){

        boolean changed = false;
        NodesList myNeighbours = new NodesList();
        List<Node> possibleNeighbours = new LinkedList<Node>();

        possibleNeighbours.addAll(nodesMatrix.possibleNeighbours(n, n.getPosition()));
        
        try {
        	for(Node possibleNeighbour: possibleNeighbours){
                if(isNear(n, possibleNeighbour)){
                    if(isConnected(n,possibleNeighbour)){
                        myNeighbours.addNode(possibleNeighbour);
                    }
                }
            }
		} catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method isConnected.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The isConnected method should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        
        if(n.getNeighbours().equals(myNeighbours))
            changed = false;
        else
            changed = true;

        n.setNeighbours(myNeighbours);

        return changed;


    }
     
    /**
     * Update a node connections using a single ConcurrentHashMap (faster implementation). 
     * @param n - the node whose connection might be updated
     * @param nodesHash - the map of all nodes to update the nodes connections
     * @return true if the node's neighbour changed and false otherwise
     */
    public final boolean updateConnection(Node n,ConcurrentNodesPositionHashMap nodesHash){

        boolean changed = false;
        NodesList myNeighbours = new NodesList();
        
        List<Node> possibleNeighbours = nodesHash.possibleNeighbours(n, n.getPosition());
        
        possibleNeighbours.remove(n);
        //if(possibleNeighbours.remove(n))
        	//System.out.println("Element does exist - ConnectivityModel - updateConnection");
        
        try {
        	for(Node possibleNeighbour : possibleNeighbours){
            	if(isConnected(n,possibleNeighbour)){
                    myNeighbours.addNode(possibleNeighbour);
                }
            }
		} catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method isConnected.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The isConnected method should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        

        if(n.getNeighbours().equals(myNeighbours))
            changed = false;
        else{
        	changed = true;
            n.setNeighbours(myNeighbours);
        }

        return changed;
    }
     
    /**
     * This method tells when two sensors are close. The sensors are
     * close if sensor s2 is within the communication radius of s1. 
     * Users can override this method to implement another strategy.
     * @param s1 - The first sensor.
     * @param s2 - The second sensor.
     * @return true if the two nodes are near and false otherwise.
     */
    public boolean isNear(Node s1, Node s2){
        double dist = Math.sqrt( Math.pow(s1.getPosition().getPosX() - s2.getPosition().getPosX(), 2) +
                Math.pow(s1.getPosition().getPosY() - s2.getPosition().getPosY(), 2));

        return dist <= s1.getCommunicationRadio();
    }

    /**
     * This method should tell when two close nodes are connected. The nodes are
     * closer if the node from communication range.
     * @param from - the first node
     * @param to - the node who is in from's communication range
     * @return true if the two nodes are connected and false otherwise
     */
    public abstract boolean isConnected(Node from, Node to);
}

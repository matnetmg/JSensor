/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.models;

import jsensor.nodes.monitoring.Event;
import jsensor.utils.Position;

/**
 * This class represent the Distribution Model of the facts. The Distribution Model
 * dictates position to all specified facts.
 * Extends this class to create a new Distribution Model.
 * @author danniel & Matheus
 */
public abstract class DistributionModelEvent {

    /**
     * Return a new Position to the next fact evaluated.
     * @return The position of the next fact.
     * @param The fact which requires the position.
     */
    public abstract Position getPosition(Event e);
    

}

package jsensor.nodes.models;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.logging.Level;

import jsensor.Main;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime.ThreadState;
import jsensor.nodes.Node;
import jsensor.nodes.events.AbstractEvent;
import jsensor.utils.Configuration;
import jsensor.utils.Position;

/**
 * Class that represents all assynchronous Movement Events of the Nodes.
 * Extend this class to create a new Movement Events for assynchronous simulation.
 * @author Danniel
 */
public abstract class MobilityModel extends AbstractEvent{

    protected double startTime;
    protected double time;
    protected double step;
    protected double elapsedTime;
    protected Position nextPosition;
    protected boolean finished = true;
    
    /**
     * This method should return an exact copy of the Moviment Event.
     * All objects within this class should make a new copy of its content
     * to another object of the same type.
     * @return an exact copy of this object
     */
    @Override
    public abstract MobilityModel clone();
    
    /**
     * This method should return a new Position to the Node n. This position should be 
     * within the simulation area. The Node n' position should not be modified. This
     * param is only for consulting the old position.
     * @param n - the node whose position might change
     * @return a new position which the Node n will assume in future.
     */
    public abstract Position getNextPosition(Node n);
    
    /**
     * This method starts the MovimentEvent event. Starting in starttime and lasting
     * for time, this method updates the node's position in the simulation.
     * @param n - the node whose position might change
     * @param startime - the start time of the moviment event
     * @param time - the time that the will last
     * @param step - the step for position updates
     */
    public final void start(Node n, double startime,double time, double step){
    	Configuration.hasMobility = true;
        this.startTime = startime + Jsensor.currentTime;
        this.node = n;
        this.time = time;
        this.step = step;
        this.finished = false;
        this.name = this.getClass().getSimpleName();
        if(time <= 0 || step <= 0){
            System.err.println("Time and step must be greater than zero");
            System.exit(1);
        }
         
        MobilityModel ame = null;
        if(Configuration.assynchronousMode){
        	try {
        		ame = this.clone();
        		
        	} catch (ClassCastException ex) {
    			System.err.println("There was a cast problem in your method clone (MobilityModel).");
    			Main.LOG.log(Level.SEVERE, null, ex);
    			System.exit(1);
    		} catch (NullPointerException ex) {
    			System.err.println("The method clone (MobilityModel) should not return null.");
    			Main.LOG.log(Level.SEVERE, null, ex);
    			System.exit(1);
    		}
            
            ame.setElapsedTime(0);
            ame.setNode(node);
            ame.setStep(step);
            ame.setStartTime(Jsensor.currentTime+startime);
            ame.setTime(time);
            ame.setFireTime(Jsensor.currentTime+ startime);
            ame.setName(name);
            
            this.node.addEventToHandle(ame, ThreadState.steping_moviment);
    
        }else{
            System.err.println("Invalid assynchronous moviment for synchronous simulation");
            System.exit(1);
        }
    }

    public double getElapsedTime() {
        return elapsedTime;
    }

    public void setElapsedTime(double elapsedTime) {
        this.elapsedTime = elapsedTime;
    }


    public Position getNextPosition() {
        return nextPosition;
    }

    public void setNextPosition(Position nextPosition) {
        this.nextPosition = nextPosition;
    }

    public double getStep() {
        return step;
    }

    public void setStep(double step) {
        this.step = step;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getStartTime() {
        return startTime;
    }

    public void setStartTime(double startTime) {
        this.startTime = startTime;
    }
    
    public boolean finished(){
    	return this.finished;
    }
    
    
    /**
     * This method is an implementation of AbstractEvent#handle(). It changes the nodes
     * position and creates new MovimentEvents to handle the next changes.
     */
    @Override
    public void handle() {
        Position old = this.node.getPosition();
        Position newP = this.getNextPosition(node);
        
        this.node.setPosition(newP);
        Jsensor.runtime.getSensorsHash().changeSensorPosition(this.node, old, this.node.getPosition());

        //Jsensor.log_jsensor(String.format("Time %d - Node %d - Changed Position - Old Position: %s - New Position: %s", Jsensor.currentTime, this.sensor.getID(),old.toString(),this.sensor.getPosition().toString() ));
        
        if(this.getElapsedTime() > this.time ){
        	finished = true;
        	return;
        }
        
        MobilityModel ame = null;
        try {
        	ame = this.clone();
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method clone (MobilityModel).");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The method clone (MobilityModel2) should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        
        
        ame.setElapsedTime(this.getElapsedTime() + step);
        ame.setStartTime(this.getStartTime() + step);
        ame.setNode(this.node);
        ame.setStep(this.step);
        ame.setTime(this.time);
        ame.setFireTime(Jsensor.currentTime+ this.step);
        ame.setName(name);
        try {
        	ame.setNextPosition(ame.getNextPosition(node));
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method getNextPosition (MobilityModel).");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The method getNextPosition (MobilityModel3) should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}

        node.addEventToHandle(ame, ThreadState.steping_moviment);
    }
    
}

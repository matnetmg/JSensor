/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.models;

import jsensor.nodes.Node;
import jsensor.utils.Position;

/**
 * This class represents the Distribution Model of the sensors. The Distribution Model
 * dictates the initial position to all specified sensors in the simulation area.
 * Extends this class to create a new Distribution Model.
 * @author danniel & Matheus
 */
public abstract class DistributionModelNode {

    /**
     * Return a new Position to the next sensor evaluated.
     * @return The position of the next sensor.
     * @param The sensor which requires the position.
     */
    public abstract Position getPosition(Node n);
    

}

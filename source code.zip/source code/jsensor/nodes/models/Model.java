/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.models;

/**
 * The base class for all models.
 * @author danniel
 */
public class Model {

    private ModelType modelType;

    public ModelType getModelType() {
        return modelType;
    }

    public void setModelType(ModelType modelType) {
        this.modelType = modelType;
    }

    

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.collections;

import it.unimi.dsi.fastutil.objects.ObjectRBTreeSet;
import jsensor.nodes.monitoring.Event;

/**
 * This class represents the set of Facts within the network. It is used to
 * store all created facts. It contains a ConcurrentSkipListSet of Facts to keep
 * it thread safe.
 * @author Danniel
 */
public class EventsList {
    private ObjectRBTreeSet<Event> factList;

    public EventsList() {
        this.factList = new ObjectRBTreeSet<Event>();
    }

    public ObjectRBTreeSet<Event> getEventList() {
        return factList;
    }

    public void setEventtList(ObjectRBTreeSet<Event> factList) {
        this.factList = factList;
    }
    
    public void addEvent(Event f){
        this.factList.add(f);
    }
    
    public void removeEvent(Event f){
        this.factList.remove(f);
    }
    
    public boolean isEmpty(){
        return this.factList.isEmpty();
    }
    
    public Event getEvent(int factID){
        for(Event f:this.factList)
            if(f.getID() == factID)
                return f;
        
        return null;
    }
    
}

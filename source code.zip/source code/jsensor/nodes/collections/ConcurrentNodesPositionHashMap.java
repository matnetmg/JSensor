/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.collections;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.Main;
import jsensor.runtime.threads.NodesCreationThread;
import jsensor.nodes.Node;
import jsensor.nodes.monitoring.DefaultJsensorCell;
import jsensor.nodes.monitoring.CellModel;
import jsensor.utils.Configuration;
import jsensor.utils.ObjectTuple;
import jsensor.utils.Position;

/**
 * This class offer an efficient way to store Nodes.
 * Each Node is stored into a Map inside another Map.
 * The most internal Map stores the Node and its key is an Integer, representing
 * the Node's ID. The external Map stores a Map of Nodes and its key is a String
 * representing the relative position (x,y) of the Node inside the graph. The relative
 * position is calculated by dividing the current position of the node by its communication
 * radio. This relative position is calculated this way to ensure that all neighbours of a Node
 * in the graph is in the maximum 1 cell around the cell of the node. This way, to retrieve a neighbour
 * of a node we just have to check the 8 cells around the cell where the node is in, plus the cell where it is 
 * stored.
 * @author Danniel & Matheus
 */
public class ConcurrentNodesPositionHashMap {
    private AbstractMap<String, CellModel> sensorsList;
    private int cellMaxX;
    private int cellMaxY;
    
    public ConcurrentNodesPositionHashMap(){
    	cellMaxX = (int) (Math.floor((double)Configuration.dimX/Configuration.cellSize));
    	cellMaxY = (int) (Math.floor((double)Configuration.dimY/Configuration.cellSize));
    	Configuration.estimateCells = (cellMaxX+1) * (cellMaxY+1);
    	sensorsList = new HashMap<String, CellModel>((cellMaxX+1) * (cellMaxY+1));
    }
    
    public AbstractMap<String, CellModel> getNodesList(){
    	return this.sensorsList;
    }

    //TODO ver synchronized
    public void addNodesHashMap(AbstractNodesList nodes) {
    	for(Node n : nodes.getNodesList()){
        	int posX = n.getPosition().getPosX()/Configuration.cellSize;
            int posY = n.getPosition().getPosY()/Configuration.cellSize;
            
            if(posX > cellMaxX || posY > cellMaxY){
            	System.err.println("The position sensor must belong to area simulation set.");
    			System.exit(1);
            }

            String pos = posX + "," + posY;
            
            synchronized (this.sensorsList) {
              	if(this.sensorsList.containsKey(pos)){
        			this.sensorsList.get(pos).getHashSensors().put(n.getID(),n);
                }else{
                	CellModel jsensorCell = instantiateMyCell(posX, posY);
                    jsensorCell.getHashSensors().put(n.getID(),n);
                	this.sensorsList.put(pos, jsensorCell);
                }
            }
        }
    }

    public CellModel getCell(int x, int y){
    	int posX = x/Configuration.cellSize;
        int posY = y/Configuration.cellSize;
        
        if(posX > cellMaxX || posY > cellMaxY){
        	System.err.println("The position of cell must belong to area simulation set.");
			System.exit(1);
        }
        
        CellModel cell = this.sensorsList.get(posX +","+ posY);
        if(cell == null){
			cell = instantiateMyCell(posX, posY);
            this.sensorsList.put((posX +","+ posY), cell);
		}
        
        CellModel cellClone = null;
        try {
        	cellClone = cell.clone();
		} catch (ClassCastException ex) {
			System.err.println("There was a cast problem with your cell.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The cell clone method should not return null..");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        
        cellClone.setPosX(cell.getPosX());
        cellClone.setPosY(cell.getPosY());
        cellClone.setHashNodes(cell.getHashSensors());
    	return cellClone;
    }
    
    public void setCell(CellModel cell){
    	int posX = cell.getPosX();
        int posY = cell.getPosY();
        this.sensorsList.put(posX +","+ posY, cell);
    }
    
    private CellModel instantiateMyCell(int posX, int posY){
    	CellModel cell = null;
        try {
        	Constructor<?> myCell = Configuration.myCellConstructor;
        	if(myCell == null)
        		cell = new DefaultJsensorCell();
        	else
        		cell = (CellModel) myCell.newInstance();
        	
        	cell.setPosX(posX);
        	cell.setPosY(posY);
        	cell.setChunk((byte) ((posX + (posY * cellMaxX)) % Configuration.numberOfChunks));
        	Configuration.addcell();
        	
            
        } catch (InvocationTargetException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cell;
    }
    
    /**
     * Add a node to the Map.
     * @param n - the node to be added
     */
    public void addNode(Node n){
        int posX = n.getPosition().getPosX()/Configuration.cellSize;
        int posY = n.getPosition().getPosY()/Configuration.cellSize;
        
        String pos = posX + "," + posY;
        
        if(this.sensorsList.containsKey(pos)){
            this.sensorsList.get(pos).getHashSensors().put(n.getID(),n);
        }else{
        	CellModel jsensorCell = instantiateMyCell(posX, posY);
            jsensorCell.getHashSensors().put(n.getID(),n);
            this.sensorsList.put(pos, jsensorCell);
        }       
    }
    
    /**
     * Changes the node position inside the Hash.
     * @param n - the node which position may change.
     * @param oldPosition - the node's old position
     * @param newPosition - the node's new position
     * @return a boolean representing if the operation succeed of failed.
     */
    //TODO ver synchronized
    public boolean changeSensorPosition(Node n, Position oldPosition, Position newPosition){
    	if(!Configuration.positionChanged){
    		synchronized (Configuration.class){
    			Configuration.positionChanged = true;
			}
    	}
    	
        int oldposX = oldPosition.getPosX()/Configuration.cellSize;
        int oldposY = oldPosition.getPosY()/Configuration.cellSize;
        
        int nposX = newPosition.getPosX()/Configuration.cellSize;
        int nposY = newPosition.getPosY()/Configuration.cellSize;
        
        String oldP = oldposX + "," + oldposY;
        String newP = nposX + "," + nposY;
            
        if(!this.sensorsList.containsKey(oldP)) 
        	return false;
        
        if(oldP.equals(newP))
        	return true;
        
        synchronized (this.sensorsList) {
        	this.sensorsList.get(oldP).getHashSensors().remove(n.getID());
			if(this.sensorsList.containsKey(newP)){
				this.sensorsList.get(newP).getHashSensors().put(n.getID(),n);
			}else{
				CellModel jsensorCell = instantiateMyCell(nposX, nposY);
				jsensorCell.getHashSensors().put(n.getID(),n);
				this.sensorsList.put(newP, jsensorCell); 
			}
		}
        return true;
    }
    
    //TODO ver synchronized
    public List<CellModel> cellsHitByFact(Position p, int radius){
    	int posXMin, posYMin, posXMax,posYMax;
    	
    	posXMin = (p.getPosX() - radius)/Configuration.cellSize;
    	posYMin = (p.getPosY() - radius)/Configuration.cellSize;
    	
    	posXMax = (int) Math.ceil((p.getPosX() + radius)/Configuration.cellSize);
    	posYMax = (int) Math.ceil((p.getPosY() + radius)/Configuration.cellSize);
    	
    	if(posXMin < 0)
    		posXMin = 0;
    	if(posYMin < 0)
    		posYMin = 0;
    	if(posXMax > cellMaxX)
    		posXMax = cellMaxX;
    	if(posYMax > cellMaxY)
    		posYMax = cellMaxY;
    	
    	List<CellModel> hitCells = new ArrayList<CellModel>();
    	String position = "";
    	
    	for(int i = posXMin; i <= posXMax; i++){
			for(int j = posYMin; j <= posYMax; j++){
				position = (i)+","+(j);
				CellModel cell = null;
				synchronized (sensorsList) {
					cell = sensorsList.get(position);
					if(cell == null){
						cell = instantiateMyCell(i, j);
		                this.sensorsList.put(position, cell);
					}
				}
				
				CellModel cellClone = null;
				try{
					cellClone = cell.clone();
				} catch (ClassCastException ex) {
					System.err.println("There was a cast problem with your cell.");
					Main.LOG.log(Level.SEVERE, null, ex);
					System.exit(1);
				} catch (NullPointerException ex) {
					System.err.println("The cell clone method should not return null..");
					Main.LOG.log(Level.SEVERE, null, ex);
					System.exit(1);
				}
				
			    cellClone.setPosX(cell.getPosX());
			    cellClone.setPosY(cell.getPosY());
			    cellClone.setHashNodes(cell.getHashSensors());
					
				hitCells.add(cellClone);
			}
		}
        return hitCells;
    }
    
    //TODO ver synchronized
    public List<ObjectTuple> cellsHitByFactS(Position p, int radius){
    	int posXMin, posYMin, posXMax,posYMax;
    	
    	posXMin = (p.getPosX() - radius)/Configuration.cellSize;
    	posYMin = (p.getPosY() - radius)/Configuration.cellSize;
    	
    	posXMax = (int) Math.ceil((p.getPosX() + radius)/Configuration.cellSize);
    	posYMax = (int) Math.ceil((p.getPosY() + radius)/Configuration.cellSize);
    	
    	if(posXMin < 0)
    		posXMin = 0;
    	if(posYMin < 0)
    		posYMin = 0;
    	if(posXMax > cellMaxX)
    		posXMax = cellMaxX;
    	if(posYMax > cellMaxY)
    		posYMax = cellMaxY;
    	
    	List<ObjectTuple> hitCells = new ArrayList<ObjectTuple>();
    	String position = "";
    	
    	for(int i = posXMin; i <= posXMax; i++){
			for(int j = posYMin; j <= posYMax; j++){
				position = (i)+","+(j);
				CellModel cell = null;
				synchronized (sensorsList) {
					cell = sensorsList.get(position);
					if(cell == null){
						cell = instantiateMyCell(i, j);
		                this.sensorsList.put(position, cell);
					}
				}
				hitCells.add(new ObjectTuple(position, cell.getChunk()));
			}
		}
        return hitCells;
    }
    
    public List<Node> neighbourss(Node n, Position p){
        int posX,posY;
        posX = p.getPosX()/Configuration.cellSize;
        posY = p.getPosY()/Configuration.cellSize;
        List<Node> neighbours = new ArrayList<Node>();
        List<String> possibleNeighbours = new ArrayList<>();
                     
		int numberCells = (int)Math.ceil((double)n.getCommunicationRadio()/Configuration.cellSize);
		
		String position = "";
		for(int i = -numberCells; i <= numberCells; i++){
			for(int j = -numberCells; j <= numberCells; j++){
				if((posX+i) < 0 || (posY+j) < 0)
					continue;
				
				position = (posX+i)+","+(posY+j);
				possibleNeighbours.add(position);
			}
		}
		
		int triviallyAccepted = (int)Math.floor((double)n.getCommunicationRadio()/(Configuration.cellSize * Math.sqrt(2)));
		
		for(int i = -(triviallyAccepted-1); i <= (triviallyAccepted-1); i++){
			for(int j = -(triviallyAccepted-1); j <= (triviallyAccepted-1); j++){
				if((posX+i) < 0 && (posY+j) < 0)
					continue;
				
				position = (posX+i)+","+(posY+j);
				possibleNeighbours.remove(position);
				if(this.sensorsList.containsKey(position)){
					neighbours.addAll(this.sensorsList.get(position).getHashSensors().values());
				}
			}
		}
		
		for(String s : possibleNeighbours){
			if(this.sensorsList.containsKey(s)){
				Collection<Node> list = this.sensorsList.get(s).getHashSensors().values();
				Iterator<Node> it = list.iterator();
				
				while(it.hasNext()){
					Node node = it.next();
					if(n.getConectivityModel().isNear(n, node)){
		                neighbours.add(node);
					}
				}
			}
		}
		
        return neighbours;
    }
    
  

    public List<Node> possibleNeighbours(Node n, Position p){
        int posX,posY;
        
        posX = p.getPosX()/Configuration.cellSize;
        posY = p.getPosY()/Configuration.cellSize;
        List<Node> possibleNeighbours = new ArrayList<Node>(); 
                     
		int numberCells = (int)Math.ceil((double)n.getCommunicationRadio()/Configuration.cellSize);
		
		String position = "";
		for(int i = -numberCells; i <= numberCells; i++){
			for(int j = -numberCells; j <= numberCells; j++){
				if((posX+i) < 0 || (posY+j) < 0)
					continue;
				
				position = (posX+i)+","+(posY+j);
				
				Collection<Node> list = null;
				if(this.sensorsList.containsKey(position)){
					list = this.sensorsList.get(position).getHashSensors().values();
					
					Iterator<Node> it = list.iterator();
					while(it.hasNext()){
						Node sensor = it.next();
						if(n.compareTo(sensor) == 0)
							continue;
						
						if(n.getConectivityModel().isNear(n, sensor))
			                possibleNeighbours.add(sensor);
					}
					
	            }
			}
		}
        return possibleNeighbours;
    }
}

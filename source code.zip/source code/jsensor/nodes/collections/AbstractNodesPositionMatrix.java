/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.collections;

import java.util.List;
import jsensor.nodes.Node;
import jsensor.utils.Position;

/**
 * This class is the abstract class for representing all Nodes Matrices.
 * Each NodeMatrix should be an instance of this class.
 * A NodeMatrix is composed by an matrix with each cell stores an 
 * AbstractNodesList. 
 * @author danniel
 */
public abstract class AbstractNodesPositionMatrix {
    protected AbstractNodesList[][] sensorsList;
    protected int dx,dy;
    protected int nodesIHave;
    
    /**
     * Retrieve a NodeList located at position (x,y).
     * @param x - the x-position of the NodeList
     * @param y - the y-position of the NodeList
     * @return the NodeList located at (x,y)
     */
    public abstract AbstractNodesList getSensorAt(int x, int y);
    
    /**
     * Change the position of a Node wich is located inside a NodeList.
     * The Node is removed from its old list and added to a newer one.
     * @param n - the node to change its position
     * @param oldPosition - the old position where the node was located
     * @param newPosition - the new position where the node should be stored
     * @return a boolean representing if the operation succeed of failed.
     */
    public abstract boolean changeSensorPosition(Node s,Position oldPosition,Position newPosition);
    
    /**
     * Rebuild the current NodeMatrix and add the content of nodes
     * into this new matrix.
     * @param nodes - the set of NodesList to be added.
     */
    public abstract void rebuild(AbstractNodesList sensors);
    
    /**
     * Retrieve a set of Nodes which can be the possible neighbour of the Node n.
     * @param n - the node whose neighbours should be listed
     * @param p - the current position of the node
     * @return a set of Nodes containing the possible neighbours of the Node n
     */
    public abstract List<Node> possibleNeighbours(Node s, Position p);
    
    public int size(){
        return this.nodesIHave;
    }
    

}

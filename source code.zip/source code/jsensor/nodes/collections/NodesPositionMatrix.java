/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.collections;

import java.util.LinkedList;
import java.util.List;
import jsensor.nodes.Node;
import jsensor.utils.Configuration;
import jsensor.utils.Position;

/**
 * This class is an implementation of AbstractNodesPositionMatrix. It stores
 * Nodes into AbstractNodesLists.
 * @author danniel
 */
public class NodesPositionMatrix extends AbstractNodesPositionMatrix{
   
    public NodesPositionMatrix(NodesList nodes) {
        dx = (int)Math.ceil(Configuration.dimX/Configuration.cellSize);
        dy = (int)Math.ceil(Configuration.dimY/Configuration.cellSize);
        this.sensorsList = new NodesList[dx + 1][dy + 1];

        for(int i = 0; i < dx + 1; i++){
            for(int j = 0; j < dy + 1; j++){
                this.sensorsList[i][j] = new NodesList();
            }
        }

        for(Node n:nodes.getNodesList()){
            int posX = n.getPosition().getPosX()/Configuration.cellSize;
            int posY = n.getPosition().getPosY()/Configuration.cellSize;

            this.sensorsList[posX][posY].addNode(n);
        }
    }

    @Override
    public AbstractNodesList getSensorAt(int x, int y){
        return this.sensorsList[x][y];
    }

    @Override
    public boolean changeSensorPosition(Node n,Position oldPosition,Position newPosition){

        int ox,oy,nx,ny;
        ox = oldPosition.getPosX()/Configuration.cellSize;
        oy = oldPosition.getPosY()/Configuration.cellSize;
        nx = newPosition.getPosX()/Configuration.cellSize;
        ny = newPosition.getPosY()/Configuration.cellSize;
        return this.sensorsList[ox][oy].removeNode(n)
                && this.sensorsList[nx][ny].addNode(n);

    }

    @Override
    public void rebuild(AbstractNodesList nodes){
        
        for(int i = 0; i < dx; i++){
            for(int j = 0; j < dy; j++){
                this.sensorsList[i][j] = new NodesList();
            }
        }


        for(Node n:nodes.getNodesList()){
            int posX = n.getPosition().getPosX()/Configuration.cellSize;
            int posY = n.getPosition().getPosY()/Configuration.cellSize;
            this.sensorsList[posX][posY].addNode(n);
        }

    }

    @SuppressWarnings("unchecked")
	@Override
    public List<Node> possibleNeighbours(Node n, Position p){

        int posX,posY;
        posX = p.getPosX()/Configuration.cellSize;
        posY = p.getPosY()/Configuration.cellSize;
        List<Node> possibleNeighbours = new LinkedList<Node>();

        possibleNeighbours.addAll(this.sensorsList[posX][posY].getNodesList());


        possibleNeighbours.remove(n);

        if(posX < dx - 1 && posY < dy - 1 && posX > 0 && posY > 0){
            for(int i = -1; i <=1; i++)
                for(int j = - 1; j <= 1; j++){
                    LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posX == dx - 1 && posY < dy - 1 && posX > 0 && posY > 0){
            for(int i = -1; i <=0; i++)
                for(int j = - 1; j <= 1; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posX < dx - 1 && posY == dy - 1 && posX > 0){
            for(int i = -1; i <=1; i++)
                for(int j = - 1; j <= 0; j++){
                    LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }


        }else if(posX == dx - 1 && posY == dy - 1){
             for(int i = -1; i <=0; i++)
                for(int j = - 1; j <= 0; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }


        }else if(posX == 0 && posY > 0 && posY < dy - 1){
             for(int i = 0; i <=1; i++)
                for(int j = -1; j <= 1; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posY == 0 && posX > 0 && posX < dx - 1){
             for(int i = -1; i <= 1; i++)
                for(int j = 0; j <= 1; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posX == 0 && posY == 0){
             for(int i = 0; i <=1; i++)
                for(int j = 0; j <= 1; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posX == 0 && posY ==dy - 1){
             for(int i = 0; i <=1; i++)
                for(int j = - 1; j <= 0; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }else if(posY == 0 && posX == dx - 1){
             for(int i = -1; i <=0; i++)
                for(int j = 0; j <= 1; j++){
                        LinkedList<Node> nl = (LinkedList<Node>) ((LinkedList<Node>) this.sensorsList[posX + i][posY + j].getNodesList()).clone();
                    for(Node node:nl){
                        possibleNeighbours.add(node);
                    }
                }

        }

        return possibleNeighbours;
    }
}

package jsensor.utils;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import jsensor.runtime.Jsensor;

public class Writer 
{
	private String diretoryName;
	
	public Writer(String diretoryName) {
		this.diretoryName = diretoryName;
	}
	
	public BufferedWriter fileWriter(String tipo) throws IOException
	{	
		File diretorio;

		//Cria um diret�rio
		diretorio = new File(Jsensor.directoryPath, diretoryName);
		diretorio.mkdirs();

		//Cria um arquivo
		File arquivo = new File(diretorio, tipo + ".txt");
		//arquivo.createNewFile();
	
		//Prepara o escritor de arquivos
		FileWriter fw = new FileWriter(arquivo, true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		return bw;
	}
	
	
	public void LogMsg(BufferedWriter file, String msg) throws IOException
	{	
		//Prepara Buffer apra receber o texto
		BufferedWriter saida = file;
	
		//Transfere o texto para o arquivo
		saida.write(msg);

		//saida.flush();
	}

}

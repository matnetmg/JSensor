package jsensor.utils;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.SortedSet;

import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.runtime.Jsensor;

class StartNodes{
	private int node;
	private int target;
	private long time;
	
	public StartNodes(int node, int target, long time){
		this.node = node;
		this.target = target;
		this.time = time;
	}
	
	public int getNode(){
		return this.node;
	}
	
	public int geTarget(){
		return this.target;
	}
	
	public long getTime(){
		return this.time;
	}
}

public class GenerateFilesOmnet {
	private static Writer writerOmnet = new Writer("Results/files_"+Configuration.dateName);
	private static String newLine = System.getProperty("line.separator"); 
	private static ArrayList<StartNodes> startNodesList = new ArrayList<StartNodes>();
	
	public static void addStartNode(int node, int target, long time){
		startNodesList.add(new StartNodes(node, target, time));
	}
	
	public static void generateStartNodes(){
		try {
			
			BufferedWriter startSensorsOmnet = writerOmnet.fileWriter("startNodes"+Configuration.numberNodes[0]);
			for( StartNodes startNodes : startNodesList){
				writerOmnet.LogMsg(startSensorsOmnet, startNodes.getNode()+ " " +startNodes.geTarget()+ " " +startNodes.getTime()+" \n"); 
			}
			
			startSensorsOmnet.flush();
			startSensorsOmnet.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void generateSensorsConnectionsPositions(AbstractNodesList[] lists){
		BufferedWriter fileNodesOmnet;
		BufferedWriter fileConnectionsOmnet;
		BufferedWriter filePositions;
		
		HashMap<String, Tuple<Integer, Integer>> semDupplicatas = new HashMap<String, Tuple<Integer,Integer>>();
		
		try {
			fileNodesOmnet = writerOmnet.fileWriter("nodes"+Configuration.numberNodes[0]);
			fileConnectionsOmnet = writerOmnet.fileWriter("Dynamic.ned");
			filePositions = writerOmnet.fileWriter("positions"+Configuration.numberNodes[0]);
			
			for(AbstractNodesList list: lists)
	        {
	        	for(Node node : list.getNodesList())
	        	{    		
	        		writerOmnet.LogMsg(fileNodesOmnet, (new StringBuilder("").append(node.getID()).append("\t").append(node.getID()).append("\t").append("node.Flood").append(newLine).toString()));
	        		writerOmnet.LogMsg(filePositions, (new StringBuilder("").append(node.getID()).append("\t").append(node.getPosition().posX).append("\t").append(node.getPosition().posY).append(newLine).toString()));
	        		
	        		SortedSet<Node> vizinhos = node.getNeighbours().getNodesList();
	        		Iterator<Node> it = vizinhos.iterator();
	        		       		
	        		while(it.hasNext()){
	        			Node neighbor = it.next();
	        			String key = node.getID()+ "-"+ neighbor.getID();
	        			String inverseKey = neighbor.getID()+ "-"+ node.getID();
	        			
	        			if(semDupplicatas.containsKey(key) || semDupplicatas.containsKey(inverseKey)){
	        				continue;
	        			}
	        			else
	        				semDupplicatas.put(key, new Tuple<Integer, Integer>(node.getID(), neighbor.getID()));
	        					
	        		}
	        	}
	        }
			
			writerOmnet.LogMsg(fileConnectionsOmnet, "package networks;\n\nimport ned.DatarateChannel;\nimport node.Node;\n\nnetwork Dynamic{");
			writerOmnet.LogMsg(fileConnectionsOmnet, "\n\ttypes:\n\t\tchannel C extends DatarateChannel {\n\t\t\tparameters:\n\t\t\t\tdelay = default(0.1ms);\n\t\t\t\tdatarate = default(1Gbps);\n\t\t\t}");
			writerOmnet.LogMsg(fileConnectionsOmnet, "\n\tsubmodules:\n\t\trte["+Jsensor.numNodes +"] : Node {\n\t\t\tparameters:\n\t\t\t\taddress = index;\n\t\t}\n");


			writerOmnet.LogMsg(fileConnectionsOmnet, "\n\tconnections allowunconnected:");
			
			
			
			for(Tuple<Integer, Integer> tuple : semDupplicatas.values()){
				writerOmnet.LogMsg(fileConnectionsOmnet, "\n\t\trte[" +(tuple.getFirst() -1) + "].port++ <--> C <--> rte["+(tuple.getSecond() -1)+"].port++;");
				
			}
			
			writerOmnet.LogMsg(fileConnectionsOmnet, "\n}");
			
			fileNodesOmnet.flush();
			fileConnectionsOmnet.flush();
			filePositions.flush();
			fileNodesOmnet.close();
			fileConnectionsOmnet.close();
			filePositions.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}

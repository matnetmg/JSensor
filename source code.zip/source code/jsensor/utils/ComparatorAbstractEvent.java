package jsensor.utils;

import java.util.Comparator;

import jsensor.nodes.events.AbstractEvent;

public class ComparatorAbstractEvent implements Comparator<AbstractEvent>{

	@Override
	public int compare(AbstractEvent o1, AbstractEvent o2) {
		if(o1.getFireTime() < o2.getFireTime())
			return -1;
		else{
			if(o1.getFireTime() == o2.getFireTime()){
				if(o1.getNodeFactID() < o2.getNodeFactID())
					return -1;
				else{
					if(o1.getNodeFactID() == o2.getNodeFactID()){
						return o1.getID().compareTo(o2.getID());
					}
					return 1;
				}
			}
			return 1;
		}
	}
}
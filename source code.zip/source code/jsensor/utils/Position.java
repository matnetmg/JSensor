/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.utils;

import java.io.Serializable;

/**
 * This class represents a position (x,y) of an object within the simulation.
 * @author danniel
 */
@SuppressWarnings("serial")
public class Position implements Serializable{

    int posX;
    int posY;

    public Position(int posX, int posY) {
        this.posX = posX;
        this.posY = posY;
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Position))
            return false;

        return (this.posX == ((Position)obj).posX ) && (this.posY == ((Position)obj).posY );
    }

    @Override
    public String toString() {
        return "Pos X: " + this.posX + " PosY: " + this.posY;
    }
}

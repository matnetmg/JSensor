package jsensor.utils;

import java.util.SortedSet;

import jsensor.nodes.events.AbstractEvent;
import jsensor.nodes.events.EventQueue;

public class CellChunk {
	private EventQueue factEventsToHandle;
	
	public CellChunk(){
		this.factEventsToHandle = new EventQueue();
	}
	
	public void addEventToHandle(AbstractEvent ae)
    { 
		this.factEventsToHandle.addCellEventToHandle(ae, ae.getNodeFactID());
    }
	
	public SortedSet<AbstractEvent> getEvents(){
		return this.factEventsToHandle.getAllEvents();
	}
	

}

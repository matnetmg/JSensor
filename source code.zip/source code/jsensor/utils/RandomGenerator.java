package jsensor.utils;

import java.util.Random;

/**
 * This class represents a easy way of provide random numbers for simulations based in chunks.
 * @author matheus
 *
 */
public class RandomGenerator {
	private long seed;
	private Random r;
	
	/**
	 * Creates a new random number generator using a single long seed. The seed is the initial value of the internal state of the pseudorandom number generator which is maintained by method next.
	 * @param seed - the initial seed.
	 */
	public RandomGenerator(long seed){
		this.seed = seed;
		r = new Random(seed);
	}
	
	/**
	 * This method returns a long seed used to generate the random numbers. 
	 * @return the seed used to generate the random numbers.
	 */
	public long getSeed(){
		return seed;
	}
	
	
	/**
	 * This method returns an random number of int type between 0 (inclusive) and the specified value (exclusive).
	 * @param n - the bound on the random number to be returned. Must be positive.
	 * @return the next pseudorandom, uniformly distributed int value between 0 (inclusive) and n (exclusive) from this random number generator's sequence.
	 */
	public int nextInt(int n){
		return r.nextInt(n);
	}
	
	/**
	 * Returns the next pseudorandom, uniformly distributed int value from this random number generator's sequence.
	 * @return the next pseudorandom, uniformly distributed int value from this random number generator's sequence.
	 */
	public int nextInt(){
		return r.nextInt();
	} 
	
	/**
	 * Returns the next pseudorandom, uniformly distributed double value between 0.0 and 1.0 from this random number generator's sequence.
	 * @return the next pseudorandom, uniformly distributed double value between 0.0 and 1.0 from this random number generator's sequence.
	 */
	public double nextDouble(){
		return r.nextDouble();
	}
	
	/**
	 * Returns the next pseudorandom, uniformly distributed boolean value from this random number generator's sequence.
	 * @return the next pseudorandom, uniformly distributed boolean value from this random number generator's sequence.
	 */
	public boolean nextBoolean(){
		return r.nextBoolean();
	}
	
	/**
	 * Returns the next pseudorandom, uniformly distributed long value from this random number generator's sequence.
	 * @return the next pseudorandom, uniformly distributed long value from this random number generator's sequence.
	 */
	public long nextLong(){
		return r.nextLong();
	}
	
	/**
	 * Returns the next pseudorandom, uniformly distributed float value between 0.0 and 1.0 from this random number generator's sequence.
	 * @return the next pseudorandom, uniformly distributed float value between 0.0 and 1.0 from this random number generator's sequence.
	 */
	public float nextFloat(){
		return r.nextFloat();
	}

}

package projects.MobilePhone.DSRAlgorithm;

public class DSRMessageTransmissionModel {
    private static final int time = 1;
    
    public static int timeToReach() {
        return time;
    }
}

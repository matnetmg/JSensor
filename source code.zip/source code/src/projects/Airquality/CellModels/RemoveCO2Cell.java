package projects.Airquality.CellModels;

import jsensor.runtime.Jsensor;
import jsensor.nodes.Node;
import jsensor.nodes.monitoring.CellModel;
import jsensor.nodes.monitoring.HandleCells;
import projects.Airquality.Nodes.BigTree;
import projects.Airquality.Nodes.MediumTree;
import projects.Airquality.Nodes.SmallTree;

public class RemoveCO2Cell extends HandleCells {

	@Override
	public void fire(Node node, CellModel cell) {
		GridCell cellToChange = (GridCell) cell;
		if(node instanceof BigTree){
			BigTree bigTree = (BigTree)node;
			
			double co2level = cellToChange.getco2();
			cellToChange.setco2(co2level * BigTree.reduction);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" Big Tree: "+ bigTree.getID()+ " Consuming CO2");
	    	   
		}else if(node instanceof MediumTree){
			MediumTree mediumTree = (MediumTree) node;
			
			double co2level = cellToChange.getco2();
			cellToChange.setco2(co2level * SmallTree.reduction);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" medium Tree: "+ mediumTree.getID()+ " Consuming CO2");
			
		}else if(node instanceof SmallTree){
			SmallTree smallTree = (SmallTree) node;
			
			double co2level = cellToChange.getco2();
			cellToChange.setco2(co2level * SmallTree.reduction);
	    	Jsensor.log("Time: - "+ Jsensor.currentTime +" Small Tree: "+ smallTree.getID()+ " Consuming CO2");
			
		}
	}
}

package projects.Airquality.Facts;

import projects.Airquality.CellModels.GridCell;
import jsensor.nodes.events.EventModel;
import jsensor.nodes.monitoring.CellModel;
import jsensor.runtime.Jsensor;

public class RainFact extends EventModel
{
	@Override
	public CellModel setValue(CellModel cell) {
		((GridCell)cell).setWater( ((GridCell)cell).getWater() + Jsensor.getNodeByID(1).getRandom().nextFloat()*150 );
		return cell;
	}

	@Override
	public RainFact clone() {
		return new RainFact();
	}
}
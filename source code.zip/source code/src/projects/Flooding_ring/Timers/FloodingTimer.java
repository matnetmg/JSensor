package projects.Flooding_ring.Timers;

import jsensor.nodes.events.TimerEvent;
import jsensor.runtime.Jsensor;
import projects.Flooding_ring.Messages.FloodingMessage;



public class FloodingTimer
  extends TimerEvent
{
  public FloodingTimer() {}
  
  public void fire()
  {
    int nodeID = node.getID() + 5000;
    if (nodeID > Jsensor.numNodes) {
      nodeID -= Jsensor.numNodes;
    }
    


    FloodingMessage message = new FloodingMessage(node.getID(), nodeID, 0, ""+node.getID(), node.getChunk());
    
    String messagetext = Integer.toString(node.getID()) + " - ";
    
    message.setMsg(messagetext);
    Jsensor.log("time: " + Jsensor.currentTime + "\t sensorID: " + node.getID() + "\t sendTo: " + nodeID);
    

    node.multicast(message);
  }
}
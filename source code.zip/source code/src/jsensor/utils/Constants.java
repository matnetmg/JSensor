package jsensor.utils;

public class Constants 
{
	public final static int SENDING_EVENT = 1;
	public final static int MOVEMENT_EVENT = 2;
	public final static int ABSTRACT_TIMER = 3;
}
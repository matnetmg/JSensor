package jsensor.utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesLoader
{
	private FileInputStream file;
	private Properties properties;
	
	public PropertiesLoader(String nameFile) throws IOException
	{
		try{
			this.properties = new Properties();
			if(nameFile.contains("\\") || nameFile.contains("/")){
				this.file = new FileInputStream(nameFile);
			}
			else{
				File f = findFile(new File(new File("").getAbsolutePath()), nameFile);
				this.file = new FileInputStream(f);
			}
			
		    this.properties.load(file);
		}catch(FileNotFoundException | NullPointerException ex){
			System.err.println("The settings file "+nameFile+" does not exist.");
			System.exit(1);
		} 
	}

	public String getValor(String chave)
	{  
        return properties.getProperty(chave);  
	}
	
	public static File findFile(File initialPath, String file)
    {
    	File myFile = null;
        if(initialPath.exists()){
            File contents[] = initialPath.listFiles();
            for(int i = contents.length - 1; i >= 0; i--){
            	if(contents[i].getName().equals(file)){
            		myFile = contents[i];
                }
            	
                if(contents[i].isDirectory()){
                	myFile = findFile(contents[i], file);
                }
                
                if(myFile !=null)
                	return myFile;
            }
        }
        return myFile;
    }
}
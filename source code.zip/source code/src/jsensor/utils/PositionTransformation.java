/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.utils;

import jsensor.runtime.Jsensor;

/**
 * This class is used to transform a Position into a GUI Position.
 * @author danniel
 */
public class PositionTransformation {

   
    public static int getGuiDimX(int posX){
        int dx = 0;
        double dx2 = 0;
        
        dx2 = (dx % Math.floor(Configuration.dimX / Jsensor.quadNumber));
        dx = (int) (dx2 * Jsensor.quadNumber) ;
  
        return dx;
    }

    public static int getGuiDimY(int posY){
        int dy = 0;
        double dy2 = 0;
 
        dy2 = (dy % Math.floor(Configuration.dimX / Jsensor.quadNumber));
        dy = (int) (dy2 * Jsensor.quadNumber) ;

        return dy;
        
    }

    public static Position getDim(int dx, int dy){
        Position pos = new Position(getGuiDimX(dx), getGuiDimY(dy));

        return pos;
    }
}

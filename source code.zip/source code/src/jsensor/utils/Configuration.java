/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.utils;


import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.nodes.models.MessageTransmissionModel;


/**
 * This class stores all simulation variables.
 * @author danniel
 */
public class Configuration {

	// código de testes
	public static String nomeTeste = "";
	public static String instanciaTeste = "";
	public static String pathTotal = "";
		
	public static enum StopBy {
		ALL,
		messages,
		mobility
	}
	
	public static int numberofcells = 0;
	
	public static synchronized void addcell(){
		numberofcells++;
	}
	
	public static String projectName = "";
	public static int dimX = 0;
    public static int dimY = 0;
    public static boolean assynchronousMode = true;
    public static boolean log_debug = true;
    public static boolean log_jsensor = true;
    public static boolean log_user = true;
    public static boolean log_omnet = false;
    
    public static long numberOfRounds = 0;
    public static long numberOfEvents = 0;
    public static long estimateCells = 0;
    public static StopBy stop_by = StopBy.messages;
    public static int refreshRate = 1;
    public static long seedRandom = 0;
    public static int numberOfThreads = Runtime.getRuntime().availableProcessors();
    public static final byte numberOfChunks = (byte) Runtime.getRuntime().availableProcessors();
    public static String applicationPath = "";
    public static String projectPath = "";
    public static boolean hasMobility = false;
    public static boolean hasFacts = false;
    
    public static Constructor<?> myCellConstructor = null; 
    public static MessageTransmissionModel messageTransmissionModel = null;
    public static int cellSize = 0;
    public static String[] nodeNames;
    public static String[] factNames;
    
    public static boolean interference;
    
    public static Constructor<?>[] distributionModels;
    public static Constructor<?>[] mobilityModels;
    public static Constructor<?>[] connectivityModels;
    public static Constructor<?>[] interferenceModels;
    public static Constructor<?>[] reliabilityModels;
    public static Constructor<?>[] nodeTypes;
    public static int[] nodeRadios;
    public static int[] communicationRadios;
    public static int[] numberNodes;
    
    public static int[] numberFacts;
    public static float[] factStartValues;
    public static float[] factDurations;
    public static float[] factStarts;
    public static int[] factRadius;
    public static int[] factSteps;
    public static Constructor<?>[] factDistributionModels;
    public static Constructor<?>[] factTypes;
    
    public static String dateName = "";
    
    public static boolean positionChanged = true;
    
    public static HashMap<String,String> params = new HashMap<String, String>();
    public static boolean distributed = false;
    @SuppressWarnings("rawtypes")
	public static ArrayList[] threads;
    public static boolean virtualThread = false;
    
    @SuppressWarnings("unchecked")
	public static void threadLists(){
    	if(Configuration.numberOfThreads < Configuration.numberOfChunks){
    		System.out.println("VIRTUAL THREADS #######################################");
    		threads = new ArrayList[Configuration.numberOfThreads];
    		virtualThread = true;
			for(int i = 0; i < Configuration.numberOfThreads; i++){
				threads[i] = new ArrayList<Integer>();
			}
			
			int idThread = Configuration.numberOfThreads;
			int count = 0;
			
			while(idThread < Configuration.numberOfChunks){
				threads[count].add(idThread++);
				count++;
				if(count == Configuration.numberOfThreads)
					count = 0;
			}
    	}
    }
    
    public static void readConfFilee(RandomAccessFile raf){
        String line = null;
        params = new HashMap<String, String>();
        
        try {
            
            while((line = raf.readLine()) != null){
                if(line.startsWith("--")) continue;
                if(line.equals("")) continue;
                if(line.equals(" ")) continue;
                if(line.equals("\n")) continue;
                if(line.equals("\b")) continue;
                
                StringTokenizer strtok = new StringTokenizer(line);
                String tok = strtok.nextToken("=");
                
                String param = tok.trim();
                
                tok = strtok.nextToken();
                
                String value = tok.trim();
                
                params.put(param, value);
                
                if(param.equals("dimX"))
                    dimX = Integer.parseInt(value);
                if(param.equals("dimY"))
                    dimY = Integer.parseInt(value);
            
                if(param.equals("assynchronousMode"))
                    assynchronousMode = Boolean.parseBoolean(value);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Configuration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    
    
    /**
     * Returns a Boolean value associated to the string parameter required
     * @param param - the String param that has to know the value
     * @return a boolean valeu of the String parameter
     */
    public static Boolean getBooleanConfigParam(String param){
        if(!params.containsKey(param))
            return null;
        
        return Boolean.parseBoolean(params.get(param));
    }
    
    /**
     * Returns a String value associated to the string parameter required
     * @param param - the String param that has to know the value
     * @return a String valeu of the String parameter
     */
    public static String getStringConfigParam(String param){
        if(!params.containsKey(param))
            return null;
        
        return params.get(param);
    }

    /**
     * Returns a Integer value associated to the string parameter required
     * @param param - the String param that has to know the value
     * @return a Integer valeu of the String parameter
     */
    public static Integer getIntegerConfigParam(String param){
        if(!params.containsKey(param))
            return null;
        
            return Integer.parseInt(params.get(param));
        
    }
    
    /**
     * Returns a Float value associated to the string parameter required
     * @param param - the String param that has to know the value
     * @return a Float valeu of the String parameter
     */
    public static Float getFloatConfigParam(String param){
        if(!params.containsKey(param))
            return null;
        
            return Float.parseFloat(params.get(param));
        
    }
    
    /**
     * Returns a Double value associated to the string parameter required
     * @param param - the String param that has to know the value
     * @return a Double valeu of the String parameter
     */
     public static Double getDoubleConfigParam(String param){
        if(!params.containsKey(param))
            return null;
        
        return Double.parseDouble(params.get(param));
        
    }
   
    


}

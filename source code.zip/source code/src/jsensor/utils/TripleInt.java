package jsensor.utils;

public class TripleInt{
	int a;
	int b;
	int c;
	
	public TripleInt(int a , int b, int c){
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	public int geta(){
		return this.a;
	}
	
	public int getb(){
		return this.b;
	}
	
	public int getc(){
		return this.c;
	}

	public void setA(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void setC(int c) {
		this.c = c;
	}
	
	
}

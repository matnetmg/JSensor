package jsensor.utils;

/**
 * This class represents a easy way of provide random numbers for simulations based in chunks.
 * @author matheus
 *
 */
public class IDAbstractFact {
	private int last;
	private int chunck;
	
	/**
	 * Creates a new random number generator using a single long seed. The seed is the initial value of the internal state of the pseudorandom number generator which is maintained by method next.
	 * @param seed - the initial seed.
	 */
	public IDAbstractFact(int chunck){
		this.last = 0;
		this.chunck = chunck;
	}
	
	/**
	 * This method returns a long seed used to generate the random numbers. 
	 * @return the seed used to generate the random numbers.
	 */
	public int getNextID(){
		int ID = (last + chunck);
		last += Configuration.numberOfChunks;
		return ID;
	}
}

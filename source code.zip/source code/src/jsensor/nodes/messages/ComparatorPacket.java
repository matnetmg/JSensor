package jsensor.nodes.messages;

import java.util.Comparator;

public class ComparatorPacket implements Comparator<Packet> {

	@Override
	public int compare(Packet o1, Packet o2) {
		if(o1.getDelayTime() < o2.getDelayTime())
			return -1;
		else{
			if(o1.getDelayTime() == o2.getDelayTime()){
				if(o1.getNode().getID() < o2.getNode().getID())
					return -1;
				else{
					if(o1.getNode().getID() == o2.getNode().getID())
						return o1.getID().compareTo(o2.getID());
					return 1;
				}
			}
			return 1;
		}
	}  
}

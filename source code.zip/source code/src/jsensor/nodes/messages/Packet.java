/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.messages;

import jsensor.nodes.Node;
import jsensor.runtime.Jsensor;
import jsensor.utils.Configuration;

/**
 * This class is encapsulate an incoming message.
 * @author danniel
 */
public class Packet implements Comparable<Packet>{
    private double delayTime;
    private Message message;
    private Node node;
    private Node target;
    private boolean sent;
    private ID ID;

    public Packet(Node sender,Node target,double delayTime, Message message) {
        
        this.node = sender;
        this.target = target;
        this.delayTime = delayTime;
        this.message = message;
        this.sent = false;
        this.ID = Jsensor.getPacketID(node.getID() % Configuration.numberOfChunks);
    }

    public Node getTarget() {
        return target;
    }

    public void setTarget(Node target) {
        this.target = target;
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public boolean hasSent() {
        return sent;
    }

    public void setSent(boolean sent) {
        this.sent = sent;
    }

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }
    
    public double getDelayTime() {
        return delayTime;
    }

    public void setDelayTime(double delayTime) {
        this.delayTime = delayTime;
    }
    
    public ID getID() {
        return ID;
    }

    public int compareTo(Packet o) {
    	if(this.delayTime < o.delayTime)
			return -1;
		else{
			if(this.delayTime == o.delayTime){
				if(this.node.getID() < o.node.getID())
					return -1;
				else{
					if(this.node.getID() == o.node.getID())
						return this.ID.compareTo(o.ID);
					return 1;
				}
			}
			return 1;
		}
    }

    @Override
    public String toString() {
        return "Packet{" + "delayTime=" + delayTime + ", node=" + node + ", target=" + target + '}';
    }

    
}

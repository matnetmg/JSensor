package jsensor.nodes;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.logging.Level;


import jsensor.Main;
import jsensor.models.ActivateNode;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.NodesList;
import jsensor.nodes.events.AbstractEvent;
import jsensor.nodes.events.TimerEvent;
import jsensor.nodes.events.EventQueue;
import jsensor.nodes.events.SendType;
import jsensor.nodes.events.SendingEvent;
import jsensor.nodes.messages.Inbox;
import jsensor.nodes.messages.Message;
import jsensor.nodes.messages.Packet;
import jsensor.nodes.models.ConnectivityModel;
import jsensor.nodes.models.InterferenceModel;
import jsensor.nodes.models.MobilityModel;
import jsensor.nodes.models.ReliabilityModel;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime.ThreadState;
import jsensor.utils.Configuration;
import jsensor.utils.IDInterval;
import jsensor.utils.Position;
import jsensor.utils.RandomGenerator;

/**
 * Class Sensor : base class for all user node implementations
 * @author danniel & Matheus
 */
public abstract class Node implements Comparable<Node> {
	private byte chunck;
    protected int ID;
    private Inbox inbox;
    private int communicationRadio;
    private boolean active = true;
    protected Position position;
    private AbstractNodesList neighbours;
    private MobilityModel mobilityModel;
    private ConnectivityModel conectivityModel;
    private InterferenceModel interferenceModel;
    private ReliabilityModel reliabilityModel;
    private jsensor.runtime.Runtime runtime;
    private boolean neighborhoodChange;
    private EventQueue messageEventsToHandle;
    private EventQueue timerEventsToHandle;
    private EventQueue movimentEventsToHandle;
    private ConcurrentSkipListSet<TimerEvent> timers;
    private ConcurrentSkipListSet<TimerEvent> timersToHandle;
    
    public Node(){
    	this.inbox = new Inbox();
    	this.neighbours = new NodesList();
    	this.neighborhoodChange = false;
    	this.messageEventsToHandle = new EventQueue();
    	this.timerEventsToHandle = new EventQueue();
    	this.movimentEventsToHandle = new EventQueue();
    	this.timers = new ConcurrentSkipListSet<TimerEvent>();
    	this.timersToHandle = new ConcurrentSkipListSet<TimerEvent>();
    }
    
    public int getCommunicationRadio(){
    	return this.communicationRadio;
    }
    
    public void setCommunicationRadio(int radio){
    	this.communicationRadio  = radio;
    }
    
    public byte getChunk(){
    	return this.chunck;
    }
    
    public void setChunk(byte chunk){
    	this.chunck  = chunk;
    }
    
    
    public RandomGenerator getRandom(){
    	return runtime.getMyRamdom(this.ID % Configuration.numberOfChunks);
    }
    
    /**
     * This method provides a random Node of a given type.
     * @param name - the name of the type nodes.
     * @return an random node of a given type, or null if the type does not exist.
     */
    public Node getRandomNode(String name){
    	IDInterval id = Jsensor.getIDInterval(name);
    	if(id != null){
    		return Jsensor.getNodeByID(id.getStart() + this.getRandom().nextInt(((id.getEnd() - id.getStart()) + 1)));
    	}
    	else{
    		System.err.println("the type of sensor "+name+" does not exist");
    		Main.LOG.log(Level.SEVERE, null, "the type of sensor "+name+" does not exist");
    		return null; 
    	}
    }

    /**
     * Return the current runtime of the application
     * @return the current runtime
     */
    public jsensor.runtime.Runtime getRuntime() {
        return runtime;
    }

    /**
     * Set the runtime for an application
     * @param runtime - the runtime to be applied for the simulation
     */
    public void setRuntime(jsensor.runtime.Runtime runtime) {
        this.runtime = runtime;
    }
    
    
    /**
     * Internal use only method.Do not use this method on your projects.
     * Set the node's position
     * @param posX - position in the x-axis 
     * @param posY - position in the y-axis
     */
    public void setPosition(int posX, int posY){
        Position p = new Position(posX, posY);
        this.position = p;
    }

    /**
     * Internal use only method.Do not use this method on your projects.
     * Set the node's position. 
     * @param pos - the Position that the node will assume
     */
    public void setPosition(Position pos){
        this.position = pos;
    }
    
    /**
     * Return the node's current position
     * @return the node's position
     */
    public Position getPosition() {
        return position;
    }
    
    // TODO coment�rios
    public void setID(int ID){
    	this.ID = ID;
    }
    
   /**
     * Return the nodes ID in the global network
     * @return the node's ID
     */
    public int getID() {
        return ID;
    }
    
    /**
     * Verify if a node is active.
     * @return true if the node is active, false otherwise
     */
    public boolean isActive() {

        return this.active;
    }
    
    /**
     * Activate the node.
     */
    public void activate() {

        this.active = true;
    }
    
    /**
     * Deactivate the node.
     */
    public void deactivate() {

        this.active = false;
    }
    
    /**
     * Deactivate the node.
     * @param timeInactive - How long the Node will be inactive
     */
    public void deactivate(int timeInactive) {

    	if(this.active){
    		this.active = false;
            ActivateNode an = new ActivateNode();
            an.setNodeToActivate(this);
            
            an.setNode(runtime.getFakeNode());
            an.setFireTime(Jsensor.currentTime + timeInactive);
            
            addEventToHandle(an, ThreadState.steping_timer);
    	}
    }

    /**
     * Return whether a node is equal to another using its id.
     * @param n - the node to be compared
     * @return true if the nodes are equal, else otherwise
     */
    public boolean equals(Node n){
        return this.ID == n.getID();
    }


    /**
     * Compare two nodes.
     * @param obj - the object to be compared with
     * @return true if obj is the current node, false otherwise
     */
    @Override
    public boolean equals(Object obj) {

        if(!(obj instanceof Node))
            return false;

        return this.ID == ((Node)obj).getID();
    }

    /**
     * Return a hashcode for this node
     * @return the hashcode
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + (int) (this.ID ^ (this.ID >>> 32));
        return hash;
    }

    /**
     * Compare two nodes.
     * @param o - the node to be compared
     * @return 1 if the node's ID is lower than o's ID, 0 if the two ID's are the same
     * or -1 otherwise
     */
    @Override
    public int compareTo(Node o) {
        if(this.ID < o.ID)
            return 1;
        if(this.ID == o.ID)
            return 0;
        else
            return -1;
    }

    
    /**
     * Return the string representation for this node
     * @return the string that represents this node
     */
    @Override
    public String toString() {
        return "[Node id="+this.ID + "]";
    }

    /**
     * Return the ConnectivityModel associated with this node
     * @return the ConnectivityModel of this node
     */
    public ConnectivityModel getConectivityModel() {
        return conectivityModel;
    }

    /**
     * Set the ConnectivityModel for this node
     * @param conectivityModel - the connectivity model to be associated with this node
     */
    public void setConectivityModel(ConnectivityModel conectivityModel) {
        this.conectivityModel = conectivityModel;
    }
    
    /**
     * Return the InterferenceModel associated with this node
     * @return the InterferenceModel of this node
     */
    public InterferenceModel getInterferenceModel() {
        return interferenceModel;
    }

    /**
     * Set the InterferenceModel for this node
     * @param InterferenceModel - the interference model to be associated with this node
     */
    public void setInterferenceModel(InterferenceModel interferenceModel) {
        this.interferenceModel = interferenceModel;
    }
    
    /**
     * Return the ReliabilityModel associated with this node
     * @return the ReliabilityModel of this node
     */
    public ReliabilityModel getReliabilityModel() {
        return reliabilityModel;
    }

    /**
     * Set the ReliabilityModel for this node
     * @param ReliabilityModel - the reliability model to be associated with this node
     */
    public void setReliabilityModel(ReliabilityModel reliabilityModel) {
        this.reliabilityModel = reliabilityModel;
    }

    /**
     * Return the MobilityModel associated with this node
     * @return the node's MobilityModel
     */
    public MobilityModel getMobilityModel() {
        return mobilityModel;
    }

    /**
     * Set the MobilityModel for this node
     * @param mobilityModel - the MobilityModel to be associated with this node
     */
    public void setMobilityModel(MobilityModel mobilityModel) {
        this.mobilityModel = mobilityModel;
    }

   
    public Inbox getInbox() {
        return this.inbox;
    }
    
    public int getSizeInbox() {
        return this.inbox.getSize();
    }

    public void setInbox(Inbox inbox) {
        this.inbox = inbox;
    }


    public AbstractNodesList getNeighbours() {
        return neighbours;
    }

    public void setNeighbours(AbstractNodesList neighbours) {
        this.neighbours = neighbours;
    }

    public boolean isNeighborhoodChange() {
        return neighborhoodChange;
    }

    public void setNeighborhoodChange(boolean neighborhoodChange) 
    {
        this.neighborhoodChange = neighborhoodChange;
    }

    /**
     * Add a new timer for synchronous simulation
     * @param t - the timer to be added
     */
    public void addTimer(TimerEvent t){
        this.timers.add(t);
    }

    /**
     * Add a new event to be handled by this node
     * @param ae - the AbstractEvent to be handled
     */
    public void addEventToHandle(AbstractEvent ae, ThreadState state)
    { 
    	switch (state) {
			case steping_timer:{
				this.timerEventsToHandle.addEventToHandle(ae);
				break;
			}
			case steping_moviment:{
				this.movimentEventsToHandle.addEventToHandle(ae);
				break;
			}
			default:{
				System.out.println("Inserir outros estados no addEventToHandle da classe nodes");
				break;
			}
			
		}
        
    }
    
    /**
     * Send a message using multicast. The Message m is sent to every node's neighbour.
     * The message will be sent at delayTime. If the current simulation
     * is synchronous, a new packet is added to every neighbour of this node. If the current simulation is
     * assynchronous, the message will be treated as a new event to be handled in the future.
     * @param message - the message to be sent
     * @param delayTime - the time when the message shall be sent
     */
    public void multicast(Message message)
    {
        if(Configuration.assynchronousMode)
        {
        	double delayTime = Configuration.messageTransmissionModel.timeToReach(this, null, message);
            SendingEvent se = new SendingEvent(message, this, null, Jsensor.currentTime + delayTime, SendType.broadcast);
            
            this.messageEventsToHandle.addEventToHandle(se);
            
        }
    }
    
    /**
     * Send a message directly to a specific Node. The message message will be sent to his target at the time
     * defined by the message transmission model . If the current simulation is synchronous, 
     * the packet will be added to target's inbox. Otherwise, it will be treated as an event to be handled
     * in the future.
     * @param message - the message to be sent
     * @param target - the target of the message
     */
    public void unicast(Message message,Node target)
    {
        if(Configuration.assynchronousMode)
        {	
        	double delayTime = Configuration.messageTransmissionModel.timeToReach(this, target, message);
        	Packet p = new Packet(this, target, Jsensor.currentTime + delayTime, message.clone());
        	
        	if(this.getReliabilityModel().reachesDestination(p)){
        		SendingEvent se = new SendingEvent(message, this, target, Jsensor.currentTime + delayTime, SendType.unicast);
        		this.messageEventsToHandle.addEventToHandle(se);
        	}
            
        }
       
    }
    

    
 /*   *//**
     * Define the actions for the step phase in synchronous simulation.
     * First, the Node#preStep() is called. Then, evaluate if the node's neighbour
     * has changed. In case of change, the Node#neighborhoodChange()                                 is called.
     * <br>
     * The next step is evaluate all timers of this node. Then Node#handleMessage() is called
     * to treat all received messages. Lastly, the method Node#posStep() is called to handle
     * the actions that might occurr after when the step ends.
     */
    public void step(){

        setNeighborhoodChange(false);

     
        for(TimerEvent t:timers){
            
            
            if(t.getFireTime() <= Jsensor.currentTime && t.getFireTime() > Jsensor.currentTime-1){
                timers.remove(t);
                timersToHandle.add(t);
                
            }

        }


        for(TimerEvent t:timersToHandle){
            
            t.fire();
        }

        handleMessages(this.inbox);

    }
    
    public void addToInbox(Message m,Node sender,Node target, double delayTime)
    {
        this.inbox.addToInbox(sender, target, delayTime, m);
    }
    

    /**
     * The step phase for assynchronous simulation. This method is responsible for handle
     * all events whose fireTime is lower than time.
     * @param time - the second to be evaluated
     */
    public void step(long time, ThreadState state){
    	Iterator<AbstractEvent> it = null;
    	
    	switch (state) {
			case steping_messages:{
				SortedSet<AbstractEvent> li = this.messageEventsToHandle.getEventLowerThan(time);
				it = li.iterator();
				break;
			}
			case steping_timer:{
				SortedSet<AbstractEvent> li = this.timerEventsToHandle.getEventLowerThan(time);
				it = li.iterator();
				break;
			}
			case steping_moviment:{
				SortedSet<AbstractEvent> li = this.movimentEventsToHandle.getEventLowerThan(time);
				//Jsensor.addEventsTimer(li.size());
				it = li.iterator();
				break;
			}
			
			default:
				break;
		}
    	
    	while(it.hasNext()){
    		AbstractEvent ae = it.next();
        	
            Jsensor.log_jsensor(String.format("Time %d - Node %d - Handling %s event", Jsensor.currentTime,this.getID(),ae.getName()));
                
        	if(ae.getNode().active)
        		ae.handle();
            
        	runtime.setRoundsDone(runtime.getRoundsDone() + 1); 
        }
    }
    
    /**
     * Update all connections of this node.
     */
    public void updateConnection(){
        this.neighbours = new NodesList();
         
        this.setNeighborhoodChange(this.getConectivityModel().updateConnection(this,Jsensor.runtime.getSensorsHash()));
    }

    /**
     * In synchronous simulation, this method is executed every round. In assynchronous simulation, this method is executed
     * every second of simulation. This method can be overwhited to specify what will happen to the incoming messages.
     * @param inbox - intance of Inbox. Used to retrieve all incoming messages from a node's inbox.
     * @see Node#step() for the calling sequence of the node methods.
     */
    public abstract void handleMessages(Inbox inbox);
    
    /**
     * Method used in synchronous simulation only. It is executed at the beginning of every step.
     * @see Node#step() for the calling sequence of the node methods.
     */
    //public abstract void preStep();
    
    /**
     * Method used in synchronous simulation only. It is executed at the end of every step.
     * @see Node#step() for the calling sequence of the node methods.
     */
    //public abstract void postStep();
    
    /**
     * Overwrite this method to specify what will happen whether a node's neighbourhood changes.
     * @see Node#step() for the calling sequence of the node methods.
     */
    //public abstract void neighborhoodChange();
    
    /**
     * This method is called when a new node is created. Overwhite this method to specify what
     * will happen when a node is created.
     */
    public abstract void onCreation();

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.SortedSet;

import jsensor.nodes.Node;


/**
 * This class is the abstract class for representing all Nodes Lists.
 * Each Nodes List is an instance of this class.
 * @author danniel & Matheus
 */
public abstract class AbstractNodesList {
    /**
     * Return a set of Nodes.
     * @return A LinkedList representing the NodesList.
     */
	public abstract SortedSet<Node> getNodesList();
    /**
     * Sets the NodeList
     * @param nodeList - The NodeList to be copied.
     */
    public abstract void setNodesList(LinkedList<Node> sensorsList);
    
    /**
     * Add a node to this NodeList.
     * @param n - the node to be added
     * @return a boolean representing if the operation succeeded or failed.
     */
    public abstract boolean addNode(Node s);
    
    /**
     * Remove a node from this list.
     * @param n - the node to be removed
     * @return a boolean representing if the operation succeeded or failed.
     */
    public abstract boolean removeNode(Node s);
    
    /**
     * Returns the size of the NodeList
     * @return the NodeList size.
     */
    public abstract int size();
    
    /**
     * Returns the iterator of the NodeList
     * @return the NodeList iterator.
     */
    public abstract Iterator<Node> iterator();
}

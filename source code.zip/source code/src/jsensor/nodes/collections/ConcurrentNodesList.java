/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.SortedSet;
import java.util.concurrent.ConcurrentSkipListSet;

import jsensor.nodes.Node;

/**
 * This class is an implementation of AbstractNodesList. 
 * It stores its nodes into ConcurrentSkipListSet to be thread safe.
 * @author danniel
 */
public class ConcurrentNodesList extends AbstractNodesList{

    private ConcurrentSkipListSet<Node> nodeList;

    public ConcurrentNodesList() {
        this.nodeList = new ConcurrentSkipListSet<Node>();
    }

    @Override
    public SortedSet<Node> getNodesList() {
        //return new LinkedList<Node>(nodeList);
    	return null;
    }

    @Override
    public void setNodesList(LinkedList< Node> nodeList) {
        this.nodeList = new ConcurrentSkipListSet<Node>(nodeList);
    }

    @Override
    public boolean addNode(Node n){
       if(!this.nodeList.contains(n))
           return this.nodeList.add(n);

       return false;
    }

    @Override
    public boolean removeNode(Node n){
        return this.nodeList.remove(n);
    }

    @Override
    public int size(){
        return this.nodeList.size();
    }


    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof ConcurrentNodesList)) return false;

        return nodeList.equals(((ConcurrentNodesList)obj).getNodesList());
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (this.nodeList != null ? this.nodeList.hashCode() : 0);
        return hash;
    }

	@Override
	public Iterator<Node> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}

package jsensor.nodes.collections;

import jsensor.nodes.events.AbstractEvent;
import jsensor.nodes.events.EventQueue;

public class FactEventsList {
	protected EventQueue factEventQueue = new EventQueue();
	
	
	/**
     * Framework internal use method. This method handle the fact events
     * which time is lower than time.
     * @param time - the time to handle all events
     */
    public void step(long time){
        for(AbstractEvent ae : this.factEventQueue.getEventLowerThan(time))
        {
            ae.handle();          
        }
    }
    
    public void addEventToHandle(AbstractEvent ae){
        this.factEventQueue.addEventToHandle(ae, 1);
    }

}

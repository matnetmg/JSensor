/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.SortedSet;

import it.unimi.dsi.fastutil.objects.ObjectRBTreeSet;
import jsensor.nodes.Node;

/**
 * This class is an implementation of AbstractNodesList.
 * It stores the Nodes into a simple LinkedList.
 * @author danniel
 */
public class NodesList extends AbstractNodesList{

    private ObjectRBTreeSet<Node> sensorList;

    public NodesList() {
        this.sensorList = new ObjectRBTreeSet<Node>();
    }

    
    public SortedSet<Node> getNodesList() {
        return sensorList;
    }

    public void setNodesList(LinkedList<Node> nodeList) {
    	System.out.println("Verificando se alguem usa esté método-- setnodelist classe Nodeslist");
        this.sensorList = new ObjectRBTreeSet<>(nodeList);
    }

    public boolean addNode(Node s){
    	return this.sensorList.add(s);
    }

    public boolean removeNode(Node s){
        return this.sensorList.remove(s);
    }

    public int size(){
        return this.sensorList.size();
    }
    
    public Iterator<Node> iterator(){
        return this.sensorList.iterator();
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof NodesList)) return false;

        return sensorList.equals(((NodesList)obj).getNodesList());
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (this.sensorList != null ? this.sensorList.hashCode() : 0);
        return hash;
    }
}

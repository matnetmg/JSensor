/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.collections;

import java.util.HashMap;
import java.util.HashSet;
import jsensor.nodes.Node;

/**
 * This class does Nothing for now.
 * @author danniel
 */
public class NodesQuadrantMap {
    private HashMap<Integer,HashSet<Integer>> quadrantMap;
    
    public NodesQuadrantMap(){
        this.quadrantMap = new HashMap<Integer, HashSet<Integer>>();
    }
    
    
    public void createQuadrant(int quadNum){
        this.quadrantMap.put(quadNum,new HashSet<Integer>());
    }
    
    public boolean containsNode(int quadNum, Long node_id){
        return this.quadrantMap.get(quadNum).contains(node_id);
    }
    
    public HashSet<?> getQuadrant(int quadNum){
        return this.quadrantMap.get(quadNum);
    }
    
    public void addSensor(int quadrant,Node n){
        if(this.quadrantMap.containsKey(quadrant));
          this.quadrantMap.get(quadrant).add(n.getID());
    }
    
    public void removeSensor(int quadrant,Node n){
        if(this.quadrantMap.containsKey(quadrant))
          this.quadrantMap.get(quadrant).remove(n.getID());
    }
    
    public void remakeMap(){
        for(Integer q:this.quadrantMap.keySet()){
            this.quadrantMap.put(q, new HashSet<Integer>());
        }
    }
    
}

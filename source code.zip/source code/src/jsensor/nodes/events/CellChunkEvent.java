/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.events;


/**
 *
 * @author Matheus
 */
public class CellChunkEvent extends AbstractEvent{
	private EventModel afe;
	private String cell;
	
    public CellChunkEvent(EventModel afe, String cell, int nodeFactID) {
    	this.nodeFactID = nodeFactID;
        this.afe = afe;
    	this.cell = cell;
    }

    @Override
    public void handle(){
    	this.afe.handleSetValue(cell);
    }
}

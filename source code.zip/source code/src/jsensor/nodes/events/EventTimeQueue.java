package jsensor.nodes.events;

import java.util.Set;

import it.unimi.dsi.fastutil.ints.IntRBTreeSet;
import jsensor.runtime.Jsensor;
/**
 * This class represents the queue where the time of events will be stored.
 * This class is for internal use of the framework.
 * @author Matheus
 */

public class EventTimeQueue {

	private IntRBTreeSet queue;

	public EventTimeQueue(){
		this.queue = new IntRBTreeSet();
	}

	public int getFirst()
	{
		int first = this.queue.firstInt();
		this.queue.remove(first);
		
		return first;
	}

	public int size(){
		return queue.size();
	}
	
	public Set<Integer> getAll(){
		return (Set<Integer>) this.queue.clone();
	}

	public void addEventToHandle(int ae){
		if(ae > Jsensor.currentTime){
			synchronized (queue) {
				this.queue.add(ae);
				this.queue.add(ae + 1);
			}
		}
	}

	public boolean isEmpty(){	
		return this.queue.isEmpty();
	}

}


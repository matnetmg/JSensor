/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.events;

import java.util.logging.Level;

import jsensor.Main;
import jsensor.runtime.Jsensor;
import jsensor.nodes.monitoring.CellModel;
import jsensor.nodes.monitoring.CellController;
import jsensor.nodes.monitoring.Event;
import jsensor.utils.Configuration;
import jsensor.utils.ObjectTuple;
import jsensor.utils.RandomGenerator;

/**
 * Class that represents all Fact Events of the network. Extends this class
 * to implement a new Fact Event for your Facts.
 * @author Danniel & Matheus
 */
public abstract class EventModel extends AbstractEvent{

	protected Event fact;
    protected double startTime;
    protected double endTime;
    protected double step;
    protected double elapsedTime;
    
    /**
     * This method should return an exact copy of the Fact Event.
     * All objects within this class should make a new copy of its content
     * to another object of the same type.
     * @return an exact copy of this object
     */
    @Override
    public abstract EventModel clone();
    
    public abstract CellModel setValue(CellModel cell);
    
    /**
     * Start the event Fact change. Starting at starttime and lasting to endtime,
     * this method changes the Fact value according to its Fact#updateValue() procedure.
     * @param f - the fact to be handled
     * @param startime - the time when the fact begins to suffer updates
     * @param endTime - the time that the fact will last
     * @param step - the step for each fact update
     */
    public final void start(Event f, double startime,double endTime, double step){
    	this.fact = f;
    	this.startTime = startime;
        this.endTime = endTime;
        this.step = step;
        if(endTime <= 0 || step <= 0){
            System.err.println("Time and step must be greater than zero");
            System.exit(1);
        }
             
        if(Configuration.assynchronousMode){
        	EventModel afe = null;
            try {
            	afe = this.clone();
			} catch (ClassCastException ex) {
				System.err.println("There was a cast problem in your method clone (AbstractFactEvent).");
				Main.LOG.log(Level.SEVERE, null, ex);
				System.exit(1);
			} catch (NullPointerException ex) {
				System.err.println("The method clone (AbstractFactEvent) should not return null.");
				Main.LOG.log(Level.SEVERE, null, ex);
				System.exit(1);
			}
        	
        	afe.setFact(f);
        	afe.setStartTime(startime);
        	afe.setEndTime(endTime);
        	afe.setStep(step);
        	
            afe.setElapsedTime(0);
            afe.setNodeFactID(fact.getID());
            afe.fireTime = Jsensor.currentTime+ startime;
        
            f.addEventToHandle(afe);
        }else{
            System.err.println("Invalid assynchronous fact event for synchronous simulation");
            System.exit(1);
        }
    }
    
    /**
     * This method provides a RandomGenerator object, that is responsible for generating all pseudorandom numbers of the simulation. 
     * It's a easy way of provide random numbers based in chunks.
     * @return a RandomGenerator object that is used to get pseudorandom numbers.
     */
    public RandomGenerator getRandom(){
    	return Jsensor.runtime.getMyRamdom(this.fact.getID() % Configuration.numberOfChunks);
    }
    
    /**
     * This method provides a RandomGenerator object, that is responsible for generating all pseudorandom numbers of the simulation. 
     * It's a easy way of provide random numbers based in chunks.
     * @param chunk - The chunk of the object requesting the RandomGenerator.
     * @return a RandomGenerator object that is used to get pseudorandom numbers.
     */
    public RandomGenerator getRandom(int chunk){
    	return Jsensor.runtime.getMyRamdomCell(chunk);
    }
    
    /**
     * This method returns the elapsed time since the start of the fact. 
     * @return a double that represents the elapsed time since the start of the fact.
     */
    public double getElapsedTime() {
        return elapsedTime;
    }

    /**
     * This method set the elapsed time since the start of the fact. 
     * @param elapsedTime - A double that represents the elapsed time since the start of the fact
     */
    public void setElapsedTime(double elapsedTime) {
        this.elapsedTime = elapsedTime;
    }

    /**
     * This method returns the fact associate with the event. 
     * @return The fact associate with the event.
     */
    public Event getFact() {
        return fact;
    }
    
    /**
     * This method sets the fact associate with the event. 
     * @param fact - The fact associate with the event.
     */
    public void setFact(Event fact) {
        this.fact = fact;
    }

    /**
     * This method gets the start time of the event. 
     * @return A double that represents the start time of the event. 
     */
    public double getStartTime() {
        return startTime;
    }

    /**
     * This method sets the start time of the event. 
     * @param startTime - The fact associate with the event.
     */
    public void setStartTime(double startTime) {
        this.startTime = startTime;
    }

    /**
     * This method gets the step time of the event. 
     * @return A double that represents the step time of the event.
     */
    public double getStep() {
        return step;
    }

    /**
     * This method sets the step time of the event. 
     * @param step - The step time for event.
     */
    public void setStep(double step) {
        this.step = step;
    }

    /**
     * This method gets the end time of the event. 
     * @return A double that represents the end time of the event.
     */
    public double getEndTime() {
        return this.endTime;
    }
    
    /**
     * This method sets the end time of the event. 
     * @param time - The end time for event.
     */
    public void setEndTime(double time) {
        this.endTime = time;
    }
    
    /**
     * This method is an implementation of AbstractEvent#handle(). 
     * For Fact events, this method updates the fact value to the new one, according 
     * to its Fact#updateValue() method. This method is invoked for every update (according
     * to its step) to prevent the Event's stack to fast overgrow.
     */
    @Override
    public void handle() {
    	
		if((this.getFireTime()) > this.getEndTime())
            return;
        try {
    		for(ObjectTuple objectTuple : Jsensor.runtime.getSensorsHash().cellsHitByFactS(this.getFact().getPosition(), this.getFact().getRadius())){
    			CellChunkEvent ce = new CellChunkEvent(this, (String)objectTuple.getO1(), this.getFact().getID());
    			CellController.addFactEventChunk(ce, (int)objectTuple.getO2());
        	}
        }catch(ClassCastException ex){
    		System.err.println("There was a cast problem with your cell.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
    	}
        EventModel afe = null;
        try {
        	afe = this.clone();
        } catch (ClassCastException ex) {
			System.err.println("There was a cast problem in your method clone (AbstractFactEvent).");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		} catch (NullPointerException ex) {
			System.err.println("The method clone (AbstractFactEvent) should not return null.");
			Main.LOG.log(Level.SEVERE, null, ex);
			System.exit(1);
		}
        
        afe.setFact(this.getFact());
        afe.setElapsedTime(afe.getElapsedTime() + step);
        afe.setStartTime(this.getStartTime() + step);
        afe.setStep(this.step);
        afe.setNodeFactID(this.getFact().getID());
        afe.setEndTime(this.endTime);
        afe.fireTime = this.fireTime+ this.step;
        this.fact.addEventToHandle(afe);
    }
    
    public void handleSetValue(String cell){
    	Jsensor.runtime.getSensorsHash().setCell(this.setValue(Jsensor.runtime.getSensorsHash().getNodesList().get(cell)));
    }

	public void onCreation() {
		// TODO Auto-generated method stub
		
	}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.nodes.events;

/**
 * Enun representing the types of sending event.
 * It can be unicast or broadcast.
 * @author Danniel
 */
public enum SendType {
   unicast,
   broadcast,
   broadcastLoss
   
}

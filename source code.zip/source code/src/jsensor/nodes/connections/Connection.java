/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.connections;

import jsensor.nodes.Node;

/**
 *
 * @author danniel
 */
public interface Connection {

    public abstract void add(Node from, Node to);
    public abstract void remove(Node from, Node to);
    public abstract void removeAllConnections();
    public abstract boolean contains(Node from, Node to);
    public abstract long size();
}

package jsensor.nodes.monitoring;

public class EventDefault extends Event{

	@Override
	public double updateValue() {
		return 0;
	}

	@Override
	public void onCreation() {
	}

}

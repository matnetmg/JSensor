/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.nodes.models;

/**
 * Enun that represents all the possible model types.
 * @author danniel
 */
public class ModelType {

    public enum modelType{
        DistributionModel,
        ConnectivityModel,
        MobilityModel
    }

}

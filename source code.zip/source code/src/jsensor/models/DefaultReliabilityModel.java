package jsensor.models;

import jsensor.nodes.messages.Packet;
import jsensor.nodes.models.ReliabilityModel;

public class DefaultReliabilityModel extends ReliabilityModel{

	@Override
	public boolean reachesDestination(Packet p) {
		return true;
	}

}

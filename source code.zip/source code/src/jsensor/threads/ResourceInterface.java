/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.threads;

/**
 *
 * @author Danniel
 */
public interface ResourceInterface<S> {

    int getNumOfRegisters();

    S getRegister() throws Exception;

    void putRegister(S register);
    
}

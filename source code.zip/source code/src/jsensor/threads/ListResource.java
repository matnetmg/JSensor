/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.threads;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 *
 * @author Danniel
 */
public class ListResource<S> implements ResourceInterface<S> {

    protected ConcurrentLinkedQueue<S> registers;
    protected boolean finished;

    public ListResource() {
        this.registers = new ConcurrentLinkedQueue<S>();
        finished = false;
    }

    @Override
    public void putRegister(S register) {
        this.registers.offer(register);
        wakeup();

    }

    @Override
    public S getRegister() throws Exception {

        if (!this.registers.isEmpty()) {
            return this.registers.poll();
        } else {
            if (finished == false) {
                suspend();
            }
            return null;
        }
    }
    
    public boolean contains(S obj){
        return this.registers.contains(obj);
    }

    private synchronized void suspend() throws Exception {
        wait();
    }

    private synchronized void wakeup() {
        notify();
    }

    @Override
    public int getNumOfRegisters() {
        return this.registers.size();
    }

    public synchronized void setFinished() {
        this.finished = true;
        this.notifyAll();
    }

    public boolean isFinished() {
        return this.finished;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.threads;

import java.util.concurrent.Callable;

/**
 *
 * @author Danniel
 */
public abstract class Consumer implements Callable<Boolean>{
    
}

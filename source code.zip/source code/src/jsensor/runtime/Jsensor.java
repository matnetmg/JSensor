/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.runtime;

import java.awt.Color;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.models.DefaultReliabilityModel;
import jsensor.runtime.threads.EventsCreationThread;
import jsensor.runtime.threads.NodesCreationThread;
import jsensor.nodes.Node;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.events.EventTimeQueue;
import jsensor.nodes.messages.ID;
import jsensor.nodes.models.ConnectivityModel;
import jsensor.nodes.models.DistributionModelEvent;
import jsensor.nodes.models.DistributionModelNode;
import jsensor.nodes.models.InterferenceModel;
import jsensor.nodes.models.MobilityModel;
import jsensor.nodes.models.ReliabilityModel;
import jsensor.nodes.monitoring.CellModel;
import jsensor.threads.ListResource;
import jsensor.utils.Configuration;
import jsensor.utils.IDInterval;
import jsensor.utils.Position;
import jsensor.utils.TripleInt;

/**
 * This class represents the global configuration and methods of the current simulation.
 * @author danniel
 */
public class Jsensor {

    public static AbsCustomGlobal customGlobal;
    public static boolean isRunning = false;
    public static long currentTime = 0;
    public static long currentRound = 0;
    private static int lastChunck = 0;
    private static int lastChunckFacts = 0;
    private static int[] vetStart = new int[Configuration.numberOfChunks];
    private static int[] vetStartFacts = new int[Configuration.numberOfChunks];
    private static long[] eventqID = new long[Configuration.numberOfChunks];
    private static long[] packetID = new long[Configuration.numberOfChunks];
    private static Hashtable<String, IDInterval> vetNodes = new Hashtable<>(5);
    private static jsensor.utils.IDMessages[] IDMessages = new jsensor.utils.IDMessages[Configuration.numberOfChunks];
    
    public static double _criacaoNodes = 0;
    
    public static int numNodes = 0;
    public static int numFacts = 0;
    public static String[] distributionModels;
    public static String[] mobilityModels;
    public static String[] connectivityModels;
    public static String[] nodesImplementation;
    public static String[] factsImplementation;
    public static String[] projects;
    public static String myCell;
    public static int quadNumber = 1;
    public static final String usrdir = System.getProperty("user.dir");
    public static Runtime runtime;
    public static Color edgeColor = Color.BLACK;
    public static Color sendingColor = Color.RED;
    public static String projectPath;
    public static String directoryPath;
    public static ListResource<String> msgsResourcee;
    public static EventTimeQueue eventsTimeToHandle = new EventTimeQueue();
    public static EventTimeQueue eventsMobilityTimeToHandle = new EventTimeQueue();
    public static int teste = 0;
    
    public static void startMesseges(){
    	
    	//Starts the generators of id messages
    	for(byte i = 0; i< Configuration.numberOfChunks; i++){
        	IDMessages[i] = new jsensor.utils.IDMessages(i);
        }
    }
    
    public static String getProjectsBinPath(){
        
        String pathd =Configuration.projectPath+"."+Configuration.projectName;
        return pathd;

    }
    
    public static int getDimX(){
        return Configuration.dimX;
    }
    
    public static int getDimY(){
        return Configuration.dimY;
    }
    
    public static long getIDMessage(int chunk){
    	return IDMessages[chunk].getNextID();
    }
    
    public static Node getNodeByID(int id){
        
        return Jsensor.runtime.getSensorByID(id);
        
    }
    
    public static ID getEventID(int i){
    	return new ID(eventqID[i]++, i); 
    }
    
    public static long getNumberOfEvent(){
    	long sum = 0;
    	for(long e: eventqID)
    		sum+=e;
    	
    	return sum; 
    }
    
    public static ID getPacketID(int i){
        return new ID(packetID[i]++, i); 
    }
    
    public static int getNumNodes(){
    	return numNodes; 
    }
    
    public static void addNumNodes(String name, int start, int end){
    	vetNodes.put(name, new IDInterval(start, end));
    }
    
    /**
     * This method provides the number of existing nodes of a given type.
     * @param name - the name of the type nodes.
     * @return an integer representing the number of existing nodes of a given type, or 0 if the type does not exist.
     */
    public static int getNumNodes(String name){
    	if(vetNodes.containsKey(name)){
    		IDInterval id = vetNodes.get(name);
    		
    		return (id.getEnd() - id.getStart() + 1);
    	}
    	else 
    		return 0; 
    }
    
    
    /**
     * This method returns an IDInterval class containing the id start and id end of nodes of a given type.
     * @param name - The name of the type nodes.
     * @return An IDInterval class, or null if the type does not exist.
     */
    public static IDInterval getIDInterval(String name){
    	if(vetNodes.containsKey(name)){
    		return vetNodes.get(name);
    	}
    	else 
    		return null; 
    }
    
    public static int getDimensionX(String name){
    	return Configuration.dimX; 
    }
    
    public static int getDimensionY(String name){
    	return Configuration.dimY; 
    }
    
    public static int getNumFacts(){
        return numFacts;
    }
    
    public static void log_jsensor(String s){
		if(Configuration.log_jsensor)
			Jsensor.msgsResourcee.putRegister("#" + s);	
	}
    
    public static void log(String s){
		if(Configuration.log_user)
			Jsensor.msgsResourcee.putRegister("$" + s);	
	}
	
	public static void log_debug(String s){
		if(Configuration.log_debug)
			Jsensor.msgsResourcee.putRegister(s);
	}
	
	public static CellModel getCell(int x, int y){
		return Jsensor.runtime.getSensorsHash().getCell(x, y);
	}
	
	public static CellModel getCell(Position p){
		return Jsensor.runtime.getSensorsHash().getCell(p.getPosX(), p.getPosY());
	}
	
	public static void setCell(CellModel cell){
		Jsensor.runtime.getSensorsHash().setCell(cell);
	}

    public static void genFacts(Runtime runtime, int index){
		int numFacts = Configuration.numberFacts[index];
		int factChunks = (numFacts - (Configuration.numberOfChunks-lastChunckFacts))/Configuration.numberOfChunks;
		int restChunks;
		if(numFacts <= (Configuration.numberOfChunks-lastChunckFacts))
			restChunks = 0;
		else 
			restChunks = (numFacts - (Configuration.numberOfChunks-lastChunckFacts)) % Configuration.numberOfChunks;
		
		
		DistributionModelEvent distributionModelEvent = null;
	    String distModelName = Configuration.factDistributionModels[index].getName();
	    distModelName = distModelName.substring(distModelName.lastIndexOf('.') + 1);
		
		try {
			if(distModelName.equalsIgnoreCase("GrideDistributionFact"))
				distributionModelEvent = (DistributionModelEvent) Configuration.factDistributionModels[index].newInstance(Jsensor.numFacts, numFacts);
			else
				distributionModelEvent = (DistributionModelEvent) Configuration.factDistributionModels[index].newInstance();

        } catch (InvocationTargetException ex) {
            Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
        }
		
        Jsensor.numFacts += numFacts;
        
        EventsCreationThread[] ncts = new EventsCreationThread[Configuration.numberOfThreads];
		TripleInt[] triples = new TripleInt[Configuration.numberOfChunks];
		
		for(int i = 0; i < Configuration.numberOfChunks; i++){
			triples[i] = new TripleInt(vetStartFacts[i], vetStartFacts[i] + factChunks, i);
			vetStartFacts[i] += factChunks;
		}
		
		int end = Configuration.numberOfChunks;
		if(numFacts < (Configuration.numberOfChunks-lastChunckFacts))
			end = lastChunckFacts + numFacts;
		
		for(int i = lastChunckFacts; i < end; i++){
			TripleInt aux = triples[i];
			aux.setB(aux.getb() + 1);
			triples[i] = aux;
			vetStartFacts[i] += 1;
			lastChunckFacts = i + 1;
		}
		
		if(restChunks > 0){
			for(int i = 0; i < restChunks; i++){
				TripleInt aux = triples[i];
				aux.setB(aux.getb() + 1);
				triples[i] = aux;
				vetStartFacts[i] += 1;
				lastChunckFacts = i + 1;
			}
		}
		
		if(lastChunckFacts > 7)
			lastChunckFacts = 0;
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
        	ncts[i] = new EventsCreationThread(index, i, triples, runtime.getEventList(), runtime, distributionModelEvent);
        	ncts[i].setName(""+i);
        }
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
            ncts[i].start();
        }
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
            try {
                ncts[i].join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
	public static void genNodes(ConcurrentNodesPositionHashMap hashMap, Runtime runtime, int index){
		int numNodes = Configuration.numberNodes[index];
		int nodeChunks = (numNodes - (Configuration.numberOfChunks-lastChunck))/Configuration.numberOfChunks;
		int restChunks;
		if(numNodes <= (Configuration.numberOfChunks-lastChunck))
			restChunks = 0;
		else 
			restChunks = (numNodes - (Configuration.numberOfChunks-lastChunck)) % Configuration.numberOfChunks;
		
		Jsensor.addNumNodes(Configuration.nodeNames[index], Jsensor.numNodes +1 , Jsensor.numNodes + numNodes);
		
		ConnectivityModel connectivityModel = null;
		InterferenceModel interferenceModel = null;
		ReliabilityModel reliabilityModel = null;
	    DistributionModelNode distributionModel = null;
	    MobilityModel mobilityModel = null;
	    String distModelName = Configuration.distributionModels[index].getName();
	    distModelName = distModelName.substring(distModelName.lastIndexOf('.') + 1);
		
		try {
			if(distModelName.equalsIgnoreCase("GrideDistributionNode"))
				distributionModel = (DistributionModelNode) Configuration.distributionModels[index].newInstance(Jsensor.numNodes+1, numNodes);
			else{
				distributionModel = (DistributionModelNode) Configuration.distributionModels[index].newInstance();
			}
			
			
			connectivityModel = (ConnectivityModel) Configuration.connectivityModels[index].newInstance();
			if(Configuration.reliabilityModels[index] == null)
				reliabilityModel = new DefaultReliabilityModel();
			else
				reliabilityModel = (ReliabilityModel) Configuration.reliabilityModels[index].newInstance();
			
        	if(Configuration.assynchronousMode == false)
        		mobilityModel = (MobilityModel) Configuration.mobilityModels[index].newInstance();

        } catch (InvocationTargetException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
        }
		
        Jsensor.numNodes += numNodes;
        
        NodesCreationThread[] ncts = new NodesCreationThread[Configuration.numberOfThreads];
		TripleInt[] triples = new TripleInt[Configuration.numberOfChunks];
		
		for(int i = 0; i < Configuration.numberOfChunks; i++){
			triples[i] = new TripleInt(vetStart[i], vetStart[i] + nodeChunks, i);
			vetStart[i] += nodeChunks;
		}
		
		int end = Configuration.numberOfChunks;
		if(numNodes < (Configuration.numberOfChunks-lastChunck))
			end = lastChunck + numNodes;
		
		for(int i = lastChunck; i < end; i++){
			TripleInt aux = triples[i];
			aux.setB(aux.getb() + 1);
			triples[i] = aux;
			vetStart[i] += 1;
			lastChunck = i + 1;
		}
		
		if(restChunks > 0){
			for(int i = 0; i < restChunks; i++){
				TripleInt aux = triples[i];
				aux.setB(aux.getb() + 1);
				triples[i] = aux;
				vetStart[i] += 1;
				lastChunck = i + 1;
			}
		}
		
		if(lastChunck > Configuration.numberOfChunks)
			lastChunck = 0;
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
        	ncts[i] = new NodesCreationThread(hashMap, index, i, triples, runtime.getMyLists(), runtime, connectivityModel, interferenceModel, reliabilityModel, distributionModel, mobilityModel);
        	ncts[i].setName(""+i);
        }
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
            ncts[i].start();
        }
        
        for(int i = 0; i < Configuration.numberOfThreads; i++){
            try {
                ncts[i].join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Jsensor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.runtime;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.Main;
import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.messages.Packet;
import jsensor.runtime.threads.AssynchronousConsumerCallable;
import jsensor.threads.LogConsumer;
import jsensor.utils.Configuration;

/**
 * This class represents the execution runtime for assynchronous simulation.
 * This runtime implements how a simulation will be executed when assynchronous mode
 * is active.
 * @author danniel e Matheus
 */
public class AssynchronousRuntime extends Runtime {

    //private AssynchronousConsumerThread[] asct;
    private LogConsumer logConsumer;
    ExecutorService executor;
    ExecutorCompletionService<Boolean> ecs;
    

    public AssynchronousRuntime() {
        super();
        //this.asct = new AssynchronousConsumerThread[Configuration.numberOfThreads];
        this.executor = Executors.newFixedThreadPool(Configuration.numberOfThreads);
        this.ecs = new ExecutorCompletionService<Boolean>(executor);

        if(Configuration.log_debug || Configuration.log_jsensor || Configuration.log_user)
        	this.logConsumer = new LogConsumer(Jsensor.msgsResourcee);
    }
    

    /**
     * For a given number of events (or simulation time) this method execute the following steps:
     * First it updates all nodes neighbouhoods. Then all facts within the simulation are update. 
     * The next step, this method receive all incoming messages and stores it in its correct Inbox. The last 
     * action is used to perform the Assynchronous step.
     */
    @Override
    public void run() 
    {
    	long time_milis = System.currentTimeMillis();
    	if(Configuration.log_debug || Configuration.log_jsensor || Configuration.log_user)
    		this.logConsumer.start();
    	
    	Jsensor.eventsTimeToHandle.addEventToHandle(0);
        int nextEvent = Jsensor.eventsTimeToHandle.getFirst();
        
        if(Configuration.log_debug)
        {
        	double t = (System.currentTimeMillis() - Main.time)/1000;
            System.out.println("[DEBUG] Pre run: " + t +" seconds\n");
        }
    	
    	while(!abort)
        {
            long time = Jsensor.currentTime;
            //System.out.print(time);
            //imprimePosicoes();
            
            
	        /*if (refreshRate != 0) {
	            if (time % refreshRate == 0) {
	                
	            }
	        }*/
            Jsensor.log_jsensor(String.format("-- Time %d started", time));
            
            Jsensor.customGlobal.preRound();
            
            //Jsensor.msgsResource.putRegister("time: "+time+" nextEvent:"+nextEvent);
            if(time == nextEvent)
            {
            	//###########################################################################################################################
	        	if(Configuration.positionChanged){
	        		
	            	for (int t = 0; t < Configuration.numberOfChunks; t++) {
	            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.findingNeighbours, Jsensor.currentTime, this.sensorsHash));
	                }
	            	
	                for (int i = 0; i < Configuration.numberOfChunks; i++) {
	    	            try {
	    					ecs.take();
	    				} catch (InterruptedException e) {
	    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
	    				}
	    	        }
	
	                synchronized (Configuration.class) {
	                	Configuration.positionChanged = false;
					}
	                if(Configuration.log_debug)
	                {
	                	double t = (System.currentTimeMillis() - Main.time)/1000;
	                    //System.out.println("[DEBUG] Finding neighbours: " + t +" seconds\n");
	                }
	            }
	        	
	        	
	        	//###########################################################################################################################
	        	
	
	        	if(Configuration.hasFacts){
	        		
	        	 	for (int t = 0; t < Configuration.numberOfChunks; t++) {
	            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.updatingFacts, time, this.sensorsHash));
	                }
	            	
	                for (int i = 0; i < Configuration.numberOfChunks; i++) {
	    	            try {
	    					ecs.take();
	    				} catch (InterruptedException e) {
	    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
	    				}
	    	        }
	                
	              //###########################################################################################################################
	                
	                
	                for (int t = 0; t < Configuration.numberOfChunks; t++) {
	            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.updatingFactCells, time, this.sensorsHash));
	                }
	            	
	                for (int i = 0; i < Configuration.numberOfChunks; i++) {
	    	            try {
	    					ecs.take();
	    				} catch (InterruptedException e) {
	    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
	    				}
	    	        }
	        	}
	        	
	        	
	        	//###########################################################################################################################
	        	
	                
                for (int t = 0; t < Configuration.numberOfChunks; t++) {
            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.reading_messages, time, this.sensorsHash));
                }
            	
                for (int i = 0; i < Configuration.numberOfChunks; i++) {
    	            try {
    					ecs.take();
    				} catch (InterruptedException e) {
    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
    				}
    	        }
                
                
                //###########################################################################################################################
        	
                
                for (int t = 0; t < Configuration.numberOfChunks; t++) {
            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.updatingCells, time, this.sensorsHash));
                }
            	
                for (int i = 0; i < Configuration.numberOfChunks; i++) {
    	            try {
    					ecs.take();
    				} catch (InterruptedException e) {
    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
    				}
    	        }
                
                
                //###########################################################################################################################
                
                
                for (int t = 0; t < Configuration.numberOfChunks; t++) {
            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.steping_timer, time, this.sensorsHash));
                }
            	
                for (int i = 0; i < Configuration.numberOfChunks; i++) {
    	            try {
    					ecs.take();
    				} catch (InterruptedException e) {
    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
    				}
    	        }
                
                
                //###########################################################################################################################
                
            
                for (int t = 0; t < Configuration.numberOfChunks; t++) {
            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.steping_messages, time, this.sensorsHash));
                }
            	
                for (int i = 0; i < Configuration.numberOfChunks; i++) {
    	            try {
    					ecs.take();
    				} catch (InterruptedException e) {
    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
    				}
    	        }
	           
                
                //###########################################################################################################################
	            
                
	            if(Configuration.hasMobility){
	            	
	            	
	            	for (int t = 0; t < Configuration.numberOfChunks; t++) {
	            		ecs.submit(new AssynchronousConsumerCallable(myLists, eventList, t, ThreadState.steping_moviment, time, this.sensorsHash));
	                }
	            	
	                for (int i = 0; i < Configuration.numberOfChunks; i++) {
	    	            try {
	    					ecs.take();
	    				} catch (InterruptedException e) {
	    					Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
	    				}
	    	        }
	            }

	            //print(3);
	            if(Jsensor.eventsTimeToHandle.isEmpty())
	            	abort = true;
	            else
	            	nextEvent = Jsensor.eventsTimeToHandle.getFirst();
            }
           
            //check conditions
            if(Configuration.numberOfRounds <= Jsensor.currentTime && Configuration.numberOfRounds != 0){
            	abort = true;
            }
            if(Jsensor.customGlobal.hasTerminated())
            	abort = true;
            	
            Jsensor.customGlobal.postRound();
            Jsensor.currentTime++;
            //System.out.print(" - "+ time +" -- ");
            
           /* if (refreshRate != 0) {
                if(time % refreshRate == 0) {
                    String s = String.format("-- Time %d finished", time);
                    Jsensor.msgsResource.putRegister(s);
                }
            }*/
            Jsensor.log_jsensor(String.format("-- Time %d finished", time));
            
        }
    	Main.printInformations();
    	
    	executor.shutdown();
    	joinThreads();
    }
    
    public void joinThreads(){
    	if(Configuration.log_debug || Configuration.log_jsensor || Configuration.log_user)
    	{
    		Jsensor.msgsResourcee.setFinished();
			try {
		         
				this.logConsumer.join();
				this.logConsumer.close();
			} catch (InterruptedException e) {
				Logger.getLogger(AssynchronousRuntime.class.getName()).log(Level.SEVERE, null, e);
			}
    	}
    }
    
    public void printNeighbours(){
    	TreeSet<Node> tree = new TreeSet<>();
    	
    	AbstractNodesList[] listss = Jsensor.runtime.getMyLists();
        for(AbstractNodesList e: listss){
        	for(Node n : e.getNodesList()){
        		tree.add(n);
        	}
        }
        
        Iterator<Node> it = tree.iterator();
        while (it.hasNext()) {
        	Node node = (Node) it.next();
			Jsensor.log_debug("Node "+node.getID() + " num viz "+ node.getNeighbours().size() + " position "+node.getPosition());
		}
    }
    
    
    public void printInbox()
    {
    	for( AbstractNodesList a : this.myLists){
    		for(Node n : a.getNodesList()){
    			for(Packet p : n.getInbox().seePackets()){
    				Jsensor.log_debug(Jsensor.currentTime + " sender: "+p.getNode().getID()+ " target: " +p.getTarget().getID()+" delay: "+p.getDelayTime()+" id: "+p.getID().getChunkie()+"-"+p.getID().getNumber());
    			}
    		}
    	}
    	Jsensor.log_debug("TIME ============================= " +Jsensor.currentTime);
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jsensor.runtime.threads;

import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.AbstractNodesPositionMatrix;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.collections.EventsList;
import jsensor.nodes.monitoring.Event;
import jsensor.runtime.Jsensor;
import jsensor.runtime.Runtime.ThreadState;
import jsensor.threads.Consumer;
import jsensor.utils.Position;

/**
 * This class represents the Consumer Thread of Synchronous mode. Each second
 * of simulation this Thread is executed to perform a specific action. It can manage
 * the nodes in three diferent ways: using an array of NodesList, using an array of 
 * NodesMatrix or using a Map.
 * @author danniel
 */
public class SynchronousConsumerCallable extends Consumer{

    private ThreadState myState;
    private AbstractNodesList[] myLists;
    private ConcurrentNodesPositionHashMap nodesMap;
    private int indexToWrite;
    private EventsList[] events;

    
    public SynchronousConsumerCallable(ThreadState myState,EventsList[] f,int indexToWrite, AbstractNodesList[] myLists, AbstractNodesPositionMatrix[] matrix) {
        this.myState = myState;
        this.myLists = myLists;
        this.indexToWrite = indexToWrite;
        this.events = f;
    }
    
    
    public SynchronousConsumerCallable(ThreadState myState,EventsList[] f,int indexToWrite, AbstractNodesList[] myLists, AbstractNodesPositionMatrix matrix) {
        this.myState = myState;
        this.myLists = myLists;
        this.indexToWrite = indexToWrite;
        this.events = f;
    }
    
    public SynchronousConsumerCallable(ThreadState myState,EventsList[] f,int indexToWrite, AbstractNodesList[] myLists, ConcurrentNodesPositionHashMap map) {
        this.myState = myState;
        this.myLists = myLists;
        this.nodesMap = map;
        this.indexToWrite = indexToWrite;
        this.events = f;
    }


    public ThreadState getMyState() {
        return myState;
    }

    public void setMyState(ThreadState myState) {
        this.myState = myState;
    }

    /**
     * For a given ThreadState, this method perform an action that can be 
     * update facts, move nodes, rebuild the matrix, find neighbours or perform
     * node's step phase.
     */
    @Override
    public Boolean call() throws Exception {

       switch(myState){
           case updatingFacts:{
               for(Event f:this.events[indexToWrite].getEventList()){
                    double oldvalue = 0;
                    if(f.getTimeElapsed() >= f.getDuration()){
                        
                        Jsensor.log_jsensor(String.format("Round %d\nFact %d\nExtinguishing;",Jsensor.currentRound,f.getID() ));
                        this.events[indexToWrite].getEventList().remove(f);
                        continue;
                    }
                    f.setTimeElapsed(f.getTimeElapsed()+1);
                    f.setValue(f.updateValue());
                    
                 
                    Jsensor.log_jsensor(String.format("Round %d\nFact %d\nUpdated Value;\nOld Value: %.2f\nNew Value: %.2f",
                                Jsensor.currentRound,f.getID(),oldvalue,f.getValue() ));
                   
            }
               
               break;
           }
            
            case moving:{

                for(Node n:this.myLists[indexToWrite].getNodesList()){
                	Position old = n.getPosition();
                    n.setPosition(n.getMobilityModel().getNextPosition(n));
                    nodesMap.changeSensorPosition(n, old, n.getPosition());
                    
                   Jsensor.log_jsensor(String.format("Round %d\nNode %d\nChanged Position;\nOld Position: %s\nNew Position: %s",
                                Jsensor.currentRound,n.getID(),old.toString(),n.getPosition().toString() ));
                       
                  
                }
               

                break;

           }
           case findingNeighbours: {
        	   for(Node n:this.myLists[indexToWrite].getNodesList()){
//                 n.removeAllConnections();
                 n.setNeighborhoodChange(n.getConectivityModel().updateConnection(n,nodesMap));
                 
               
                 Jsensor.log_jsensor(String.format("Round %d\nNode %d\nUpdate Neighbours;\nUpdated? %b",
                             Jsensor.currentRound,n.getID(),n.isNeighborhoodChange()));
                 
             }

                break;
            }
            case steping_messages:{

                for(Node n:this.myLists[indexToWrite].getNodesList()){
                    //n.step();
                    
                   
                    Jsensor.log_jsensor( String.format("Round %d\nNode %d\nPerforming Step Phase;",
                                Jsensor.currentRound,n.getID() ));
                    
                }

                break;
            }
			default:
				break;
        }
       return null;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsensor.runtime.threads;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsensor.Main;
import jsensor.nodes.Node;
import jsensor.nodes.collections.AbstractNodesList;
import jsensor.nodes.collections.ConcurrentNodesPositionHashMap;
import jsensor.nodes.models.ConnectivityModel;
import jsensor.nodes.models.DistributionModelNode;
import jsensor.nodes.models.InterferenceModel;
import jsensor.nodes.models.MobilityModel;
import jsensor.nodes.models.ReliabilityModel;
import jsensor.runtime.Runtime;
import jsensor.utils.Configuration;
import jsensor.utils.Position;
import jsensor.utils.TripleInt;
import jsensor.utils.Tuple;

/**
 * This class implements the thread responsible to create the nodes efficiently.
 * The set of all nodes to be created is divided into abstract sets and each NodesCreationThread
 * takes one of this lists and creates an instance of those nodes.
 * @author Danniel
 */
public class NodesCreationThread extends Thread{
	private ConcurrentNodesPositionHashMap hashMap;
    private ConnectivityModel connectivityModel;
    private InterferenceModel interferenceModel;
    private ReliabilityModel reliabilityModel;
    private DistributionModelNode distributionModel;
    private MobilityModel mobilityModel;
    private int index;
    private TripleInt[] tripleList;
    private AbstractNodesList[] nodesList;
    private Runtime runtime;
    private int tripleIndex;
    private LinkedList<Tuple<Integer,Position>> nodes;

    public NodesCreationThread(ConcurrentNodesPositionHashMap hashMap, int index, int tripleIndex, TripleInt[] triple, AbstractNodesList[] nodesList, 
    		Runtime runtime, ConnectivityModel connectivityModel, InterferenceModel interferenceModel, ReliabilityModel reliabilityModel,
    		DistributionModelNode distributionModel, MobilityModel mobilityModel) {
    	this.hashMap = hashMap;
    	this.index = index;
        this.tripleList = triple;
        this.nodesList = nodesList;
        this.runtime = runtime;
        this.tripleIndex = tripleIndex;
        this.connectivityModel = connectivityModel;
        this.interferenceModel = interferenceModel;
        this.reliabilityModel = reliabilityModel;
        this.distributionModel = distributionModel;
        this.mobilityModel = mobilityModel;
    }

    public NodesCreationThread(int tripleIndex, ConnectivityModel connectivity, int numNodes, AbstractNodesList[] nodesList, Runtime runtime, 
            String nodeProjetc, String nodeImpl, LinkedList<Tuple<Integer, Position>> nodes) {
        this.nodesList = nodesList;
        this.runtime = runtime;
        this.nodes = nodes;
        this.tripleIndex = tripleIndex;
    }

    /**
     * The number of all nodes to be created is divided equally for all NodesCreationThreads
     * and these number of nodes is instantiated by this method.
     * For a desired number of nodes, this method instantiate them and put into an AbstractNodesList.
     */
    @Override
    public void run() {
		TripleInt triple = tripleList[this.tripleIndex];
		
    	
		for(int i = triple.geta(); i < triple.getb(); i++){
			byte chunks = (byte) triple.getc();
			
			Node node = null;
	        try {
	            node = (Node) Configuration.nodeTypes[index].newInstance();
	
	        } catch (InvocationTargetException ex) {
	            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (IllegalArgumentException ex) {
	            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (SecurityException ex) {
	            Logger.getLogger(NodesCreationThread.class.getName()).log(Level.SEVERE, null, ex);
	        }
	
	        node.setChunk(chunks);
	        node.setRuntime(runtime);
	        node.setID((i * Configuration.numberOfChunks + chunks)+ 1);
	        node.setConectivityModel(connectivityModel);
	        node.setInterferenceModel(interferenceModel);
	        node.setReliabilityModel(reliabilityModel);
	        node.setCommunicationRadio(Configuration.communicationRadios[index]);
	        if(Configuration.assynchronousMode == false)
	            node.setMobilityModel(mobilityModel);
	        
	        
	        
	        try {
	        	Position p = distributionModel.getPosition(node);
	        	if(p == null)
	        		throw new NullPointerException("The getPosition(Node "+node.getID()+") method of "+distributionModel.getClass().getSimpleName()+" class should not return null.");
	        	
	        	node.setPosition(p);
			} catch (NullPointerException ex) {
				System.err.println("The getPosition(Node "+node.getID()+") method of "+distributionModel.getClass().getSimpleName()+" class should not return null.");
				Main.LOG.log(Level.SEVERE, null, ex);
				System.exit(1);
			}
	        
	        this.nodesList[tripleIndex].addNode(node);
	        
    	} 
		
		hashMap.addNodesHashMap(this.nodesList[tripleIndex]);
		
    	if(Configuration.virtualThread)
    		if(tripleIndex == Integer.parseInt(Thread.currentThread().getName()))
    			runThread();
    }
    
    private void runThread(){
    	for(Object i : Configuration.threads[Integer.parseInt(Thread.currentThread().getName())]){
    		new NodesCreationThread(hashMap, index, (int) i, tripleList, nodesList, runtime, connectivityModel,
    				interferenceModel, reliabilityModel, distributionModel, mobilityModel).run();
    	}
    }
    
}
